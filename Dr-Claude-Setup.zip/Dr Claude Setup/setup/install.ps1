# Dr. Claude installer. Run it from "Install Dr. Claude.cmd" (double-click). No admin rights needed.
#   Installs to  %LOCALAPPDATA%\Dr Claude\  (python\ = official Python 3.12 embeddable, app\ = Dr. Claude)
#   Your notes, Course Records and Canvas files live in  Documents\Dr. Claude\  (never touched by reinstalling)
param([string]$Dest = '', [switch]$Test)  # -Test: install into -Dest, shortcuts into -Dest\shortcuts, no Codex, no launch
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $here
$dest = if ($Dest) { $Dest } else { Join-Path $env:LOCALAPPDATA 'Dr Claude' }
$py = Join-Path $dest 'python'
$app = Join-Path $dest 'app'

function Say($t, $c = 'Gray') { Write-Host $t -ForegroundColor $c }

try {
    Say ''
    Say '  Dr. Claude setup' 'Yellow'
    Say '  ----------------' 'Yellow'
    Get-ChildItem -LiteralPath $root -Recurse -File | Unblock-File -ErrorAction SilentlyContinue

    # close a running copy so its files can be replaced
    Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($py, [StringComparison]::OrdinalIgnoreCase) } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

    Say '  1/4  Python (official embeddable 3.12)...'
    $zip = Get-ChildItem -LiteralPath $here -Filter 'python-3.12*-embed-amd64.zip' | Select-Object -First 1
    if (-not $zip) {
        # Small download: fetch the official Python from python.org and check its fingerprint (sha256)
        Say '       downloading Python 3.12.10 from python.org (11 MB)...'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $pzip = Join-Path $env:TEMP 'python-3.12.10-embed-amd64.zip'
        Invoke-WebRequest -UseBasicParsing -Uri 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip' -OutFile $pzip
        if ((Get-FileHash -LiteralPath $pzip -Algorithm SHA256).Hash -ne '4ACBED6DD1C744B0376E3B1CF57CE906F9DC9E95E68824584C8099A63025A3C3') {
            Remove-Item -LiteralPath $pzip -Force -ErrorAction SilentlyContinue
            throw 'The Python download did not match its fingerprint. Check your internet and run setup again.'
        }
        $zip = Get-Item -LiteralPath $pzip
    }
    $stamp = Join-Path $py '.version'
    if (-not (Test-Path $stamp) -or (Get-Content $stamp -Raw).Trim() -ne $zip.Name) {
        if (Test-Path $py) { Remove-Item -LiteralPath $py -Recurse -Force }
        New-Item -ItemType Directory -Force -Path $py | Out-Null
        Expand-Archive -LiteralPath $zip.FullName -DestinationPath $py -Force
        Set-Content -LiteralPath $stamp -Value $zip.Name -Encoding ascii
    }

    Say '  2/4  Dr. Claude app...'
    New-Item -ItemType Directory -Force -Path $app | Out-Null
    # copy everything except data\ (chats, settings and keys from an earlier install stay put)
    Get-ChildItem -LiteralPath (Join-Path $root 'app') | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $app -Recurse -Force
    }
    Copy-Item -LiteralPath (Join-Path $here 'uninstall.ps1') -Destination $dest -Force
    Set-Content -LiteralPath (Join-Path $dest 'Uninstall Dr. Claude.cmd') -Encoding ascii -Value @'
@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
pause
'@

    Say '  3/4  Shortcuts...'
    $ws = New-Object -ComObject WScript.Shell
    $targets = if ($Test) { @((New-Item -ItemType Directory -Force -Path (Join-Path $dest 'shortcuts')).FullName) }
               else { @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs')) }
    foreach ($dir in $targets) {
        $lnk = $ws.CreateShortcut((Join-Path $dir 'Dr. Claude.lnk'))
        $lnk.TargetPath = Join-Path $py 'pythonw.exe'
        $lnk.Arguments = '"' + (Join-Path $app 'dr_claude.py') + '"'
        $lnk.WorkingDirectory = $app
        $lnk.IconLocation = (Join-Path $app 'static\icon.ico') + ',0'
        $lnk.Description = 'Dr. Claude: your study professor'
        $lnk.Save()
    }

    Say '  4/4  ChatGPT (Codex) for the AI tutor...'
    $codex = Join-Path $env:LOCALAPPDATA 'Programs\OpenAI\Codex\bin\codex.exe'
    if ($Test) {
        Say '       (test run: skipped)'
    } elseif ((Test-Path $codex) -or (Get-Command codex -ErrorAction SilentlyContinue)) {
        Say '       Codex is already installed.' 'Green'
    } else {
        $ans = Read-Host '       Install OpenAI Codex now? It lets Dr. Claude use your school ChatGPT account. [Y/n]'
        if ($ans -notmatch '^(n|no)$') {
            try {
                # OpenAI's official installer (downloads from OpenAI, checks the file, no admin needed)
                powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://chatgpt.com/codex/install.ps1 | iex"
                Say '       Codex installed.' 'Green'
            } catch {
                Say '       Codex did not install. You can do it later in Dr. Claude (Settings > AI brain > Install Codex).' 'Yellow'
            }
        } else {
            Say '       Skipped. You can install it later from inside Dr. Claude, or use a free Gemini key instead.'
        }
    }

    Say ''
    Say '  Done! Dr. Claude is opening now. Next time, use the "Dr. Claude" icon on your Desktop.' 'Green'
    if ($Test) { exit 0 }
    Start-Process -FilePath (Join-Path $py 'pythonw.exe') -ArgumentList ('"' + (Join-Path $app 'dr_claude.py') + '"') -WorkingDirectory $app
    Start-Sleep -Seconds 4
} catch {
    Say ''
    Say ("  Setup hit a problem: " + $_.Exception.Message) 'Red'
    Say '  Take a screenshot of this window and send it to whoever gave you Dr. Claude.' 'Red'
    Read-Host '  Press Enter to close'
    exit 1
}
