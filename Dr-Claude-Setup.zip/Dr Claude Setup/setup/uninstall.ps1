# Removes the Dr. Claude program and its shortcuts. Asks before touching your notes (Documents\Dr. Claude).
$dest = Join-Path $env:LOCALAPPDATA 'Dr Claude'
$py = Join-Path $dest 'python'
Write-Host ''
Write-Host '  Uninstall Dr. Claude' -ForegroundColor Yellow
Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($py, [StringComparison]::OrdinalIgnoreCase) } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    Remove-Item -LiteralPath (Join-Path $dir 'Dr. Claude.lnk') -Force -ErrorAction SilentlyContinue
}
Set-Location $env:TEMP
Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue
Write-Host '  Removed the program, its chats, settings and saved keys.' -ForegroundColor Green

$notes = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Dr. Claude'
if (Test-Path $notes) {
    $a = Read-Host "  Also delete your notes, Course Records and downloaded Canvas files in $notes ? [y/N]"
    if ($a -match '^(y|yes)$') { Remove-Item -LiteralPath $notes -Recurse -Force; Write-Host '  Deleted.' } else { Write-Host '  Kept them.' }
}
Write-Host ''
Write-Host '  Two things only you can do:' -ForegroundColor Yellow
Write-Host '   - Canvas: Account > Settings > Approved Integrations > delete the "Dr. Claude" token.'
Write-Host '   - Codex (optional): delete the folder %LOCALAPPDATA%\Programs\OpenAI\Codex and %USERPROFILE%\.codex'
