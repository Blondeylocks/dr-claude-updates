Dr. Claude - your study professor
=================================

1. Right-click "Dr Claude Setup.zip" > Extract All (don't run it from inside the zip).
2. Double-click "Install Dr. Claude.cmd".
   If Windows says "Windows protected your PC": click "More info" > "Run anyway".
3. Dr. Claude opens and walks you through setup (name, how you like to learn, AI, Canvas).

What gets installed (no admin rights needed):
  %LOCALAPPDATA%\Dr Claude\python   official Python 3.12 (embeddable, from python.org)
  %LOCALAPPDATA%\Dr Claude\app      the Dr. Claude app (+ data\ = chats, settings, encrypted keys)
  Documents\Dr. Claude\             your classes: Canvas files, Course Records, Teaching Rules, notes
  Desktop + Start menu shortcut "Dr. Claude"
  Optional: OpenAI Codex (official installer) so the tutor can use your school ChatGPT account

Uninstall: run "%LOCALAPPDATA%\Dr Claude\Uninstall Dr. Claude.cmd".
