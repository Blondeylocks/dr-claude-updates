@echo off
title Dr. Claude setup
if not exist "%~dp0setup\install.ps1" goto notextracted
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\install.ps1"
goto :eof
:notextracted
powershell -NoProfile -Command "Add-Type -AssemblyName PresentationFramework; $m = 'One quick step first: Dr. Claude has to be unzipped before it can install.||1. Close this message.|2. Find the Dr Claude Setup zip file you downloaded (usually in your Downloads folder).|3. Right-click it, choose Extract All, then click Extract.|4. In the folder that opens, double-click Install Dr. Claude again.'.Replace('|', [Environment]::NewLine); [System.Windows.MessageBox]::Show($m, 'Dr. Claude setup') | Out-Null"
