"""One-click "🎤 Voice upgrade (Whisper)" installer (v1.4.2, 2026-11-11).

The installed app runs on Python's small "embeddable" build, which has no pip. This module, in a background thread:
  1. gets pip: python -m pip if it exists, else downloads get-pip.py from bootstrap.pypa.io into <base>\\voice_pip
  2. pip installs faster-whisper + numpy (+ NVIDIA cuBLAS/cuDNN wheels only for the GPU model) into <base>\\voice_libs
  3. downloads the Whisper model from Hugging Face into <base>\\voice_models\\<name>
Progress goes to STATE, which the Settings card polls. The app never waits on any of this.
Nothing here touches the student's files, chats or settings. Removing voice_libs + voice_models undoes it all.
"""
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

import stt

NO_WINDOW = 0x08000000 if os.name == "nt" else 0
PIP_DIR = stt.BASE / "voice_pip"
TMP = stt.BASE / "voice_tmp"
GET_PIP = "https://bootstrap.pypa.io/get-pip.py"
MODEL_BYTES = {"small.en": 484_000_000, "large-v3-turbo": 1_620_000_000}

STATE = {"state": "idle", "step": "", "pct": 0, "error": "", "model": "", "started": 0, "finished": 0}
_lock = threading.Lock()
_log_lines = []


def _log(msg):
    line = time.strftime("%H:%M:%S ") + msg
    _log_lines.append(line)
    del _log_lines[:-200]
    try:
        stt.BASE.mkdir(parents=True, exist_ok=True)
        with open(stt.BASE / "voice_setup.log", "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def _set(**kw):
    STATE.update(kw)
    if "step" in kw:
        _log(f"[{STATE['pct']}%] {kw['step']}")


def nvidia_gpu():
    """Name of an NVIDIA GPU, or '' (nvidia-smi ships with the NVIDIA driver)."""
    exe = shutil.which("nvidia-smi") or r"C:\Windows\System32\nvidia-smi.exe"
    try:
        r = subprocess.run([exe, "--query-gpu=name", "--format=csv,noheader"], capture_output=True, text=True,
                           timeout=10, creationflags=NO_WINDOW)
        return r.stdout.strip().splitlines()[0].strip() if r.returncode == 0 and r.stdout.strip() else ""
    except Exception:
        return ""


def info():
    gpu = nvidia_gpu()
    models = []
    for name, m in stt.MODEL_INFO.items():
        if m["gpu"] and not gpu:
            continue
        models.append({"name": name, "label": m["label"], "size": m["size"], "ready": stt.model_ready(name)})
    return {"gpu": gpu, "models": models, "libs": stt.available(), "state": dict(STATE), "log": _log_lines[-6:]}


def _run(cmd, on_line=None, timeout=3600):
    _log("$ " + " ".join(str(c) for c in cmd)[:300])
    p = subprocess.Popen([str(c) for c in cmd], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                         encoding="utf-8", errors="replace", creationflags=NO_WINDOW, cwd=str(stt.BASE))
    t0 = time.time()
    tail = []
    for line in p.stdout:
        line = line.rstrip()
        if not line:
            continue
        tail.append(line)
        del tail[:-25]
        if on_line:
            on_line(line)
        if time.time() - t0 > timeout:
            p.kill()
            raise RuntimeError("took too long")
    rc = p.wait()
    if rc != 0:
        raise RuntimeError("\n".join(tail[-8:]) or f"exit code {rc}")


def _pip_cmd():
    """A command list that runs pip with this app's own Python."""
    py = sys.executable
    try:
        r = subprocess.run([py, "-m", "pip", "--version"], capture_output=True, text=True, timeout=60, creationflags=NO_WINDOW)
        if r.returncode == 0:
            return [py, "-m", "pip"]
    except Exception:
        pass
    if not (PIP_DIR / "pip").is_dir():
        _set(step="Getting the installer (pip)…", pct=3)
        TMP.mkdir(parents=True, exist_ok=True)
        gp = TMP / "get-pip.py"
        req = urllib.request.Request(GET_PIP, headers={"User-Agent": "Dr-Claude-voice-setup"})
        with urllib.request.urlopen(req, timeout=60) as r, open(gp, "wb") as f:
            shutil.copyfileobj(r, f)
        _run([py, gp, "--target", PIP_DIR, "--no-warn-script-location", "--disable-pip-version-check"])
    boot = f"import sys; sys.path.insert(0, r'{PIP_DIR}'); from pip._internal.cli.main import main; sys.exit(main(sys.argv[1:]))"
    return [py, "-c", boot]


def _dir_bytes(d):
    n = 0
    for root, _, files in os.walk(d):
        for f in files:
            try:
                n += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return n


def _install(model, gpu_libs):
    STATE.update(state="working", error="", pct=0, model=model, started=time.time(), finished=0)
    try:
        # 1-2: libraries
        if not stt.available() or (gpu_libs and not stt.has_cuda_libs()):
            pip = _pip_cmd()
            pkgs = ["faster-whisper", "numpy"] + (["nvidia-cublas-cu12", "nvidia-cudnn-cu12==9.*"] if gpu_libs else [])
            new = stt.BASE / "voice_libs.new"
            shutil.rmtree(new, ignore_errors=True)
            seen = [0]

            def on_line(line):
                if line.startswith(("Collecting", "Downloading", "Using cached")):
                    seen[0] += 1
                    parts = line.replace("Using cached", "Using").split()
                    name = (parts[1] if len(parts) > 1 else "").split("/")[-1].split("-")[0][:40]
                    _set(step=f"Downloading voice tools… ({name})", pct=min(42, 5 + seen[0] * (1 if gpu_libs else 2)))
                elif line.startswith("Installing collected"):
                    _set(step="Installing voice tools…", pct=44)

            _set(step="Downloading voice tools…", pct=5)
            _run(pip + ["install", "--target", new, "--only-binary=:all:", "--no-warn-script-location",
                        "--disable-pip-version-check", "--progress-bar", "off", *pkgs], on_line)
            if stt.LIBS.exists():
                old = stt.BASE / f"voice_libs.old{int(time.time())}"
                stt.LIBS.rename(old)
                shutil.rmtree(old, ignore_errors=True)
            new.rename(stt.LIBS)
            stt.add_libs_path()
            if not stt.available():
                raise RuntimeError("the voice tools installed but won't load")
        # 3: model
        if not stt.model_ready(model):
            _set(step=f"Downloading the voice model ({stt.MODEL_INFO[model]['size']})…", pct=46)
            dest = stt.model_dir(model)
            dest.mkdir(parents=True, exist_ok=True)
            code = (f"import sys; sys.path.insert(0, r'{stt.LIBS}'); from faster_whisper.utils import download_model; "
                    f"download_model({model!r}, output_dir=r'{dest}')")
            done = [False]

            def watch():
                total = MODEL_BYTES.get(model, 5e8)
                while not done[0]:
                    got = _dir_bytes(dest)
                    STATE["pct"] = int(46 + min(52, 52 * got / total))
                    STATE["step"] = f"Downloading the voice model… {got / 1e6:.0f} of ~{total / 1e6:.0f} MB"
                    time.sleep(1.0)

            th = threading.Thread(target=watch, daemon=True)
            th.start()
            try:
                _run([sys.executable, "-c", code])
            finally:
                done[0] = True
            if not stt.model_ready(model):
                raise RuntimeError("the voice model didn't finish downloading")
        _set(step="Starting Whisper…", pct=99)
        stt.unload()
        stt.load(model)
        _set(state="done", step=f"Voice upgrade is on ({model}, on the {stt.status()['device'].upper()}).", pct=100, finished=time.time())
    except Exception as e:
        _log(f"ERROR {e}")
        STATE.update(state="error", error=str(e)[-600:], finished=time.time(),
                     step="Something went wrong. Check your internet and try again.")
    finally:
        shutil.rmtree(TMP, ignore_errors=True)


def start(model=None):
    model = model if model in stt.MODEL_INFO else stt.DEFAULT_MODEL
    gpu_libs = stt.MODEL_INFO[model]["gpu"] and bool(nvidia_gpu())
    with _lock:
        if STATE["state"] == "working":
            return dict(STATE)
        STATE.update(state="working", step="Starting…", pct=1, error="")
        threading.Thread(target=_install, args=(model, gpu_libs), daemon=True).start()
    return dict(STATE)


def remove():
    """Turn the voice upgrade off and free the disk space."""
    stt.unload()
    for d in (stt.LIBS, stt.MODELS, PIP_DIR, stt.BASE / "voice_libs.new"):
        shutil.rmtree(d, ignore_errors=True)
    if str(stt.LIBS) in sys.path:
        sys.path.remove(str(stt.LIBS))
    STATE.update(state="idle", step="", pct=0, error="")
    return {"ok": True, "note": "Removed. Restart Dr. Claude to fully unload it."}
