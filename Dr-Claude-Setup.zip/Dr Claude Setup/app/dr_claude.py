#!/usr/bin/env python3
"""
Dr. Claude (portable) - a personal AI professor that learns your classes from Canvas.

How it works (the system):
    Edge app window  <--HTTP/SSE-->  this Python server (127.0.0.1 only)  -->  brain.py: ChatGPT (Codex CLI) or Gemini
                                         |
                                         +-- canvas_sync.py   Canvas token -> Documents\\Dr. Claude\\<course>\\ (files, Course Record)
                                         +-- built-in study timer, video catalog, thoughts, calculator, uploads

Data:  Documents\\Dr. Claude\\   profile, courses.json, deadlines.json, course folders, Thoughts, Video Library, AGENTS.md
       <app>\\data\\             settings, chats, logs, encrypted Canvas token / Gemini key, study_sessions.csv
       (DRC_HOME / DRC_DATA environment variables override these two, for testing)

Python 3.12 standard library only. Run:
    pythonw dr_claude.py               normal launch (opens the app window, closes with it)
    python  dr_claude.py --headless    server only, prints the URL (for testing)
"""
import base64
import csv
import datetime as dt
import json
import logging
import mimetypes
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))  # embeddable Python ignores the script folder (python312._pth)
import brain  # noqa: E402
import canvas_sync  # noqa: E402
import canvas_bridge  # noqa: E402
import rules  # noqa: E402
import filetext  # noqa: E402
import updates  # noqa: E402
import books  # noqa: E402
import ideas  # noqa: E402
import cliptrim  # noqa: E402
import coursebooks  # noqa: E402
import maker  # noqa: E402
import stt  # noqa: E402  (optional Whisper voice upgrade, v1.4.2)
import voice_setup  # noqa: E402
import voice_conf  # noqa: E402  (voice confidence reader, v1.4.2)

STATIC = APP_DIR / "static"
# Installed layout: <install>\python (embeddable Python), <install>\app (this code, replaced by updates),
# <install>\data (chats, settings, encrypted keys: never touched by updates).
INSTALL = APP_DIR.parent if (APP_DIR.parent / "python").is_dir() else None
DATA = Path(os.environ.get("DRC_DATA") or (INSTALL / "data" if INSTALL else APP_DIR / "data"))
if INSTALL and not os.environ.get("DRC_DATA") and (APP_DIR / "data").is_dir() and not DATA.exists():
    shutil.move(str(APP_DIR / "data"), str(DATA))  # v1.0 kept data inside app\; move it out of the updater's way
try:
    VERSION = (APP_DIR / "VERSION").read_text(encoding="utf-8").strip()
except OSError:
    VERSION = "0.0.0"
CHATS = DATA / "chats"
MEDIA = DATA / "chat_media"      # per chat: files the student attached + pictures the AI drew (deleted with the chat)
TEXTBOOK_FINDER = False   # v1.4.5: the web PDF finder is OFF in the public build (looked like piracy)
PENDING = DATA / "book_pending"  # textbook PDFs waiting for the student to say "yes, that's the right book"
HOME = Path.home()


def documents_dir():
    """The real Documents folder (it may be moved into OneDrive), via the Windows known-folder API."""
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [("a", wintypes.DWORD), ("b", wintypes.WORD), ("c", wintypes.WORD), ("d", ctypes.c_ubyte * 8)]
            fid = GUID(0xFDD39AD0, 0x238F, 0x46AF, (ctypes.c_ubyte * 8)(0xAD, 0xB4, 0x6C, 0x85, 0x48, 0x03, 0x69, 0xC7))
            out = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(fid), 0, None, ctypes.byref(out)) == 0:
                path = out.value
                ctypes.windll.ole32.CoTaskMemFree(out)
                if path and os.path.isdir(path):
                    return Path(os.path.realpath(path))
        except Exception:
            pass
    return Path(os.path.realpath(HOME / "Documents"))


# Hard safety root: the app only lists/opens files under here (never changed by settings).
DOCS = documents_dir()
DRC_HOME = Path(os.environ.get("DRC_HOME") or DOCS / "Dr. Claude")
CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0

DATA.mkdir(parents=True, exist_ok=True)
CHATS.mkdir(exist_ok=True)
DRC_HOME.mkdir(parents=True, exist_ok=True)
TOKEN_FILE = DATA / "canvas_token.bin"
GEMINI_KEY_FILE = DATA / "gemini_key.bin"
logging.basicConfig(filename=str(DATA / "app.log"), level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("drclaude")

STATUS = ["✅", "🟡", "❌", "⬜"]  # solid, shaky, not yet, not practiced
MODES = ["Lecture", "Homework", "Quiz", "Mock Exam", "Office Hours", "Replay a Course", "Log a Class"]
STUDY_MODES = set(MODES) - {"Log a Class"}


# ----------------------------------------------------------------------------- settings
def find_edge():
    for p in [os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)") + r"\Microsoft\Edge\Application\msedge.exe",
              os.environ.get("ProgramFiles", r"C:\Program Files") + r"\Microsoft\Edge\Application\msedge.exe"]:
        if os.path.isfile(p):
            return p
    return shutil.which("msedge") or ""


DEFAULTS = {
    "theme": "system",  # system | light | dark
    "hub": str(DRC_HOME),
    "edge": find_edge(),
    "logpose": True,             # the built-in study timer
    "brain": "",                 # "codex" | "gemini" ("" = not chosen yet)
    "codex_path": "",            # blank = find it
    "codex_sandbox": "workspace-write",  # or "read-only"
    "codex_model": "",
    "gemini_model": "",          # blank = newest Flash model the key can use
    "auto_update": True,         # install downloaded updates the next time the app starts
    "update_url": "",            # blank = the built-in update link (update_config.json)
    "voice_model": "",           # "" = voice upgrade not installed; "small.en" | "large-v3-turbo"
    "voice_conf": True,          # voice confidence reader (ON by default since v1.4.4): numbers only, audio never saved
    "voice_auto_done": False,    # v1.4.4: voice turned on automatically once; after that the student's choice sticks
}
SETTINGS_FILE = DATA / "settings.json"
_lock = threading.RLock()


def load_settings():
    s = dict(DEFAULTS)
    try:
        s.update(json.loads(SETTINGS_FILE.read_text(encoding="utf-8")))
    except Exception:
        pass
    if not s.get("edge"):
        s["edge"] = DEFAULTS["edge"]
    s["hub"] = str(DRC_HOME)  # fixed: everything of hers lives here
    return s


SETTINGS = load_settings()


def manifest_url():
    if os.environ.get("DRC_UPDATE_URL"):
        return os.environ["DRC_UPDATE_URL"]
    if SETTINGS.get("update_url"):
        return SETTINGS["update_url"]
    try:
        u = json.loads((APP_DIR / "update_config.json").read_text(encoding="utf-8")).get("manifest_url", "")
        return "" if "PASTE" in u else u
    except (OSError, ValueError):
        return ""


IDEAS = ideas.Box(DATA, VERSION, lambda: load_profile().get("name", ""), manifest_url)
UPDATE = updates.Updater(APP_DIR, INSTALL, VERSION, manifest_url(), log) if INSTALL else None


def save_settings(new):
    with _lock:
        for k, v in new.items():
            if k in DEFAULTS:
                SETTINGS[k] = bool(v) if isinstance(DEFAULTS[k], bool) else str(v)
        SETTINGS_FILE.write_text(json.dumps(SETTINGS, indent=2), encoding="utf-8")
    return SETTINGS


# ----------------------------------------------------------------------------- safety
def under_docs(p):
    """Return the real path if it is inside Documents, else raise PermissionError."""
    rp = os.path.realpath(str(p))
    nc = os.path.normcase(rp)
    for root in {os.path.normcase(str(DOCS)), os.path.normcase(os.path.realpath(str(DRC_HOME)))}:
        if nc == root or nc.startswith(root + os.sep):
            return Path(rp)
    raise PermissionError("Only files inside Documents can be opened.")


# ----------------------------------------------------------------------------- markdown helpers
def read_text(p):
    try:
        return Path(p).read_text(encoding="utf-8-sig", errors="replace")
    except Exception:
        return ""


def md_sections(text):
    """Split on level-2 headings. Returns [(heading or None, body)]."""
    res, cur, buf, in_code = [], None, [], False
    for line in text.splitlines():
        if line.strip().startswith("```"):
            in_code = not in_code
        if not in_code and re.match(r"^##\s", line):
            res.append((cur, "\n".join(buf)))
            cur, buf = line[3:].strip(), []
        else:
            buf.append(line)
    res.append((cur, "\n".join(buf)))
    return res


def find_section(text, *prefixes):
    for h, b in md_sections(text):
        if h and any(h.lower().startswith(p.lower()) for p in prefixes):
            return h, b.strip()
    return None, ""


def split_row(line):
    s = line.strip()
    if s.startswith("|"):
        s = s[1:]
    if s.endswith("|") and not s.endswith("\\|"):
        s = s[:-1]
    return [c.strip() for c in re.split(r"(?<!\\)\|", s)]


SEP_RE = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")


def md_tables(text):
    lines, out, i = text.splitlines(), [], 0
    while i < len(lines) - 1:
        if "|" in lines[i] and SEP_RE.match(lines[i + 1]):
            header, rows = split_row(lines[i]), []
            i += 2
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                rows.append(split_row(lines[i]))
                i += 1
            out.append((header, rows))
        else:
            i += 1
    return out


def plain(s):
    s = re.sub(r"[*`_]", "", s or "")
    return re.sub(r"\s+", " ", s).strip()


def short_topic(s, n=48):
    s = plain(s)
    s = re.split(r"\s\(", s)[0]
    return s if len(s) <= n else s[: n - 1].rstrip() + "…"


def mastery_from_text(text):
    counts = {k: 0 for k in STATUS}
    topics = []
    for header, rows in md_tables(text):
        mi = next((k for k, h in enumerate(header) if "mastery" in h.lower()), None)
        if mi is None:
            continue
        ti = next((k for k, h in enumerate(header) if h.lower().strip() in ("topic", "topics")), 0)
        for r in rows:
            if mi >= len(r):
                continue
            cell, st, pos = r[mi], None, 10 ** 9
            for s in STATUS:
                p = cell.find(s)
                if p != -1 and p < pos:
                    st, pos = s, p
            if st:
                counts[st] += 1
                topics.append({"topic": short_topic(r[ti] if ti < len(r) else ""), "status": st})
    return counts, topics


# ----------------------------------------------------------------------------- courses
def course_code(name):
    m = re.match(r"^\s*([A-Z]{2,4})\s?(\d{4}[A-Z]?)", name)
    return f"{m.group(1)} {m.group(2)}" if m else None


_course_cache = {"t": 0, "v": []}
COURSES_FILE = DRC_HOME / "courses.json"


def load_courses(force=False):
    """Courses come from Canvas (courses.json, written by canvas_sync) plus any added by hand."""
    if not force and time.time() - _course_cache["t"] < 3:
        return _course_cache["v"]
    try:
        idx = json.loads(COURSES_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        idx = {}
    courses = []
    for c in idx.get("courses", []):
        rec = Path(c.get("record") or "")
        courses.append({
            "id": c["id"], "code": c["code"], "title": c.get("title", ""), "name": c.get("name", c["code"]),
            "term": c.get("term", ""), "professor": c.get("professor", ""), "past": False, "manual": bool(c.get("manual")),
            "record": str(rec) if c.get("record") and rec.exists() else "", "mastery_file": "",
            "folder": c.get("folder", ""), "canvas_id": c.get("canvas_id"),
        })
    _course_cache.update(t=time.time(), v=courses)
    return courses


def past_course_folders():
    return []


def add_manual_course(code, title, professor=""):
    """A course without Canvas (she uploads her own files): folder + blank Course Record."""
    code = re.sub(r"\s+", " ", (code or "").strip().upper())
    title = (title or "").strip()
    if not code:
        raise ValueError("Give the class a code, like ARO 1011L.")
    cid = re.sub(r"[^A-Z0-9]", "", code) or "COURSE"
    folder = DRC_HOME / canvas_sync.safe_name(f"{cid} {title}".strip())
    (folder / "My Files").mkdir(parents=True, exist_ok=True)
    record = folder / f"{cid} Course Record.md"
    if not record.exists():
        tpl = canvas_sync.course_record(code, title or code, "(not on Canvas)", "", "?", professor or "?", [], {}, [], None, folder, False)
        record.write_text(tpl.replace("Started automatically from Canvas", "Started by hand (no Canvas)"), encoding="utf-8")
    with _lock:
        try:
            idx = json.loads(COURSES_FILE.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            idx = {"courses": []}
        idx["courses"] = [c for c in idx.get("courses", []) if c["id"] != cid] + [{
            "id": cid, "code": code, "title": title or code, "name": f"{code} {title}".strip(), "term": "", "professor": professor,
            "folder": str(folder), "record": str(record), "manual": True}]
        COURSES_FILE.write_text(json.dumps(idx, indent=1, ensure_ascii=False), encoding="utf-8")
    load_courses(force=True)
    return cid


GUIDE_ID = "DRC101"
GUIDE_SRC = APP_DIR / "guide" / "Dr Claude Guide.md"


def guide_text():
    return read_text(GUIDE_SRC)


def ensure_guide_course():
    """Built-in class "DRC 101": how to use Dr. Claude, Codex and AI. The guide ships with the app (so updates refresh it)
    and is copied into the class's My Files, where the tutor reads it like any class file."""
    if not GUIDE_SRC.exists():
        return
    try:
        c = get_course(GUIDE_ID)
        if not c:
            add_manual_course("DRC 101", "How to use Dr. Claude & AI")
            c = get_course(GUIDE_ID)
        dest = Path(c["folder"]) / "My Files" / GUIDE_SRC.name
        if read_text(dest) != guide_text():
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(GUIDE_SRC, dest)
    except Exception as e:  # never block startup over the guide
        log.warning("guide course: %r", e)


def get_course(cid):
    for c in load_courses():
        if c["id"] == cid or c["code"] == cid:
            return c
    return None


def course_facts(c):
    _, facts = find_section(read_text(c["record"]), "Course facts") if c.get("record") else (None, "")
    out = {}
    for header, rows in md_tables(facts)[:1]:
        for r in rows:
            if len(r) >= 2:
                out[plain(r[0]).lower()] = plain(r[1])
    return out


def course_mastery(c):
    if c.get("mastery_file"):
        return mastery_from_text(read_text(c["mastery_file"]))
    if c.get("record"):
        _, sec = find_section(read_text(c["record"]), "Mastery")
        return mastery_from_text(sec)
    return {k: 0 for k in STATUS}, []


# ----------------------------------------------------------------------------- study game data
def parse_time(t):
    t = (t or "").strip()
    for fmt in ("%I:%M %p", "%I %p", "%H:%M"):
        try:
            return dt.datetime.strptime(t, fmt).time()
        except ValueError:
            pass
    return None


def load_deadlines():
    """Due dates from Canvas (deadlines.json, rewritten on every sync)."""
    out = []
    try:
        rows = json.loads((DRC_HOME / "deadlines.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        rows = []
    for r in rows:
        try:
            d = dt.date.fromisoformat((r.get("date") or "").strip())
        except ValueError:
            continue
        tm = parse_time(r.get("time"))
        out.append({
            "date": d.isoformat(), "time": (r.get("time") or "").strip(),
            "title": (r.get("title") or "").strip(), "class": (r.get("class") or "").strip(),
            "kind": (r.get("kind") or "").strip().lower(),
            "_sort": dt.datetime.combine(d, tm or dt.time(23, 59, 59)),
        })
    out.sort(key=lambda x: x["_sort"])
    return out


def upcoming_deadlines(today=None):
    today = today or dt.date.today()
    res = []
    for d in load_deadlines():
        if d["kind"] == "holiday" or dt.date.fromisoformat(d["date"]) < today:
            continue
        days = (dt.date.fromisoformat(d["date"]) - today).days
        x = {k: v for k, v in d.items() if k != "_sort"}
        x["days"] = days
        x["when"] = "Today" if days == 0 else "Tomorrow" if days == 1 else f"in {days} days"
        res.append(x)
    return res


def is_test(d):
    return d["kind"] == "exam" or re.search(r"\b(quiz|midterm|final|exam|test)\b", d["title"], re.I)


STUDY_LOG = DATA / "study_sessions.csv"


def load_sessions_csv():
    p = STUDY_LOG
    rows = []
    try:
        with open(p, encoding="utf-8-sig", newline="") as f:
            for r in csv.DictReader(f):
                try:
                    rows.append({"date": dt.date.fromisoformat(r["date"].strip()), "class": (r.get("class") or "").strip(),
                                 "min": float(r.get("focused_min") or 0)})
                except (ValueError, KeyError):
                    pass
    except FileNotFoundError:
        pass
    return rows


def load_bounty():
    """Study totals for the home screen (today, this week, day streak) from the built-in timer's log."""
    rows = load_sessions_csv()
    today = dt.date.today()
    week0 = today - dt.timedelta(days=today.weekday())
    days = {r["date"] for r in rows if r["min"] >= 5}
    streak, d = 0, today if today in days else today - dt.timedelta(days=1)
    while d in days:
        streak += 1
        d -= dt.timedelta(days=1)
    return {"todayMin": round(sum(r["min"] for r in rows if r["date"] == today)),
            "weekMin": round(sum(r["min"] for r in rows if r["date"] >= week0)),
            "streakDays": streak, "running": bool(TIMER.get("start"))}


# ----------------------------------------------------------------------------- dashboard
def build_dashboard():
    today = dt.date.today()
    courses = [c for c in load_courses() if not c["past"] and c["id"] != GUIDE_ID]
    up = upcoming_deadlines(today)
    sess = load_sessions_csv()
    week0 = today - dt.timedelta(days=today.weekday())
    prev0 = week0 - dt.timedelta(days=7)
    classes = [c["code"] for c in courses]
    weekly = []
    for code in classes + sorted({s["class"] for s in sess} - set(classes)):
        this = sum(s["min"] for s in sess if s["class"] == code and s["date"] >= week0)
        last = sum(s["min"] for s in sess if s["class"] == code and prev0 <= s["date"] < week0)
        if code in classes or this or last:
            weekly.append({"class": code, "this": round(this, 1), "last": round(last, 1)})

    cards = []
    for c in courses:
        counts, topics = course_mastery(c)
        nxt = next((d for d in up if d["class"] == c["code"]), None)
        studied = [s["date"] for s in sess if s["class"] == c["code"]]
        last = max(studied) if studied else None
        facts = course_facts(c)
        cards.append({
            "id": c["id"], "code": c["code"], "title": c["title"], "professor": c["professor"],
            "meets": facts.get("meets", ""), "counts": counts, "topics": topics,
            "next": nxt, "last_studied": last.isoformat() if last else None,
            "last_studied_days": (today - last).days if last else None,
            "has_mastery_file": bool(c["mastery_file"]),
        })

    return {
        "today": today.isoformat(),
        "deadlines": up[:3],
        "bounty": load_bounty(),
        "weekly": weekly,
        "week_start": week0.isoformat(),
        "courses": cards,
        "plan": build_plan(cards, up, today),
    }


def weak_list(topics, order):
    rank = {s: i for i, s in enumerate(order)}
    ts = [t for t in topics if t["status"] in rank]
    ts.sort(key=lambda t: rank[t["status"]])
    return ts


def build_plan(cards, up, today):
    """Simple rules, explained in plain words."""
    plan, used = [], set()
    by_code = {c["code"]: c for c in cards}
    # Rule 1: a quiz/exam within 10 days beats everything.
    for d in up:
        c = by_code.get(d["class"])
        if c and is_test(d) and d["days"] <= 10:
            weak = weak_list(c["topics"], ["❌", "⬜", "🟡"])[:3]
            names = ", ".join(f"{t['status']} {t['topic']}" for t in weak) or "the topics on the Assessment Log"
            mode = "Mock Exam" if d["days"] >= 4 else "Quiz"
            plan.append({
                "course": c["id"], "code": c["code"], "mode": mode,
                "title": f"{c['code']}: get ready for {d['title']}",
                "why": f"It's {d['when'].lower()} ({fmt_date(d['date'])}{', ' + d['time'] if d['time'] else ''}). "
                       f"That's your nearest test, so it comes first. Start with what you know least: {names}.",
            })
            used.add(c["code"])
            break
    # Rule 2: something due in the next 2 days.
    for d in up:
        if d["days"] <= 2 and d["class"] in by_code and not is_test(d) and d["class"] not in used:
            c = by_code[d["class"]]
            plan.append({
                "course": c["id"], "code": c["code"], "mode": "Office Hours",
                "title": f"{c['code']}: finish {d['title']}",
                "why": f"Due {d['when'].lower()}{' at ' + d['time'] if d['time'] else ''}. Finish it a day early if you can. "
                       "Open Office Hours if you get stuck.",
            })
            used.add(c["code"])
            break
    # Rule 3: the class with the most shaky / not-yet topics.
    def weakness(c):
        k = c["counts"]
        return k["❌"] * 3 + k["🟡"] * 2 + k["⬜"] * 1
    rest = sorted([c for c in cards if c["code"] not in used and weakness(c) > 0], key=weakness, reverse=True)
    if rest:
        c = rest[0]
        weak = weak_list(c["topics"], ["❌", "🟡", "⬜"])[:2]
        plan.append({
            "course": c["id"], "code": c["code"], "mode": "Quiz",
            "title": f"{c['code']}: firm up shaky topics",
            "why": f"This class has the most topics that aren't solid yet ({c['counts']['❌']} ❌, {c['counts']['🟡']} 🟡, "
                   f"{c['counts']['⬜']} ⬜). Quiz yourself on: " + ", ".join(f"{t['status']} {t['topic']}" for t in weak) + ".",
        })
        used.add(c["code"])
    # Rule 4: a class you haven't studied in a while.
    stale = [c for c in cards if c["code"] not in used and (c["last_studied_days"] is None or c["last_studied_days"] >= 7)]
    if stale and len(plan) < 3:
        c = stale[0]
        ago = "never with the timer" if c["last_studied_days"] is None else f"{c['last_studied_days']} days ago"
        plan.append({
            "course": c["id"], "code": c["code"], "mode": "Lecture",
            "title": f"{c['code']}: catch up on the newest lecture",
            "why": f"Last studied {ago}. A short Lecture session keeps you at the same pace as the real class.",
        })
    return plan[:3]


def fmt_date(iso):
    d = dt.date.fromisoformat(iso)
    return d.strftime("%a %b ") + str(d.day)


# ----------------------------------------------------------------------------- course detail
def course_detail(c):
    rec = read_text(c["record"]) if c.get("record") else ""
    sec = {}
    if rec:
        parts = []
        for name in ("Course facts", "Source files", "Course Summary", "Session log"):
            h, b = find_section(rec, name)
            if h:
                parts.append(f"## {h}\n{b}")
        sec["overview"] = "\n\n".join(parts)
        for key, names in (("pacing", ("Pacing Calendar",)), ("assessments", ("Assessment Log",)),
                           ("patterns", ("Professor patterns", "Prof patterns"))):
            h, b = find_section(rec, *names)
            sec[key] = f"## {h}\n{b}" if h else ""
    if c.get("mastery_file"):
        sec["mastery"] = read_text(c["mastery_file"])
    else:
        h, b = find_section(rec, "Mastery")
        sec["mastery"] = f"## {h}\n{b}" if h else ""
    if c.get("folder"):
        sec["timeline"] = read_text(Path(c["folder"]) / "Canvas Calendar.md")
    counts, topics = course_mastery(c)
    return {"course": c, "sections": sec, "counts": counts, "topics": topics}


# ----------------------------------------------------------------------------- library
QUICK_DIRS = ["Canvas Files", "Learning", "Class Notes", "Canvas Export", "Start Here", "Code", "Readings"]


def list_dir(path):
    p = under_docs(path)
    if not p.is_dir():
        raise FileNotFoundError(str(p))
    items = []
    for e in os.scandir(p):
        name = e.name
        if name.lower() in ("desktop.ini", "thumbs.db") or name.startswith(("~$", ".")):
            continue
        try:
            st = e.stat()
            items.append({"name": name, "path": e.path, "dir": e.is_dir(), "size": 0 if e.is_dir() else st.st_size,
                          "mtime": dt.datetime.fromtimestamp(st.st_mtime).isoformat(timespec="minutes")})
        except OSError:
            pass
    items.sort(key=lambda x: (not x["dir"], x["name"].lower()))
    return {"path": str(p), "items": items}


def search_files(root, q, limit=300):
    root = under_docs(root)
    terms = [t for t in q.lower().split() if t]
    res = []
    if not terms:
        return res
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d != "edge-profile"]
        for n in dirnames + filenames:
            if n.lower() == "desktop.ini":
                continue
            if all(t in n.lower() for t in terms):
                full = os.path.join(dirpath, n)
                res.append({"name": n, "path": full, "dir": n in dirnames,
                            "rel": os.path.relpath(full, root)})
                if len(res) >= limit:
                    return res
    return res


def open_path(path, how):
    p = under_docs(path)
    if not p.exists():
        raise FileNotFoundError(str(p))
    if how == "notepad":
        if p.is_dir():
            raise ValueError("That's a folder.")
        subprocess.Popen(["notepad.exe", str(p)])
    elif how == "reveal":
        subprocess.Popen(["explorer.exe", "/select,", str(p)])
    else:
        os.startfile(str(p))  # default app (or Explorer for folders)


# ----------------------------------------------------------------------------- sessions store
SESSIONS_FILE = DATA / "sessions.json"


def load_sessions():
    try:
        return json.loads(SESSIONS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return []


def save_session(meta):
    with _lock:
        ss = [s for s in load_sessions() if s["id"] != meta["id"]]
        ss.append(meta)
        ss.sort(key=lambda s: s.get("updated", ""), reverse=True)
        SESSIONS_FILE.write_text(json.dumps(ss, indent=2, ensure_ascii=False), encoding="utf-8")


def get_session(sid):
    return next((s for s in load_sessions() if s["id"] == sid), None)


def chat_file(sid):
    if not re.fullmatch(r"[0-9a-f-]{36}", sid or ""):
        raise ValueError("bad session id")
    return CHATS / f"{sid}.json"


def load_chat(sid):
    try:
        return json.loads(chat_file(sid).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []


def append_chat(sid, *msgs):
    with _lock:
        msgs_all = load_chat(sid) + list(msgs)
        chat_file(sid).write_text(json.dumps(msgs_all, indent=1, ensure_ascii=False), encoding="utf-8")


# ----------------------------------------------------------------------------- built-in study timer
# Study modes start it; the tutor's [[timer ...]] markers keep it alive; "end" (or 20 idle minutes) banks the
# minutes into data\study_sessions.csv, which feeds the home screen (today / this week / streak).
TIMER = {"active": {}, "last": "", "start": None, "cls": "", "seen": None}
IDLE_MIN = 20


def _bank():
    s, seen = TIMER.get("start"), TIMER.get("seen")
    if not s:
        return 0.0
    end = min(time.time(), (seen or s) + IDLE_MIN * 60)
    mins = max(0.0, (end - s) / 60)
    if mins >= 1:
        new = not STUDY_LOG.exists()
        with open(STUDY_LOG, "a", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            if new:
                w.writerow(["date", "class", "focused_min", "start", "end"])
            w.writerow([dt.date.fromtimestamp(s).isoformat(), TIMER.get("cls", ""), round(mins, 1),
                        dt.datetime.fromtimestamp(s).strftime("%H:%M"), dt.datetime.fromtimestamp(end).strftime("%H:%M")])
    TIMER.update(start=None, seen=None)
    return mins


def logpose(action, cls="", minutes=None, text=""):
    """Built-in study timer (the name is kept so the old call sites still work)."""
    now = time.time()
    with _lock:
        if TIMER.get("start") and TIMER.get("seen") and now - TIMER["seen"] > IDLE_MIN * 60:
            _bank()  # walked away: bank only the real part
        if action == "start":
            if TIMER.get("start") and cls and cls != TIMER.get("cls"):
                _bank()
            if not TIMER.get("start"):
                TIMER.update(start=now, cls=cls)
            TIMER["seen"] = now
            out = f"Study timer started ({cls})"
        elif action in ("problem", "clear"):
            if TIMER.get("start"):
                TIMER["seen"] = now
            out = "Timer running" if TIMER.get("start") else "Timer not running"
        elif action == "end":
            m = _bank()
            out = f"Study session saved: {m:.0f} min." if m >= 1 else "Study session ended."
        else:
            b = load_bounty()
            out = (f"Today: {b['todayMin']} min · this week: {b['weekMin']} min · streak: {b['streakDays']} day(s)"
                   + (" · timer running" if TIMER.get("start") else ""))
    TIMER["last"] = out
    log.info("timer %s %s -> %s", action, cls, out)
    return out


def logpose_async(*a, **k):
    threading.Thread(target=logpose, args=a, kwargs=k, daemon=True).start()


MARKER_RE = re.compile(r"\[\[\s*(?:logpose|timer)\s+(problem\s+(\d+(?:\.\d+)?)|clear|end)\s*\]\]", re.I)
RECORD_RE = re.compile(r"```record-update\s*\n(.*?)```", re.S)


def strip_markers(text):
    text = RECORD_RE.sub("", text)
    return re.sub(r"[ \t]*\[\[\s*(?:logpose|timer)[^\]]*\]\][ \t]*\n?", "", text).rstrip()


# ----------------------------------------------------------------------------- her profile + learning style
PROFILE_FILE = DRC_HOME / "profile.json"
RULES = rules.Rules(DRC_HOME / "Profile")
PREFS = [  # key, label shown in the app, rule given to the tutor
    ("learning_mode", "Teach me: I try first, then you check",
     "Learning mode: the student attempts practice and homework problems first; you check and explain. Don't hand over answers right away."),
    ("one_q", "One question at a time",
     "Ask ONE question per message, with nothing else in it except feedback on the last answer."),
    ("retry", "Wrong answer = hint + retry the same question",
     "When an answer is wrong, give a hint or name the specific mistake, then have them retry the SAME question until it's right. Loop back to it later to check it stuck."),
    ("full_data", "Re-show all the data in every question",
     "Every question re-shows the FULL given data (whole table, equation, figure), never a partial one. State every assumption up front in bold."),
    ("labels", "Label every question (▶ NOW: Q1 …)",
     "Every practice question starts with its own heading line: ## ▶ NOW: <ID> · <short name> (⏱ N min). Feedback starts with ### ✔ <ID> check or ### ❌ <ID>: not yet. Refer to other questions by ID. Never two questions in one message."),
    ("visuals", "Diagrams + “Picture it” scenes",
     "Every new idea gets a '🎬 Picture it:' line with a concrete scene they can imagine, plus ASCII diagrams, tables, and '?' fill-in slots (inside ``` code blocks)."),
    ("steps", "Step-by-step animations",
     "For any method with 3+ steps, show it as a ```steps animation (format below). Don't animate the answer to a question they haven't tried yet."),
    ("memory", "Memory tricks (after the real explanation)",
     "Add a '🧠 Memory trick:' (acronym, rhyme, image) AFTER the real explanation, never instead of it."),
    ("videos", "YouTube clips when they help",
     "When they ask their own question, are stuck after one hint, or a topic starts, and a video would genuinely help, add ONE ```video block (format below)."),
    ("why", "“Why this matters” for new topics",
     "Start each new topic with one short 'why this matters' line (real life, their major, jobs)."),
    ("checkins", "Ask me how the teaching is going",
     "About every 5 practice questions, ask ONE quick question about how the teaching is going, as its own message under the heading "
     "`### 💬 Teaching check-in`. Their answer goes to their Command page as a suggested new rule, so just thank them and carry on."),
]
PREF_GROUP = {"learning_mode": "Questions", "one_q": "Questions", "retry": "Questions", "full_data": "Questions", "labels": "Format",
              "visuals": "Visuals", "steps": "Visuals", "memory": "Visuals", "videos": "Visuals", "why": "Tone", "checkins": "Tone"}
PROFILE_DEFAULTS = {"name": "", "school": "Cal Poly Pomona", "major": "", "canvas_url": "https://canvas.cpp.edu",
                    "notes": "", "prefs": {k: True for k, _, _ in PREFS}, "onboarded": False}


def load_profile():
    p = json.loads(json.dumps(PROFILE_DEFAULTS))
    try:
        saved = json.loads(PROFILE_FILE.read_text(encoding="utf-8"))
        prefs = dict(p["prefs"], **(saved.get("prefs") or {}))
        p.update(saved)
        p["prefs"] = prefs
    except (OSError, ValueError):
        pass
    return p


def save_profile(new):
    with _lock:
        p = load_profile()
        for k in ("name", "school", "major", "canvas_url", "notes"):
            if k in new:
                p[k] = str(new[k]).strip()[:2000]
        if isinstance(new.get("prefs"), dict):
            for k, _, _ in PREFS:
                if k in new["prefs"]:
                    p["prefs"][k] = bool(new["prefs"][k])
        if "onboarded" in new:
            p["onboarded"] = bool(new["onboarded"])
        PROFILE_FILE.write_text(json.dumps(p, indent=1, ensure_ascii=False), encoding="utf-8")
        (DRC_HOME / "My Learning Profile.md").write_text(profile_md(p), encoding="utf-8")
        RULES.sync_prefs(p["prefs"], {k: rule for k, _, rule in PREFS}, PREF_GROUP)
        write_agents_md(p)
    return p


def who(p=None):
    return ((p or load_profile()).get("name") or "the student").strip()


def profile_md(p):
    on = [lab for k, lab, _ in PREFS if p["prefs"].get(k)]
    off = [lab for k, lab, _ in PREFS if not p["prefs"].get(k)]
    return (f"# My Learning Profile\n*Dr. Claude reads this every session. Edit it in the app (Settings → My profile).*\n\n"
            f"- Name: {p.get('name') or '?'}\n- School: {p.get('school') or '?'}\n- Major: {p.get('major') or '?'}\n\n"
            f"## How I like to learn\n" + "".join(f"- ✅ {x}\n" for x in on) + "".join(f"- ⬜ (off) {x}\n" for x in off)
            + (f"\n## In my own words\n{p['notes']}\n" if p.get("notes") else ""))


def teaching_rules(p, course=""):
    """The student's Teaching Rules (Command page) in force for this class; the setup toggles if there are none yet."""
    act = RULES.active(course)
    if act:
        text = rules.rules_for_prompt(act)
    else:
        text = "\n".join(f"- {rule}" for k, _, rule in PREFS if p["prefs"].get(k))
    if not any(r["id"] == "pref_learning_mode" for r in act) and not p["prefs"].get("learning_mode"):
        text = "- Explain mode: answer and explain clearly and directly; quiz only when they ask for it.\n" + text
    return text


STEPS_FMT = """```steps
title: <what this animates>
--- Step 1: <what happens in this step>
<ASCII picture with the current spot marked, e.g. [7] or <-- HERE>
--- Step 2: ...
<same-size picture>
```
(The app plays it like a video with Play / ◀ ▶. One frame per step.)"""

VIDEO_FMT = """```video
search: <specific YouTube search words for THIS exact moment, e.g. "round robin scheduling time quantum 3 gantt chart">
caption: <what to watch for, in a few words>
```
(The app finds the clip, trims it to just the part that answers this, and checks it, reusing a catalog of clips that grows and learns from 👍/👎. Never write a video id or a timestamp yourself.)
After they watch, the app asks them "How was this clip?". If they say it was the wrong part or the wrong video, ask in one short line what they were looking for, then write a new video block with sharper search words."""

RECORD_FMT = """```record-update
{"section": "Pacing Calendar", "rows": ["| 9 | 10/19–10/23 | BST delete, traversals | Ch. 10 | | Quiz 3 |"]}
```
Sections you may add to: "Pacing Calendar", "Assessment Log", "Professor patterns", "Mastery", "Session log".
"rows" = Markdown table rows matching that section's table; "lines" = bullet lines (for Professor patterns / Session log).
The app adds them to the Course Record and hides the block. Use one block per section, only for real, confirmed facts."""


AERO_TRAPS = """- Aerospace traps to check for: the "equal transit time" lift myth (air over the top does NOT have to meet the air underneath), Bernoulli vs. Newton as if only one were true (both describe the same flow), stall = the wing exceeding its critical angle of attack (NOT the engine stopping), mixing up static/dynamic/total pressure, forgetting units (slug vs lbm, ft vs m) and the standard-atmosphere values, and free-body diagrams with missing or doubled forces."""


def aero_traps(p):
    return AERO_TRAPS if "aero" in (p.get("major") or "").lower() else "- Field traps: check the classic misconceptions of this subject before moving on."


def professor_rules(p, course=""):
    n = who(p)
    return f"""You are Dr. Claude, {n}'s personal professor and study tutor: a patient, cheap version of college.
{n} is a student at {p.get('school') or 'college'}{(' studying ' + p['major']) if p.get('major') else ''} who wants to actually learn the material, not just get answers.
Refer to {n} by name or as "you"; if you need a pronoun, use they/them.

You have two jobs:
1. Registrar. Keep an honest record of what each real class covers, week by week, and what every quiz and exam looks like, in that class's Course Record. Never invent dates, scores or topics: unknown = `?` plus where to check.
2. Professor. Teach, quiz and test using that record: the same topics, in the same order and pace, in the same style as the real professor (past quizzes in the Canvas files are gold: professors reuse them).

Where things are (all inside {DRC_HOME}):
- My Learning Profile.md: how {n} likes to learn. Follow it.
- <course folder>\\<CODE> Course Record.md: course facts, Pacing Calendar, Assessment Log, Professor patterns, Mastery, Session log.
- <course folder>\\Canvas Calendar.md, Assignments.md, Modules.md, Syllabus.html, Canvas Files\\, Canvas Pages\\, My Files\\ (uploads).
- Thoughts\\<CODE>.md: things {n} noticed or got confused by. Use them.
- Gradebook\\<CODE>.md: mock quiz/exam scores (date, score, what was missed, mistake type).
- Profile\\Teaching Rules.md: {n}'s own Teaching Rules (set on the app's Command page). Re-read it before EVERY reply: it changes between turns.

{n}'s Teaching Rules. They OVERRIDE every default below and anything earlier in the chat; follow them exactly:
{teaching_rules(p, course)}
- Beginner level by default; fill in missing basics as they come up. Give every practice question an expected solve time (recall 2-3 min, single-step 4-6, multi-step 8-15).
- Park off-topic questions ("good question, parking it") and come back to useful ones after the current block.

How to teach (evidence-based defaults, from learning-science research; the Teaching Rules above still win on any clash):
- Professor depth, beginner door: every concept climbs 4 rungs. 🎬 a picture anyone can imagine → ⚙️ the system (inputs → process → outputs) → 🎓 professor level (the formal definition, a derivation of WHY it must be true, edge cases, how a real exam asks it) → 🏭 where it shows up in the real world (their major, labs, jobs). Never stop at analogies; never open with the formal version.
- Study session shape: a 3-line plan, then 2-3 quick recall questions on older topics (no notes), 1-2 pretest questions on the new topic ("wrong is expected and helps"), short teaching chunks (6 minutes of reading or less, each ending in something they do), ONE worked example with labeled steps, then the same type with steps left blank, then practice, one mixed-in look-alike problem ("which method, and why?" before solving), one problem solved with ZERO hints, and a 2-4 sentence explain-back. Re-ask the pretest at the end.
- Hint ladder, one rung at a time: a pointing question → name the rule → show the first step → a worked example of a SIMILAR problem → the full solution plus a fresh problem they solve alone. After 2-3 hints, or if they're frustrated, jump to the similar worked example. After the final attempt, always show the correct answer and why.
- Never ask "does that make sense?" (people say yes either way). Ask a quick check question instead. On quizzes, ask "how sure, 1-3?" before they answer; "sure but wrong" answers get a callout and come back later.
- Never solve a real graded homework, lab or take-home problem for them: teach it on a twin problem.
- Check the math before calling an answer wrong: solve it two ways and check units and limiting cases.
- Spaced review: keep <course folder>\\Review Queue.md (columns: ID | Concept | Card | Due | Interval | Streak | Source). Add every missed question, every problem that needed a lot of hints, and every "sure but wrong" answer. Schedule 1 day → 3 → 7 → 21 → 60; a miss goes back to 1 day. Ask due cards at the start of sessions.
- Free guest lectures: when a topic starts, point to one specific free lecture (MIT OpenCourseWare, NASA Glenn's Beginner's Guide to Aeronautics, Professor Leonard, 3Blue1Brown, Khan Academy, OpenStax) with a "watch for:" line and 2 questions to answer after watching. A video is never the whole lesson.
{aero_traps(p)}
- Say once at the start of a new course: "Active learning feels harder than watching someone explain, but studies show it works about 2x better. If it feels hard, it's working."
- After a session, update Mastery marks (✅ solid · 🟡 shaky · ❌ not yet · ⬜ not practiced) and add a one-line Session log entry.

Teaching every kind of student (sourced: CAST UDL 3.0, IES/WWC practice guide, Berkeley/Yale/Michigan teaching centers, UW DO-IT, Ramirez et al. 2018, Pashler et al. 2008):
- Two ways in, two ways out: every concept gets words + a picture or an example + the rule, and they may answer by typing, voice, a sketch, or picking from options. Never ask or assume a "learning style" (no good evidence for matching).
- First session with a new student, ask once: "Anything that helps you learn best? (shorter steps, more pictures, voice, extra time)". Never ask for a diagnosis; for formal accommodations, point them to their school's disability office.
- If they struggle with reading, focus or anxiety: one short step per message, re-show the full problem each time, no time pressure in practice, a predictable session shape, announce changes before they happen, and offer a break when replies show strain.
- English learners: plain words, define terms in a mini glossary, thinking or taking notes in their strongest language is fine (offer a Spanish explanation if they want it), and judge the engineering/science, never the grammar.
- First-generation students: make the structure visible (what we're doing, why, what "good" looks like) and explain unwritten college rules (office hours, how exams are graded) when they come up.
- Low confidence or math anxiety: talk about process ("which step next?"), never ability; never call a topic scary or say some people "just get it". Before a quiz, they may write 2 lines about what worries them.
- Advanced students: check what they already know first, skip examples they don't need, and push harder with a "why" or an extension question.
- Voice: answering out loud is often easier and shows how sure they are; treat pauses or "um"s as a gentle hint only, compare to that student's own normal, and never comment on how someone talks.
- A message may end with a hidden "[voice read (hint only): likely SURE / MIXED / UNSURE: ...]" note, made by comparing how they said it to their OWN usual voice. Combine it with whether the answer is right: sure + wrong = a likely misconception, so add it to the Review Queue first (Source: sure-but-wrong) and explain why the tempting answer fails; unsure + right = fragile, so add a card due tomorrow; unsure + wrong = teach it again; sure + right = normal spacing. If the note says calibrate: BEFORE saying whether it's right, ask "how sure were you, 1-5?", and when they answer, end that reply with [[voicecal sure=N correct=yes|no]] (the app hides it). NEVER mention the voice read, and never comment on how someone talks, pauses or stutters: it's a hint, not a verdict."""


TALK_STYLE = """How to talk (this is a chat with a student, NOT a coding task):
- Write like a friendly professor talking face to face: plain sentences, short paragraphs, everyday words. Explain any jargon the first time you use it.
- Never put your answer or explanation inside a code block, and never reply in JSON, YAML or code-style formatting. A ``` block is ONLY for real code the student is studying, or an ASCII diagram.
- Math: write it in plain text with Unicode symbols (3 × 4 = 12, x², √2, π, Δv, ∫ f(x) dx, ≤, ≠), never LaTeX ($…$, \\frac, \\(…\\)) because the app can't draw LaTeX. Put a big equation on its own line.
- Never mention files, folders, paths, commands, the terminal, the sandbox, AGENTS.md, or what you read or edited behind the scenes. No "Summary of changes", no file citations, no line numbers. If you updated their record, say it in plain words at most once ("I noted that in your course record").
- Bold the one idea that matters most. Use a short list or table only when it truly helps.
- Voice: they can answer out loud (hold Space, or the 🎤 button). If they have only typed so far, once per session (not more) suggest saying the next answer out loud, in one short friendly line.
- End with one clear next step or one question for them, not a menu of offers ("If you want, I can…")."""


def picture_rules(b):
    if b.key == "codex":
        how = ("When a real picture would help (a labeled diagram of a wing, a free-body diagram, a circuit, a graph, a concept sketch), "
               "draw it with your built-in image generation tool. The app shows every picture you make right in this chat by itself, "
               "so never tell them to open a folder or a file, and never print a file path. Keep labels big and few. "
               "If they ask for a picture and you can't make one, say so plainly.")
    else:
        how = ("When a real picture would help (a labeled diagram, a free-body diagram, a graph, a concept sketch), ask the app to draw it "
               "by writing this block on its own (the app replaces it with the picture in this chat):\n```image\n"
               "prompt: <a clear description: what to draw, the labels, the style, e.g. 'clean textbook diagram, white background'>\n```")
    return "Pictures: " + how + " Use pictures when they teach; at most 2 per reply."


MAKE_RULES = ("Files you can make for them: a web page (.html: an interactive demo or a self-checking practice quiz), a printable PDF "
              "(cheat sheet, worked examples, practice set with an answer key), an animation (.gif), something to listen to (.mp3) "
              "or a short narrated video (.mp4). Many students don't know you can do this, so offer it: when you START a new topic, "
              "and whenever they're stuck (2+ misses or they say they're lost), end with ONE short line offering the single most useful "
              "format for this exact thing, e.g. \"Want me to make you a 1-page PDF cheat sheet of these rules?\" or "
              "\"Want a short animated GIF of push and pop?\". Don't offer again in the next few messages if they say no. "
              "When they say yes (or ask for any of these), write this block; the app builds the file and shows it right here "
              "in the chat with Open and Save buttons, so never tell them to look in a folder, and never write these files yourself:\n")


def app_prompt(p, b, course=""):
    parts = [professor_rules(p, course), "", TALK_STYLE, "",
             "You are running live inside the Dr. Claude desktop app; the student talks with you turn by turn.",
             "Formatting: replies are rendered as Markdown. Put every ASCII diagram, Gantt chart, stack, tree or bit layout inside a ``` code block. Use Markdown tables for tables.",
             picture_rules(b),
             "Chat attachments: the student can attach files and pictures to a message (homework photos, a worksheet, a screenshot). "
             "They belong to this chat only, not the class library. Look at them before answering, and refer to them by what they show, not by file name.",
             "Study timer: put ONE marker on its own line at the very end of a message: [[timer problem N]] right after you ask a practice question "
             "(N = expected minutes), [[timer clear]] when explaining with no question pending, [[timer end]] when the session wraps up. Never mention the marker."]
    if p["prefs"].get("steps"):
        parts += ["Step-by-step animation format:", STEPS_FMT]
    if p["prefs"].get("videos"):
        parts += ["Video format:", VIDEO_FMT]
    if b.can_edit:
        parts += ["Course Record updates: edit the Course Record / Gradebook / Thoughts files directly (you have write access to the Dr. Claude folder only)."]
    else:
        parts += ["Course Record updates: you can't edit files here, so when you learn a real fact for the record (what a class covered, a quiz format, a score, a mastery change), "
                  "end your message with a block like this:", RECORD_FMT]
    parts += [MAKE_RULES + maker.MAKE_FMT]
    parts += ["Questions about the app itself (screens, Canvas sync, the calculator, the Ideas box), Codex, Codex in Chrome, or how to write good AI prompts: "
              f"answer from the Dr. Claude Guide ({GUIDE_SRC}). The student can also open Guide in the left menu, or pick the DRC 101 class to ask about it.",
              "Files you can't open: if something isn't in the context you were given, say so and ask, never guess its contents.",
              "The student may voice-type: expect speech-to-text typos and read for meaning."]
    return "\n".join(parts)


def write_agents_md(p=None):
    """Codex reads AGENTS.md from its working folder: keep the professor's rules there too."""
    p = p or load_profile()
    try:
        (DRC_HOME / "AGENTS.md").write_text("# Dr. Claude: instructions for the AI tutor\n*Written by the Dr. Claude app from the learning profile. "
                                            "Edit the profile in the app instead of this file.*\n\n" + professor_rules(p) + "\n\n" + TALK_STYLE + "\n",
                                            encoding="utf-8")
    except OSError as e:
        log.warning("AGENTS.md: %s", e)


MODE_TEXT = {
    "Lecture": "Teach the NEXT topic from the Pacing Calendar (check the Course Record's Session log for where they are). Start with a short why-this-matters line, teach in small chunks with visuals, and check understanding with one question at a time.",
    "Homework": "Give a homework problem set like the real professor's, in learning mode: one problem at a time, they attempt first, you check it. Give an expected solve time for each. Keep the answer key to yourself.",
    "Quiz": "Give a quiz that mirrors the real quiz format from the Assessment Log (same length, style, open/closed book). Prefer real past quizzes in Canvas Files when the professor reuses them. One question at a time.",
    "Mock Exam": "Run a mock exam built like the real one (Assessment Log + Professor patterns + past exams). Say the time limit and rules first, then give the questions one at a time. Grade it at the end and log the score in the Gradebook.",
    "Office Hours": "Office hours: live Q&A. Ask what they're stuck on (one short question), then help with tiny steps and visuals.",
    "Replay a Course": "Replay this course: build or continue a replay syllabus (Replays\\<CODE> Replay Syllabus.md) from the Pacing Calendar and Assessment Log (ask the pace once: real pace, 2x, or crash course), then teach it week by week.",
    "Log a Class": "Registrar mode. They will tell you (or dictate) what today's real class covered. Ask only for what's missing (date, topics, any quiz/exam details), then update the Course Record's Pacing Calendar / Assessment Log. Keep replies short. This is not a study session.",
}


def kickoff_prompt(mode, c, text):
    n = who()
    lines = [f"Mode: {mode}. Course: {c['code']} {c['title']}.", MODE_TEXT.get(mode, ""),
             f"Today is {dt.date.today().strftime('%A, %B %d, %Y')}."]
    if mode in STUDY_MODES:
        lines.append("The app already started the study timer.")
    lines.append(f"{n}'s first message: {text}" if text else "Begin now.")
    return "\n".join(lines)


# ----------------------------------------------------------------------------- context the brain gets
TEXT_CACHE = filetext.TextCache(DATA / "textcache.json")
TEXT_EXTS = {".pdf", ".docx", ".pptx", ".txt", ".md", ".html", ".htm", ".csv"}


def course_files(c, limit=400):
    out = []
    if not c or not c.get("folder"):
        return out
    root = Path(c["folder"])
    for sub in ("Canvas Files", "My Files", "Canvas Pages"):
        for dirpath, _, files in os.walk(root / sub):
            for f in files:
                if f.startswith(".") or f.endswith(".part"):
                    continue
                out.append(Path(dirpath) / f)
                if len(out) >= limit:
                    return out
    return out


def _ask_ai_if_set(system, msg):
    if not SETTINGS.get("brain"):
        raise RuntimeError("no AI brain set up yet")
    return brain_once(system, msg)


SHELF = coursebooks.Shelf(DATA, lambda p: TEXT_CACHE.get(p, 40000) or "", _ask_ai_if_set)
_shelf_busy = threading.Lock()


def books_needs(fill_in_background=True):
    """Each real class: does it have its textbook, and which book(s) does the syllabus name?"""
    out = []
    for c in load_courses():
        if c["past"] or c["id"] == GUIDE_ID:
            continue
        st = SHELF.status(c, use_ai=False)
        out.append({"id": c["id"], "code": c["code"], "title": c["title"], **st})
    if fill_in_background and SETTINGS.get("brain") and not _shelf_busy.locked():
        def fill():  # the AI reads the "Required text: ..." lines into titles/authors, once per class until its files change
            with _shelf_busy:
                for c in load_courses():
                    if not c["past"] and c["id"] != GUIDE_ID:
                        try:
                            SHELF.status(c, use_ai=True)
                        except Exception as e:
                            log.warning("book scan %s: %r", c["id"], e)
        threading.Thread(target=fill, daemon=True).start()
    return out


def book_note(c):
    """One line for the tutor when the class has no textbook in its files yet."""
    if not TEXTBOOK_FINDER:
        return ""   # v1.4.5: finder removed from the public build
    if not c or c["id"] == GUIDE_ID:
        return ""
    try:
        st = SHELF.status(c, use_ai=False)
    except Exception:
        return ""
    if st["has_book"] or st["dismissed"]:
        return ""
    named = "; ".join(" ".join(x for x in (b.get("title") or "", ", ".join(b.get("authors") or []), b.get("edition") or "",
                                            ("ISBN " + b["isbn"]) if b.get("isbn") else "") if x) for b in st["books"])
    return ("This class has NO textbook in its files yet" + (f" (the syllabus names: {named})" if named else "") +
            ". If a book would help with what you're teaching, mention it ONCE in a short line: they can add it in "
            "Library → 📕 Find a textbook (Dr. Claude searches for it and shows them the link first). Then teach from the slides and notes you have.")


def build_ctx(c, user_msg, b, first):
    folder = Path(c["folder"]) if c and c.get("folder") else DRC_HOME
    paths = [str(DRC_HOME / "My Learning Profile.md"), str(DRC_HOME / "AGENTS.md")]
    for name in ("record",):
        if c and c.get(name):
            paths.append(c[name])
    for f in ("Canvas Calendar.md", "Assignments.md", "Modules.md", "Syllabus.html"):
        if (folder / f).exists():
            paths.append(str(folder / f))
    tf = thoughts_file(c)
    if tf.exists():
        paths.append(str(tf))
    paths += [str(folder / "Canvas Files"), str(folder / "My Files")]
    ctx = {"cwd": str(DRC_HOME), "paths": paths,
           "note": "Read the Course Record first, then the newest Thoughts, then the files you need. Write only inside this folder."}
    bn = book_note(c) if first else ""
    if bn:
        ctx["note"] += " " + bn
    if c and c["id"] == GUIDE_ID:
        ctx["note"] = ("This is DRC 101, the built-in class about the Dr. Claude app, Codex, Codex in Chrome, and using AI well. "
                       "Answer from My Files\\Dr Claude Guide.md (the app's own guide). If the guide doesn't cover it, say so plainly, "
                       "then give your best general advice and suggest sending it through 💡 Ideas.")
        paths.insert(0, str(GUIDE_SRC))
        if b.key != "codex":
            ctx["text"] = "## The Dr. Claude Guide\n" + guide_text()[:30000]
            return ctx
    if b.key == "codex":
        return ctx
    # brains without file access: hand them the text (kept small)
    parts = []
    if c and c.get("record"):
        parts.append(f"## Course Record ({Path(c['record']).name})\n{read_text(c['record'])[:12000]}")
    cal = read_text(folder / "Canvas Calendar.md")
    if cal:
        today = dt.date.today()
        keep = [l for l in cal.splitlines()[:6]] + [l for l in cal.splitlines()[6:] if _row_after(l, today)]
        parts.append("## Canvas Calendar (upcoming)\n" + "\n".join(keep)[:3000])
    if tf.exists():
        parts.append("## Their thoughts log (newest last)\n" + "\n".join(read_text(tf).splitlines()[-20:]))
    files = course_files(c)
    if files:
        rels = [str(f.relative_to(folder)) for f in files]
        parts.append("## Course files (names only)\n" + "\n".join(rels[:150]))
        qw = set(words(user_msg))
        scored = []
        for f, rel in zip(files, rels):
            if f.suffix.lower() not in TEXT_EXTS:
                continue
            s = len(qw & set(words(rel)))
            if first and re.search(r"syllab", rel, re.I):
                s += 3
            if s:
                scored.append((s, f, rel))
        scored.sort(key=lambda x: -x[0])
        budget = 16000
        for s, f, rel in scored[:4]:
            txt = TEXT_CACHE.get(f, 6000)
            if txt and budget > 0:
                parts.append(f"## File: {rel}\n{txt[:budget]}")
                budget -= len(txt)
    if first and (folder / "Syllabus.html").exists():
        parts.append("## Syllabus\n" + filetext.html_text(read_text(folder / "Syllabus.html"))[:5000])
    if bn:
        parts.append("## Note from the app\n" + bn)
    ctx["text"] = "\n\n".join(parts)
    return ctx


def _row_after(line, today):
    m = re.search(r"\| (\w{3} \w{3} \d{2}),", line)
    if not m:
        return False
    try:
        d = dt.datetime.strptime(f"{m.group(1)} {today.year}", "%a %b %d %Y").date()
    except ValueError:
        return True
    return d >= today - dt.timedelta(days=7)


def get_brain():
    k = SETTINGS.get("brain")
    if k == "codex":
        return brain.CodexBrain(SETTINGS.get("codex_path", ""), SETTINGS.get("codex_sandbox", "workspace-write"), SETTINGS.get("codex_model", ""))
    if k == "gemini":
        return brain.GeminiBrain(canvas_sync.load_token(GEMINI_KEY_FILE), SETTINGS.get("gemini_model", ""))
    return brain.Brain()


def apply_record_updates(text, c):
    """Apply ```record-update blocks (from brains that can't edit files) to the Course Record."""
    notes = []
    if not c or not c.get("record"):
        return notes
    rec_p = Path(c["record"])
    for raw in RECORD_RE.findall(text):
        try:
            upd = json.loads(raw.strip())
        except ValueError:
            continue
        for u in upd if isinstance(upd, list) else [upd]:
            sec = str(u.get("section", "")).strip()
            add = [str(x).strip() for x in (u.get("rows") or []) + (u.get("lines") or []) if str(x).strip()]
            if sec not in ("Pacing Calendar", "Assessment Log", "Professor patterns", "Mastery", "Session log") or not add:
                continue
            with _lock:
                lines = read_text(rec_p).splitlines()
                start = next((i for i, l in enumerate(lines) if l.startswith("## ") and l[3:].strip().lower().startswith(sec.lower())), None)
                if start is None:
                    lines += ["", f"## {sec}"] + add
                else:
                    end = next((i for i in range(start + 1, len(lines)) if lines[i].startswith("## ")), len(lines))
                    last = max((i for i in range(start + 1, end) if lines[i].strip()), default=start)
                    lines[last + 1:last + 1] = add
                rec_p.write_text("\n".join(lines) + "\n", encoding="utf-8")
            notes.append(f"Course Record: added {len(add)} line(s) to {sec}")
    return notes


NL2 = chr(10) * 2
RUNNING = {}  # sid -> list of stop handles (Popen or HTTP response)
VOICE_ROUTES = {"/api/stt/status", "/api/stt", "/api/voice/info", "/api/voice/setup", "/api/voice/remove",
                "/api/voice/conf", "/api/voice/forget", "/api/voice/read"}
VOICE_PROFILE = DATA / "voice_profile.json"


def start_voice_install(model):
    """Install the voice upgrade in the background; flip the setting on once it really works."""
    st = voice_setup.start(model)

    def remember():
        while voice_setup.STATE["state"] == "working":
            time.sleep(1)
        if voice_setup.STATE["state"] == "done":
            SETTINGS.update(save_settings({"voice_model": model}))
            stt.warm_async(model)
    threading.Thread(target=remember, daemon=True).start()
    return st


def auto_voice_once():
    """v1.4.4 (Ethaniel's call): voice upgrade + confidence reader ON for every user, once. Installs small.en in the
    background (~750 MB, any laptop). If the student later turns it off or removes it, that choice is kept."""
    try:
        if SETTINGS.get("voice_auto_done"):
            return
        SETTINGS.update(save_settings({"voice_auto_done": True, "voice_conf": True}))
        if SETTINGS.get("voice_model"):
            return                                   # already installed
        model = stt.DEFAULT_MODEL
        if stt.available() and stt.model_ready(model):
            SETTINGS.update(save_settings({"voice_model": model}))
            stt.warm_async(model)
            return
        time.sleep(20)                               # let the app finish starting first
        log.info("auto voice: installing %s in the background", model)
        start_voice_install(model)
    except Exception:
        log.exception("auto voice")


def voice_topics(c, n=30):
    """Topic names from the class's Course Record, so Whisper spells this class's words right."""
    if not c:
        return []
    try:
        return [t["topic"] for t in course_mastery(c)[1] if t.get("topic")][:n]
    except Exception:
        return []


# ----------------------------------------------------------------------------- chat media: attachments + pictures
# MEDIA\<sid>\files\     what the student attached to this chat (never added to the class library)
# MEDIA\<sid>\pictures\  pictures the AI drew, shown inline as ![..](/media/<sid>/pictures/<name>)
# MEDIA\_drafts\<id>\    attachments picked before the message is sent (moved into the chat on send)
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
IMAGE_BLOCK_RE = re.compile(r"```image[ \t]*\n(.*?)(?:```|$)", re.S)
MD_IMG_RE = re.compile(r"!\[([^\]]*)\]\(<?([^)>]+)>?\)")
WINPATH_IMG_RE = re.compile(r"`?([A-Za-z]:\\[^\n`\"*<>|]+?\.(?:png|jpe?g|webp|gif))`?", re.I)


def chat_media(sid, sub=""):
    chat_file(sid)  # validates the id
    return MEDIA / sid / sub if sub else MEDIA / sid


def draft_dir(draft):
    if not re.fullmatch(r"[0-9a-f]{32}", draft or ""):
        raise ValueError("bad draft id")
    return MEDIA / "_drafts" / draft


def unique_path(folder, name):
    folder.mkdir(parents=True, exist_ok=True)
    stem, ext = Path(name).stem[:80] or "file", Path(name).suffix[:10]
    p, n = folder / f"{stem}{ext}", 2
    while p.exists():
        p, n = folder / f"{stem} ({n}){ext}", n + 1
    return p


def media_url(p):
    rel = Path(p).resolve().relative_to(MEDIA.resolve())
    return "/media/" + "/".join(urllib.parse.quote(x) for x in rel.parts)


def codex_home():
    return Path(os.environ.get("CODEX_HOME") or HOME / ".codex")


def picture_roots():
    return [codex_home(), DRC_HOME, DATA, Path(os.environ.get("TEMP", str(HOME)))]


def new_images(since):
    """Images the AI saved during this turn (Codex's generated_images folder, or anywhere it wrote in Dr. Claude's folder)."""
    skip = {"Canvas Files", "Canvas Pages", "My Files", "Video Library", "chat_media", "book_pending", ".git"}
    out = []
    for root in (codex_home() / "generated_images", DRC_HOME):
        for dirpath, dirs, files in os.walk(root):
            dirs[:] = [d for d in dirs if d not in skip]
            for f in files:
                p = Path(dirpath) / f
                if p.suffix.lower() in IMAGE_EXTS:
                    try:
                        if p.stat().st_mtime >= since - 1:
                            out.append(p)
                    except OSError:
                        pass
    return sorted(out, key=lambda p: p.stat().st_mtime)


def keep_picture(sid, src=None, data=None, ext=".png"):
    """Copy a picture into this chat's media folder. -> its /media URL (or "" if it isn't a usable picture)."""
    folder = chat_media(sid, "pictures")
    if src is not None:
        src = Path(src)
        try:
            ok = src.is_file() and src.suffix.lower() in IMAGE_EXTS and any(
                str(src.resolve()).lower().startswith(str(r.resolve()).lower()) for r in picture_roots())
        except OSError:
            ok = False
        if not ok:
            return ""
        if str(src.resolve()).lower().startswith(str(folder.resolve()).lower()):
            return media_url(src)
        dest = unique_path(folder, src.name)
        shutil.copy2(src, dest)
    else:
        dest = unique_path(folder, f"picture{ext}")
        dest.write_bytes(data)
    return media_url(dest)


def polish_reply(text):
    """Codex habits that don't belong in a student chat: file citations, and a whole answer wrapped in a code block."""
    text = re.sub(r"[ 	]*【F:[^】]*】", "", text)
    m = re.fullmatch(r"\s*```(?:markdown|md|text|plaintext)?[ \t]*\n(.*?)\n```\s*", text, re.S)
    if m and "```" not in m.group(1):
        text = m.group(1)
    return text


def draw_picture(prompt, b):
    """For ```image blocks: -> (path or None, bytes or None, ext, error)."""
    if b.key == "gemini":
        try:
            data, ext = brain.gemini_image(canvas_sync.load_token(GEMINI_KEY_FILE), prompt)
            return None, data, ext, ""
        except RuntimeError as e:
            return None, None, "", str(e)
    if b.key == "codex":
        since, got, err = time.time(), [], ""
        ask = ("Use your built-in image generation tool to draw this picture for a student, then reply with just the word done.\n\n" + prompt)
        for kind, val in b.send("You make pictures for a study app.", [], ask, {"cwd": str(DRC_HOME), "paths": []}):
            if kind in ("image", "image_b64"):
                got.append((kind, val))
            elif kind == "error":
                err = val
        for kind, val in got:
            if kind == "image" and Path(val).is_file():
                return Path(val), None, "", ""
            if kind == "image_b64":
                try:
                    return None, base64.b64decode(val), ".png", ""
                except ValueError:
                    pass
        found = new_images(since)
        if found:
            return found[-1], None, "", ""
        return None, None, "", err or "ChatGPT didn't make a picture (image making may not be turned on for this account)."
    return None, None, "", "No AI is connected."


def finish_pictures(text, sid, b, since, pics, emit=None):
    """Put every picture from this turn into the chat itself (not just a file on disk)."""
    shown, used = set(), set()  # urls already in the reply · source files already copied

    def grab(src):
        try:
            key = str(Path(src).resolve()).lower()
        except OSError:
            return ""
        if key in used:
            return ""
        url = keep_picture(sid, src=src)
        if url:
            used.add(key)
        return url

    def from_path(m):
        url = grab(m.group(2).strip())
        if url:
            shown.add(url)
            return f"![{m.group(1)}]({url})"
        return m.group(0) if m.group(2).startswith("/media/") else (f"_{m.group(1)}_" if m.group(1) else "")
    text = MD_IMG_RE.sub(from_path, text)

    def from_bare(m):
        url = grab(m.group(1))
        if url:
            shown.add(url)
            return f"\n\n![Picture]({url})\n\n"
        return m.group(0)
    text = WINPATH_IMG_RE.sub(from_bare, text)

    def from_block(m):
        prompt = re.sub(r"^\s*prompt:\s*", "", m.group(1).strip(), flags=re.I).strip()
        if not prompt:
            return ""
        if emit:
            emit({"t": "status", "text": "Drawing a picture…"})
        path, data, ext, err = draw_picture(prompt, b)
        url = grab(path) if path else keep_picture(sid, data=data, ext=ext) if data else ""
        if url:
            shown.add(url)
            return f"![{prompt[:80]}]({url})"
        return f"> 🎨 I couldn't draw this picture: {err}\n> *({prompt[:200]})*"
    text = IMAGE_BLOCK_RE.sub(from_block, text)

    extra = []
    for kind, val in pics:
        url = grab(val) if kind == "image" else ""
        if kind == "image_b64":
            try:
                url = keep_picture(sid, data=base64.b64decode(val), ext=".png")
            except ValueError:
                url = ""
        if url and url not in shown:
            shown.add(url)
            extra.append(url)
    if b.key == "codex":  # pictures Codex saved without telling us where
        for p in new_images(since):
            url = grab(p)
            if url and url not in shown:
                shown.add(url)
                extra.append(url)
    if extra:
        text = text.rstrip() + "\n\n" + "\n\n".join(f"![Picture]({u})" for u in extra)
    return text


MAKE_BLOCK_RE = re.compile(r"```make[ \t]*\n(.*?)(?:\n```[ \t]*(?=\n|$)|$)", re.S)
MAKE_WORD = {"html": "web page", "pdf": "PDF", "gif": "animation", "mp3": "audio", "mp4": "video"}


def finish_made(text, sid, emit=None):
    """Turn each ```make block into the real file, saved with this chat and shown in it (a ```made card)."""
    def one(m):
        spec = maker.parse(m.group(1))
        if not spec:
            return "> 🛠️ I meant to make you a file here, but I wrote the request wrong. Ask me again and I'll redo it."
        if emit:
            emit({"t": "status", "text": f"Making your {MAKE_WORD[spec['type']]}…"})
        try:
            path = maker.make(spec, chat_media(sid, "made"), SETTINGS.get("edge") or find_edge())
        except Exception as e:  # noqa: BLE001 - shown to the student in plain words
            log.warning("make %s: %s", spec["type"], e)
            return f"> 🛠️ I couldn't make the {MAKE_WORD[spec['type']]} ({e}). Ask me to try again, or pick another format."
        card = {"type": spec["type"], "title": spec["title"], "url": media_url(path), "name": path.name,
                "size": path.stat().st_size}
        return "```made\n" + json.dumps(card, ensure_ascii=False) + "\n```"
    return MAKE_BLOCK_RE.sub(one, text)


def media_file(url):
    """/media/... URL -> the file inside the chat media folder (or None)."""
    if not str(url).startswith("/media/"):
        return None
    parts = [urllib.parse.unquote(x) for x in str(url)[len("/media/"):].split("?")[0].split("/") if x]
    p = MEDIA.joinpath(*parts).resolve() if parts else MEDIA
    return p if str(p).startswith(str(MEDIA.resolve()) + os.sep) and p.is_file() else None


def attachment_paths(sid):
    d = chat_media(sid, "files")
    return sorted((p for p in d.iterdir() if p.is_file()), key=lambda p: p.stat().st_mtime) if d.is_dir() else []


def attach_ctx(b, ctx, sid, new_files):
    """Tell the brain about this chat's attachments. -> a note to put in front of the student's message."""
    if b.key == "gemini":
        allp = attachment_paths(sid)
        ctx["images"] = [str(p) for p in allp if p.suffix.lower() in IMAGE_EXTS][-3:]
        docs, budget = [], 24000
        for p in allp:
            if p.suffix.lower() in IMAGE_EXTS or budget <= 0:
                continue
            t = TEXT_CACHE.get(p, budget)
            if t:
                docs.append(f"## Attached file: {p.name}\n{t}")
                budget -= len(t)
        if docs:
            ctx["text"] = (ctx.get("text", "") + "\n\n" + "\n\n".join(docs)).strip()
    else:
        ctx["images"] = [str(p) for p in new_files if p.suffix.lower() in IMAGE_EXTS]
    if not new_files:
        return ""
    if b.key == "gemini":
        return "(The student attached: " + ", ".join(p.name for p in new_files) + ". Pictures are included with this message; file text is in the context above.)\n\n"
    lines = [f"- {p}  ({'picture: look at it with your image viewer' if p.suffix.lower() in IMAGE_EXTS else 'file: open and read it'})" for p in new_files]
    return "(The student attached these to this message. They're for this chat only:\n" + "\n".join(lines) + ")\n\n"


def run_turn(sid, meta, prompt, history, c, first, emit, new_files=(), pics=None):
    """Run one tutor turn through the chosen brain. Returns (final_text, tools, ok).
    new_files = attachments sent with this message; pics collects the pictures the brain drew."""
    b = get_brain()
    p = load_profile()
    ctx = build_ctx(c, prompt, b, first)
    session = meta.get("brain_session") if meta.get("brain") == b.key else None
    msg = attach_ctx(b, ctx, sid, list(new_files)) + prompt
    if b.stateful and not session and history:  # brain changed mid-chat: give it the recent conversation
        msg = "Earlier in this chat:\n" + "\n".join(f"{m['role']}: {m['text'][:800]}" for m in history[-8:]) + "\n\nNow: " + prompt
    ver = RULES.version()
    if b.stateful and session and meta.get("rules_ver") != ver:  # a resumed chat doesn't see the new system prompt
        msg = ("(Note from the app: their Teaching Rules just changed. These rules are now in force and override anything earlier:\n"
               + teaching_rules(p, c.get("code", "") if c else "") + ")\n\n" + msg)
    meta["rules_ver"] = ver
    stop = []
    RUNNING[sid] = stop
    text, tools, ok = "", [], True
    emit({"t": "status", "text": "Waking Dr. Claude…"})
    log.info("turn start sid=%s brain=%s first=%s", sid, b.key, first)
    try:
        for kind, val in b.send(app_prompt(p, b, c.get("code", "") if c else ""), history, msg, ctx, session=session, stop=stop):
            if kind == "text":
                if not text and val.startswith("\n\n"):
                    val = val.lstrip("\n")
                text += val
                emit({"t": "text", "delta": val})
            elif kind == "status":
                emit({"t": "status", "text": val})
            elif kind == "tool":
                info = {"icon": "📖" if val.startswith("Looking") else "✏️" if val.startswith("Updated") else "🛠️", "text": val}
                tools.append(info)
                emit({"t": "tool", **info})
            elif kind == "session":
                meta["brain_session"], meta["brain"] = val, b.key
            elif kind in ("image", "image_b64") and pics is not None:
                pics.append((kind, val))
            elif kind == "error":
                ok = False
                emit({"t": "error", "text": val})
    except Exception as e:
        ok = False
        log.exception("brain turn")
        emit({"t": "error", "text": f"Something went wrong talking to the AI: {e}"})
    finally:
        RUNNING.pop(sid, None)
    if any(getattr(h, "_killed", False) for h in stop):
        emit({"t": "error", "text": "Stopped."})
    log.info("turn end sid=%s chars=%d ok=%s", sid, len(text), ok)
    return text, tools, ok


def stop_turn(sid):
    hs = RUNNING.get(sid)
    if not hs:
        return False
    for h in hs:
        try:
            h._killed = True
            if hasattr(h, "pid"):
                subprocess.run(["taskkill", "/T", "/F", "/PID", str(h.pid)], capture_output=True, creationflags=CREATE_NO_WINDOW)
            else:
                h.close()
        except Exception:
            pass
    return True


# ----------------------------------------------------------------------------- Tools drawer: side chat + thoughts
def side_prompt():
    n = who()
    return f"""You are the quick side helper inside the Dr. Claude study app. The main tutoring chat is separate; you are the little panel on the side.
{n} asks quick questions here (a definition, a formula, "what does X mean", a calculation check) without derailing the main lesson.
Answer SHORT: 1-6 lines, plain words, beginner level. One small ASCII picture or table if it really helps; a one-line mental image is welcome.
If the question is about the practice question {n} is working on right now (given as context), do NOT hand over the answer: give a nudge or a smaller hint question instead, and say to try it in the main chat.
Read voice-typing typos for meaning. Never invent facts or numbers you are not sure of. Don't edit any files.
Talk like a friendly person, not a coding tool: no code blocks for normal answers, no file paths, plain-text math with symbols like × ÷ ² √ π (never LaTeX)."""


INSIGHT_PROMPT = """Below is {name}'s running "thoughts" log for {course}: things they noticed, got confused by, or realized while studying (newest last).
Give a short insight, max 8 lines, beginner-friendly:
1. The pattern you see (what keeps tripping them up, or what clicked).
2. Any thought that shows a misconception: name it and fix it in one line.
3. The ONE thing to review next, and a vivid picture to remember it by.
Be honest and specific, quote their words where useful. Don't pad.

{thoughts}"""

SIDE = {}  # side chat id -> {"history": [...], "session": provider session, "brain": key}


def run_side(prompt, side_sid=None, system=None, timeout=180):
    """One-shot (blocking) brain call for the side panel. Returns (text, side_sid)."""
    b = get_brain()
    st = SIDE.get(side_sid) if side_sid else None
    if not st or st["brain"] != b.key:
        side_sid = str(uuid.uuid4())
        st = SIDE[side_sid] = {"history": [], "session": None, "brain": b.key}
    out, err = [], None
    ctx = {"cwd": str(DRC_HOME), "paths": [], "text": ""}
    try:
        for kind, val in b.send(system or side_prompt(), st["history"], prompt, ctx, session=st["session"]):
            if kind == "text":
                out.append(val)
            elif kind == "session":
                st["session"] = val
            elif kind == "error":
                err = val
    except Exception as e:
        err = f"Something went wrong: {e}"
    text = strip_markers("".join(out)).strip() or err or "No answer came back."
    st["history"] += [{"role": "user", "text": prompt}, {"role": "assistant", "text": text}]
    return text, side_sid


# ----------------------------------------------------------------------------- Command: the student's coach for HOW Dr. Claude teaches
def command_prompt():
    n = who()
    d = RULES.load()
    cur = "\n".join(f"- id={r['id']} · {r['group']}{' · ' + r['course'] if r.get('course') else ''} · {'on' if r.get('on', True) else 'paused'} · {r['text']}"
                    for r in d["rules"]) or "(no rules yet)"
    return f"""You are Command, {n}'s own coach inside the Dr. Claude study app. You do NOT teach school subjects.
Your only job: manage {n}'s Teaching Rules, the rules that control HOW the tutor (Dr. Claude) teaches them.
{n} tells you what works and what doesn't ("stop giving me acronyms, use real-life examples", "quiz me harder",
"explanations are too long", "I learn by drawing"). Turn each wish into a clear, specific rule the tutor can follow.

How to answer:
- Reply in 1-4 short, friendly lines: say what you'd change and why. If the wish is vague, ask ONE short question instead of guessing.
- Then, only if there is something to change, add exactly one block like this (it is shown to {n} as before/after cards;
  NOTHING is saved until they press Confirm):
```rule-change
{{"changes": [
  {{"op": "add", "group": "Visuals", "text": "Use a real-life example before any acronym or memory trick.", "why": "<their words>"}},
  {{"op": "edit", "id": "<id from the list>", "text": "<the new wording>", "why": "<their words>"}},
  {{"op": "toggle", "id": "<id>", "on": false}},
  {{"op": "delete", "id": "<id>"}}
]}}
```
- group is one of: Format, Pace, Questions, Visuals, Tone, Per-class. For Per-class also give "course": "<code like AE 2010>".
- "why" = {n}'s own words, short. Write rules as instructions to the tutor ("Show ...", "Never ...", "Keep ... under N lines").
- If a new wish conflicts with an existing rule, EDIT or pause that rule instead of adding a contradicting one.
- Never invent wishes they didn't express. Never edit files yourself; the app saves confirmed changes.

{n}'s current Teaching Rules:
{cur}"""


def brain_once(system, msg):
    out, err = [], None
    try:
        for kind, val in get_brain().send(system, [], msg, {"cwd": str(DRC_HOME), "paths": [], "text": ""}):
            if kind == "text":
                out.append(val)
            elif kind == "error":
                err = val
    except Exception as e:
        err = f"Something went wrong: {e}"
    return "".join(out).strip(), err


CALC_PROMPT = """You turn a student's math question (typed or voice-typed, in words) into ONE calculator expression.
Allowed: numbers, + - * / ^ ( ) ! %, sqrt( ), ln( ), log( ) (base 10), log2( ), exp( ), sin( ) cos( ) tan( ) (radians), abs( ), pi, e, ans (= the previous answer).
Convert words to numbers ("three hundred twelve" -> 312), "percent of" -> /100*, degrees -> *pi/180, units dropped.
Reply with ONLY the expression on one line, nothing else. If it isn't a calculation, reply NONE."""


def command_ask(msg, max_changes=8):
    text, err = brain_once(command_prompt(), msg)
    if not text:
        return {"reply": err or "No answer came back.", "proposals": [], "error": bool(err)}
    reply, changes = rules.parse_changes(strip_markers(text))
    return {"reply": reply, "proposals": RULES.propose(changes[:max_changes])}


def command_state():
    d = RULES.load()
    return {"rules": d["rules"], "groups": rules.GROUPS, "inbox": d["inbox"], "feedback": d["feedback"][-30:][::-1],
            "version": d["version"], "file": str(RULES.md)}


def after_rules_change():
    """Keep the setup toggles in step with their rules (pausing one on the Command page unticks it in Settings)."""
    with _lock:
        p = load_profile()
        rs = {r["id"]: r for r in RULES.load()["rules"]}
        if any(i.startswith("pref_") for i in rs):
            for k, _, _ in PREFS:
                p["prefs"][k] = bool(rs[f"pref_{k}"].get("on", True)) if f"pref_{k}" in rs else False
        PROFILE_FILE.write_text(json.dumps(p, indent=1, ensure_ascii=False), encoding="utf-8")
        (DRC_HOME / "My Learning Profile.md").write_text(profile_md(p), encoding="utf-8")
    write_agents_md(p)


def checkin_to_inbox(question, answer, code):
    """A 'How's my teaching?' answer -> Feedback log + suggested rule(s) in the Command inbox."""
    RULES.log_feedback(answer, "check-in", code)
    res = command_ask(f"The tutor asked a teaching check-in during {code}:\n{question[-600:]}\n\n{who()}'s answer: {answer}\n\n"
                      "Suggest at most 2 rule changes that follow from the answer (none if it was just 'all good').", max_changes=2)
    items = [{"proposal": p} for p in res["proposals"]]
    if items:
        RULES.add_inbox(items, f"check-in · {code}", answer)
    log.info("check-in -> %d suggestion(s)", len(items))


CHECKIN_RE = re.compile(r"#{2,4}\s*💬\s*Teaching check-in", re.I)


def thoughts_file(c):
    return Path(SETTINGS["hub"]) / "Thoughts" / ((c["code"].replace(" ", "") if c else "General") + ".md")


THOUGHT_RE = re.compile(r"^- \*\*(?P<when>[^*]+)\*\*(?: · _(?P<q>[^_]*)_)? · (?P<text>.*)$")


def load_thoughts(c):
    p = thoughts_file(c)
    items = []
    for line in read_text(p).splitlines() if p.exists() else []:
        m = THOUGHT_RE.match(line)
        if m:
            items.append({"when": m["when"], "q": m["q"] or "", "text": m["text"].replace("<br>", "\n")})
    return {"path": str(p), "items": items}


def add_thought(c, text, q=""):
    p = thoughts_file(c)
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        name = f"{c['code']} {c['title']}" if c else "General"
        p.write_text(f"# My Thoughts: {name}\n*Things I noticed, got stuck on, or realized while studying. "
                     "Dr. Claude reads this to see what's confusing me.*\n\n", encoding="utf-8")
    when = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    q = re.sub(r"[_\n]", " ", q or "").strip()[:80]
    text = text.strip().replace("\r", "").replace("\n", "<br>")
    with p.open("a", encoding="utf-8") as f:
        f.write(f"- **{when}**{' · _' + q + '_' if q else ''} · {text}\n")


# ----------------------------------------------------------------------------- on-demand video clips
# The tutor writes ```video with "search: <what they need to see>". The page asks /api/clip, which reuses a
# catalog clip if one fits (and they haven't voted it down), otherwise searches YouTube live, checks the video
# is real + embeddable (oEmbed), jumps to the best-matching chapter if the video has chapters, and adds it to
# the catalog. Votes (👍/👎) and uses make the catalog adapt over time.
CLIP_LOCK = threading.Lock()
STOP = set("a an the of to in on for and or with how what why is are do does my i me it this that from by vs "
           "step steps explained explanation example examples tutorial video clip watch".split())
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/126.0 Safari/537.36", "Accept-Language": "en-US,en;q=0.9", "Cookie": "CONSENT=YES+1; SOCS=CAI"}


def catalog_path():
    return Path(SETTINGS["hub"]) / "Video Library" / "catalog.json"


def words(s):
    return [w for w in re.findall(r"[a-z0-9]+", (s or "").lower()) if w not in STOP and len(w) > 1]


def load_catalog():
    p = catalog_path()
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except ValueError:
            log.warning("catalog.json unreadable; starting over from the seed")
    cat = {"about": "Dr. Claude's video catalog. Grows by itself: every clip found on demand is added. "
                    "votes: up/down from the 👍/👎 buttons; uses: times shown. Safe to edit by hand.", "clips": []}
    try:  # hand-checked starter clips that ship with the app (no one's votes or searches in it)
        seed = json.loads((APP_DIR / "seed" / "catalog.json").read_text(encoding="utf-8"))
        for c in seed.get("clips", []):
            cat["clips"].append(dict(c, queries=[], uses=0, up=0, down=0, source="seed"))
    except (OSError, ValueError):
        pass
    save_catalog(cat)
    return cat


def save_catalog(cat):
    p = catalog_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(cat, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, p)


def http_get(url, timeout=10):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def overlap(qw, text_words):
    if not qw:
        return 0.0
    tw = set(text_words)
    hit = sum(1 for w in qw if w in tw or any(t.startswith(w[:5]) for t in tw if len(w) >= 5))
    return hit / len(qw)


def catalog_match(cat, q, course, exclude):
    qw = words(q)
    best, best_s = None, 0.0
    for c in cat["clips"]:
        if c["id"] in exclude or c.get("down", 0) > c.get("up", 0) + 1 or q.strip().lower() in c.get("bad_q", []):
            continue
        s = overlap(qw, c["tags"] + words(c["title"]) + [w for qq in c.get("queries", []) for w in words(qq)])
        s += 0.08 * (c.get("up", 0) - c.get("down", 0)) + (0.05 if course and c.get("course") == course else 0)
        if q.strip().lower() in [x.lower() for x in c.get("queries", [])]:
            s += 0.5
        if s > best_s:
            best, best_s = c, s
    return best if best_s >= 0.75 else None


def secs(t):
    p = [int(x) for x in re.findall(r"\d+", t or "")]
    v = 0
    for x in p:
        v = v * 60 + x
    return v


def yt_search(q):
    m = None
    for _ in range(2):  # YouTube sometimes serves a page variant without the data blob; retry once
        try:
            html = http_get("https://www.youtube.com/results?hl=en&gl=US&search_query=" + urllib.parse.quote(q))
        except OSError as e:
            log.warning("yt search failed: %s", e)
            continue
        m = re.search(r"(?:var ytInitialData|window\[\"ytInitialData\"\])\s*=\s*(\{.*?\});\s*</script>", html, re.S)
        if m:
            break
    if not m:
        log.warning("yt search: no results blob for %r", q)
        return []
    out = []

    def walk(o):
        if isinstance(o, dict):
            vr = o.get("videoRenderer")
            if isinstance(vr, dict) and vr.get("videoId"):
                out.append({"id": vr["videoId"],
                            "title": "".join(r.get("text", "") for r in (vr.get("title") or {}).get("runs", [])),
                            "channel": "".join(r.get("text", "") for r in (vr.get("ownerText") or {}).get("runs", [])),
                            "seconds": secs((vr.get("lengthText") or {}).get("simpleText", ""))})
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(json.loads(m.group(1)))
    return out


def yt_chapters(vid):
    try:
        html = http_get(f"https://www.youtube.com/watch?v={vid}&hl=en")
    except OSError:
        return []
    ch = []
    for m in re.finditer(r'"chapterRenderer":\{"title":\{"simpleText":"((?:[^"\\]|\\.)*)"\},"timeRangeStartMillis":(\d+)', html):
        t = json.loads('"' + m.group(1) + '"')
        if (t, int(m.group(2)) // 1000) not in ch:
            ch.append((t, int(m.group(2)) // 1000))
    return sorted(set(ch), key=lambda x: x[1])


def embeddable(vid):
    try:
        info = json.loads(http_get(f"https://www.youtube.com/oembed?format=json&url=https://www.youtube.com/watch?v={vid}"))
        return info
    except (OSError, ValueError):
        return None


TRANSCRIPTS = DATA / "transcripts"


def trim_for(vid, q, seconds=0):
    """The exact part of this video that answers q, from its captions: (start, end, confidence, excerpt) or None."""
    segs = cliptrim.transcript(vid, TRANSCRIPTS)
    return cliptrim.best_window(segs, q, seconds) if segs else None


def clip_checks_out(q, excerpt):
    """Ask the AI whether this part of the video really teaches q. True / False, or None when no AI is set up."""
    if not SETTINGS.get("brain") or not excerpt:
        return None
    try:
        out, _ = brain_once(cliptrim.CHECK_PROMPT, f"The student needs: {q}\n\nTranscript of just this part:\n{excerpt}")
    except Exception:
        return None
    first = (out or "").strip().upper()
    return True if first.startswith("YES") else False if first.startswith("NO") else None


def find_clip(q, course="", exclude=()):
    """A clip that plays ONLY the part that answers q: start/end come from the video's captions (cliptrim),
    the AI double-checks that part, and "sure" tells the app whether to ask the student if it was the right part."""
    exclude = set(exclude)
    key = q.strip().lower()
    with CLIP_LOCK:
        cat = load_catalog()
        hit = catalog_match(cat, q, course, exclude)
        if hit:
            hit["uses"] = hit.get("uses", 0) + 1
            if q not in hit.setdefault("queries", []):
                hit["queries"] = (hit["queries"] + [q])[-12:]
            save_catalog(cat)
            hit = dict(hit)
    if hit:
        saved = (hit.get("trims") or {}).get(key)
        if saved:
            return {**hit, "start": saved[0], "end": saved[1], "sure": True, "from": "catalog"}
        t = trim_for(hit["id"], q, hit.get("seconds", 0))
        if t and t[2] >= 0.5:
            return {**hit, "start": t[0], "end": t[1], "sure": t[2] >= 0.75, "why": t[3][:200], "from": "catalog"}
        if not t:
            return {**hit, "sure": bool(hit.get("up")), "from": "catalog"}
    qw = words(q)
    results = [r for r in yt_search(q) if r["id"] not in exclude and 60 <= r["seconds"] <= 2400][:8]
    if not results:
        return None
    for rank, r in enumerate(results):
        dur = r["seconds"]
        r["score"] = overlap(qw, words(r["title"])) - 0.04 * rank + (0.15 if 120 <= dur <= 900 else 0.05)
    results.sort(key=lambda r: -r["score"])
    fallback, checks = None, 0
    for r in results[:5]:
        info = embeddable(r["id"])
        if not info:
            continue
        start = end = 0
        chap, sure, why = "", False, ""
        t = trim_for(r["id"], q, r["seconds"])
        if t:
            if t[2] < 0.4:  # the video barely talks about it: keep looking
                fallback = fallback or (r, info, t[0], t[1], "", t[3])
                continue
            ok = clip_checks_out(q, t[3]) if checks < 2 else None
            checks += ok is not None
            if ok is False:
                fallback = fallback or (r, info, t[0], t[1], "", t[3])
                continue
            start, end, why = t[0], t[1], t[3]
            sure = ok is True or t[2] >= 0.75
        else:  # no captions: fall back to the video's chapters
            chs = yt_chapters(r["id"])
            if chs:
                scored = [(overlap(qw, words(x)), i) for i, (x, _) in enumerate(chs)]
                sc, i = max(scored, key=lambda x: (x[0], -x[1]))
                if sc >= 0.5 and chs[i][1] > 0 and sc > scored[0][0] + 0.2:
                    chap, start = chs[i][0], chs[i][1]
                    end = chs[i + 1][1] if i + 1 < len(chs) else 0
        return {**remember_clip(r, info, q, qw, course, start, end, chap), "sure": sure, "why": why[:200], "from": "youtube"}
    if fallback:
        r, info, start, end, chap, why = fallback
        return {**remember_clip(r, info, q, qw, course, start, end, chap), "sure": False, "why": why[:200], "from": "youtube"}
    return None


def remember_clip(r, info, q, qw, course, start, end, chap):
    clip = {"id": r["id"], "title": info.get("title") or r["title"], "channel": info.get("author_name") or r["channel"],
            "seconds": r["seconds"], "start": start, "end": end, "chapter": chap,
            "tags": sorted(set(qw)), "queries": [q], "course": course, "note": "", "trims": {q.strip().lower(): [start, end]},
            "source": "auto", "added": dt.date.today().isoformat(), "uses": 1, "up": 0, "down": 0}
    with CLIP_LOCK:
        cat = load_catalog()
        old = next((c for c in cat["clips"] if c["id"] == r["id"]), None)
        if old:
            old["uses"] = old.get("uses", 0) + 1
            old["queries"] = (old.get("queries", []) + [q])[-12:]
            old["tags"] = sorted(set(old["tags"]) | set(qw))
            old.setdefault("trims", {})[q.strip().lower()] = [start, end]
            clip = old
        else:
            cat["clips"].append(clip)
        save_catalog(cat)
    log.info("clip q=%r -> %s %s-%s", q, r["id"], start, end)
    return {**clip, "start": start, "end": end}


def rate_clip(vid, vote, q=""):
    """👍 = keep this clip (and this exact part) for this question. 👎 = wrong part or wrong video: drop the saved part
    and never show this clip for this question again."""
    key = (q or "").strip().lower()
    with CLIP_LOCK:
        cat = load_catalog()
        for c in cat["clips"]:
            if c["id"] == vid:
                c["up" if vote > 0 else "down"] = c.get("up" if vote > 0 else "down", 0) + 1
                if q and vote > 0 and q not in c.setdefault("queries", []):
                    c["queries"] = (c["queries"] + [q])[-12:]
                if key and vote < 0:
                    (c.get("trims") or {}).pop(key, None)
                    c["bad_q"] = (c.get("bad_q", []) + [key])[-30:]
                    c["queries"] = [x for x in c.get("queries", []) if x.strip().lower() != key]
        save_catalog(cat)


# ----------------------------------------------------------------------------- HTTP
class State:
    port = 0
    last_beat = time.time()
    bye_at = None
    server = None
    headless = False


def json_body(h):
    n = int(h.headers.get("Content-Length") or 0)
    if not n:
        return {}
    return json.loads(h.rfile.read(n).decode("utf-8"))


class Handler(BaseHTTPRequestHandler):
    server_version = "DrClaude/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass

    # --- helpers
    def _host_ok(self):
        host = (self.headers.get("Host") or "").lower()
        return host in (f"127.0.0.1:{State.port}", f"localhost:{State.port}")

    def send_json(self, obj, code=200):
        b = json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)

    def err(self, msg, code=400):
        self.send_json({"error": str(msg)}, code)

    def serve_static(self, rel):
        p = (STATIC / rel).resolve()
        if not str(p).startswith(str(STATIC.resolve())) or not p.is_file():
            return self.err("not found", 404)
        b = p.read_bytes()
        ctype = mimetypes.guess_type(str(p))[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript",):
            ctype += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)

    # --- GET
    def do_GET(self):
        if not self._host_ok():
            return self.err("bad host", 403)
        u = urllib.parse.urlparse(self.path)
        q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
        path = u.path
        try:
            if path in ("/", "/index.html"):
                return self.serve_static("index.html")
            if path == "/favicon.ico":
                return self.serve_static("icon.png")
            if path.startswith("/static/"):
                return self.serve_static(urllib.parse.unquote(path[len("/static/"):]))
            if path.startswith("/media/"):
                return self.serve_media(path[len("/media/"):])
            if path == "/api/book/job":
                if not TEXTBOOK_FINDER:
                    return self.err("The textbook finder was removed.", 410)
                job = books.JOBS.get(q.get("id", ""))
                return self.send_json({k: v for k, v in job.items() if k not in ("book", "path")} if job else {"state": "gone"})
            if path == "/api/ping":
                return self.send_json({"ok": True, "app": "dr-claude", "port": State.port, "version": VERSION})
            if path == "/api/state":
                return self.send_json({"settings": SETTINGS, "courses": load_courses(), "modes": MODES,
                                       "today": dt.date.today().isoformat(), "docs_root": str(DRC_HOME),
                                       "profile": load_profile(), "prefs": [{"key": k, "label": l} for k, l, _ in PREFS],
                                       "canvas": canvas_status(), "version": VERSION})
            if path == "/api/books/needs":
                return self.send_json({"courses": books_needs()})
            if path == "/api/guide":
                return self.send_json({"markdown": guide_text(), "course": GUIDE_ID})
            if path == "/api/ideas":
                if any(not it.get("sent") for it in IDEAS.load()):
                    IDEAS.send_waiting()
                return self.send_json({"ideas": IDEAS.load()[::-1], "kinds": ideas.KINDS})
            if path == "/api/profile":
                return self.send_json({"profile": load_profile(), "prefs": [{"key": k, "label": l} for k, l, _ in PREFS]})
            if path == "/api/brain/status":
                k = q.get("brain") or SETTINGS.get("brain")
                if k == "codex":
                    b = brain.CodexBrain(SETTINGS.get("codex_path", ""), SETTINGS.get("codex_sandbox", ""), SETTINGS.get("codex_model", ""))
                elif k == "gemini":
                    b = brain.GeminiBrain(canvas_sync.load_token(GEMINI_KEY_FILE), SETTINGS.get("gemini_model", ""))
                else:
                    b = brain.Brain()
                st = b.status()
                st["brain"] = b.key
                if k == "gemini":
                    st["has_key"] = GEMINI_KEY_FILE.exists()
                return self.send_json(st)
            if path == "/api/canvas/status":
                return self.send_json(canvas_status())
            if path == "/api/canvas/bridge":
                return self.send_json({"port": canvas_bridge.Config.port, "bookmarklet": canvas_bridge.bookmarklet(),
                                       "canvas": canvas_bridge.canvas_origin()})
            if path == "/api/command":
                return self.send_json(command_state())
            if path == "/api/update/status":
                return self.send_json(update_status())
            if path == "/api/dashboard":
                return self.send_json(build_dashboard())
            if path == "/api/course":
                c = get_course(q.get("id", ""))
                return self.send_json(course_detail(c)) if c else self.err("unknown course", 404)
            if path == "/api/files":
                target = q.get("path")
                if not target:
                    c = get_course(q.get("course", ""))
                    target = c["folder"] if c and c["folder"] else str(DOCS)
                res = list_dir(target)
                res["root"] = q.get("root") or target
                return self.send_json(res)
            if path == "/api/quickdirs":
                c = get_course(q.get("course", ""))
                if not c or not c["folder"]:
                    return self.send_json({"folder": "", "dirs": []})
                f = Path(c["folder"])
                dirs = [str(f / d) for d in QUICK_DIRS if (f / d).is_dir()]
                dirs += [str(d) for d in sorted(f.iterdir()) if d.is_dir() and re.match(r"(?i)^(lab|group report)", d.name)]
                return self.send_json({"folder": c["folder"], "dirs": dirs})
            if path == "/api/search":
                return self.send_json({"results": search_files(q.get("root") or str(DOCS), q.get("q", ""))})
            if path == "/api/gradebook":
                gb = Path(SETTINGS["hub"]) / "Gradebook"
                gbooks = []
                if gb.is_dir():
                    for p in sorted(gb.glob("*.md")):
                        gbooks.append({"name": p.stem, "path": str(p), "content": read_text(p),
                                      "mtime": dt.datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="minutes")})
                return self.send_json({"folder": str(gb), "books": gbooks})
            if path == "/api/replays":
                rp = Path(SETTINGS["hub"]) / "Replays"
                items = []
                if rp.is_dir():
                    for p in sorted(rp.rglob("*.md")):
                        cid = next((c["id"] for c in load_courses()
                                    if c["code"].replace(" ", "").lower() in p.stem.replace(" ", "").lower()), "")
                        items.append({"name": p.stem, "path": str(p), "content": read_text(p), "course": cid,
                                      "mtime": dt.datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="minutes")})
                return self.send_json({"folder": str(rp), "replays": items})
            if path == "/api/sessions":
                return self.send_json({"sessions": load_sessions(), "running": list(RUNNING)})
            if path == "/api/chat/history":
                sid = q.get("sid", "")
                return self.send_json({"session": get_session(sid), "messages": load_chat(sid), "running": sid in RUNNING})
            if path == "/api/logpose/status":
                return self.send_json({"text": logpose("status"), "active": TIMER["active"], "running": bool(TIMER.get("start"))})
            if path == "/api/thoughts":
                return self.send_json(load_thoughts(get_course(q.get("course", ""))))
            if path == "/api/clip":
                c = get_course(q.get("course", ""))
                ex = [x for x in q.get("exclude", "").split(",") if x]
                clip = find_clip(q.get("q", ""), c["code"].replace(" ", "") if c else "", ex)
                return self.send_json({"clip": clip})
            return self.err("not found", 404)
        except PermissionError as e:
            return self.err(e, 403)
        except FileNotFoundError as e:
            return self.err(f"Not found: {e}", 404)
        except Exception as e:
            log.exception("GET %s", path)
            return self.err(e, 500)

    # --- POST
    def do_POST(self):
        if not self._host_ok():
            return self.err("bad host", 403)
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/heartbeat":
            State.last_beat = time.time()
            State.bye_at = None
            return self.send_json({"ok": True})
        if path == "/api/bye":
            State.bye_at = time.time()
            return self.send_json({"ok": True})
        if self.headers.get("X-Dr-Claude") != "1":  # blocks cross-site form posts
            return self.err("missing app header", 403)
        try:
            if path in VOICE_ROUTES:
                return self.voice_api(path, json_body(self))
            if path == "/api/upload":
                return self.upload()
            if path == "/api/chat/attach":
                return self.attach()
            body = json_body(self)
            if path == "/api/chat/attach/remove":
                p = draft_dir(body.get("draft", "")) / Path(str(body.get("name", ""))).name
                p.unlink(missing_ok=True)
                return self.send_json({"ok": True})
            if path == "/api/chat/delete":
                sid = body.get("sid", "")
                if sid in RUNNING:
                    return self.err("Dr. Claude is still answering in that chat. Press Stop first.", 409)
                cf = chat_file(sid)
                with _lock:
                    ss = [x for x in load_sessions() if x["id"] != sid]
                    SESSIONS_FILE.write_text(json.dumps(ss, indent=2, ensure_ascii=False), encoding="utf-8")
                cf.unlink(missing_ok=True)
                shutil.rmtree(chat_media(sid), ignore_errors=True)  # its attachments and pictures go with it
                TIMER["active"].pop(sid, None)
                return self.send_json({"ok": True})
            if path == "/api/book/lookup":
                if not TEXTBOOK_FINDER:
                    return self.err("The textbook finder was removed.", 410)
                try:
                    return self.send_json({"book": books.lookup(body.get("isbn", ""))})
                except (ValueError, LookupError) as e:
                    return self.err(e)
            if path == "/api/book/search":
                if not TEXTBOOK_FINDER:
                    return self.err("The textbook finder was removed.", 410)
                book = body.get("book") or {}
                if not book.get("title"):
                    return self.err("Look the ISBN up first.")
                return self.send_json(books.web_search(book))
            if path == "/api/book/download":
                if not TEXTBOOK_FINDER:
                    return self.err("The textbook finder was removed.", 410)
                job = books.start_download(body.get("url", ""), PENDING, body.get("book") or {})
                return self.send_json({k: v for k, v in job.items() if k not in ("book", "path")})
            if path == "/api/book/open":
                if not TEXTBOOK_FINDER:
                    return self.err("The textbook finder was removed.", 410)
                job = books.JOBS.get(body.get("id", ""))
                if not job or not job.get("path"):
                    return self.err("That download is gone.")
                os.startfile(job["path"])
                return self.send_json({"ok": True})
            if path == "/api/book/keep":
                if not TEXTBOOK_FINDER:
                    return self.err("The textbook finder was removed.", 410)
                c = get_course(body.get("course", ""))
                dest = (Path(c["folder"]) / "My Files" / "Textbooks") if c and c.get("folder") else DRC_HOME / "Textbooks"
                try:
                    return self.send_json({"path": books.keep(body.get("id", ""), dest)})
                except LookupError as e:
                    return self.err(e)
            if path == "/api/book/discard":
                books.discard(body.get("id", ""))
                return self.send_json({"ok": True})
            if path == "/api/books/dismiss":
                SHELF.dismiss(str(body.get("course", "")), str(body.get("why", "no textbook"))[:80])
                return self.send_json({"ok": True})
            if path == "/api/books/undismiss":
                SHELF.undismiss(str(body.get("course", "")))
                return self.send_json({"ok": True})
            if path == "/api/ideas/add":
                return self.send_json(IDEAS.add(str(body.get("kind", "")), str(body.get("text", ""))))
            if path == "/api/ideas/resend":
                return self.send_json(IDEAS.send(str(body.get("id", ""))))
            if path == "/api/ideas/delete":
                IDEAS.delete(str(body.get("id", "")))
                return self.send_json({"ok": True})
            if path == "/api/made/open":
                f = media_file(body.get("url", ""))
                if not f:
                    return self.err("That file is gone (was the chat deleted?).", 404)
                os.startfile(str(f))
                return self.send_json({"ok": True})
            if path == "/api/made/save":
                f = media_file(body.get("url", ""))
                c = get_course(str(body.get("course", "")))
                if not f:
                    return self.err("That file is gone (was the chat deleted?).", 404)
                if not c or not c.get("folder"):
                    return self.err("Pick a class first.")
                dest = unique_path(Path(c["folder"]) / "My Files" / "Made by Dr. Claude", f.name)
                shutil.copy2(f, dest)
                return self.send_json({"ok": True, "path": str(dest), "course": c["code"]})
            if path == "/api/openurl":
                url = str(body.get("url", ""))
                if not re.match(r"https://", url):
                    return self.err("Only https links open from here.")
                os.startfile(url)
                return self.send_json({"ok": True})
            if path == "/api/calc/ask":
                txt = str(body.get("text", "")).strip()[:400]
                if not txt:
                    return self.err("Type a math question first.")
                out, err = brain_once(CALC_PROMPT, txt)
                expr = (out or "").strip().strip("`").splitlines()[-1].strip() if out else ""
                expr = re.sub(r"^(expression|answer)\s*[:=]\s*", "", expr, flags=re.I)
                if not out or expr.upper().startswith("NONE"):
                    return self.send_json({"expr": "", "error": err or "That doesn't look like a math question I can turn into numbers."})
                return self.send_json({"expr": expr})
            if path == "/api/open":
                open_path(body.get("path", ""), body.get("how", "default"))
                return self.send_json({"ok": True})
            if path == "/api/settings":
                s = save_settings(body)
                load_courses(force=True)
                return self.send_json({"settings": s})
            if path == "/api/logpose":
                action = body.get("action")
                if action not in ("start", "end", "clear", "status"):
                    return self.err("bad action")
                c = get_course(body.get("course", "")) if body.get("course") else None
                cls = c["code"] if c else ""
                out = logpose(action, cls)
                sid = body.get("sid")
                if action == "start" and sid:
                    TIMER["active"][sid] = cls
                if action == "end":
                    TIMER["active"].clear()
                return self.send_json({"text": out})
            if path == "/api/profile":
                return self.send_json({"profile": save_profile(body)})
            if path == "/api/brain/codex/install":
                brain.CodexBrain.open_install()
                return self.send_json({"ok": True})
            if path == "/api/brain/codex/login":
                b = brain.CodexBrain(SETTINGS.get("codex_path", ""))
                if not b.path:
                    return self.err("Codex isn't installed yet. Click Install Codex first.")
                b.open_login(bool(body.get("device")), cwd=str(DRC_HOME))
                return self.send_json({"ok": True})
            if path == "/api/brain/gemini/key":
                key = (body.get("key") or "").strip()
                if not key:
                    return self.err("Paste the key first.")
                st = brain.GeminiBrain(key, SETTINGS.get("gemini_model", "")).status()
                if st.get("ready"):
                    canvas_sync.save_token(GEMINI_KEY_FILE, key)
                return self.send_json(st)
            if path == "/api/brain/test":
                out, err = [], None
                ctx = {"cwd": str(DRC_HOME), "paths": [], "text": ""}
                for kind, val in get_brain().send("You are a friendly tutor. Reply in one short sentence.", [],
                                                  "Say hi and tell me you're ready to help me study.", ctx):
                    if kind == "text":
                        out.append(val)
                    elif kind == "error":
                        err = val
                text = "".join(out).strip()
                return self.send_json({"ok": bool(text) and not err, "text": text, "error": err})
            if path == "/api/canvas/token":
                base = (body.get("url") or load_profile().get("canvas_url") or "").strip().rstrip("/")
                tok = (body.get("token") or "").strip()
                if not (base.startswith("https://") or re.match(r"http://(127\.0\.0\.1|localhost)[:/]", base + "/")):
                    return self.err("The Canvas address should start with https://")
                if not tok:
                    return self.err("Paste the token first.")
                try:
                    me = canvas_sync.Canvas(base, tok).whoami()
                except canvas_sync.CanvasError as e:
                    msg = ("Canvas didn't accept that token. Copy it again (the whole thing) or make a new one."
                           if e.status == 401 else f"Canvas said: {e}")
                    return self.send_json({"ok": False, "message": msg})
                except Exception as e:
                    return self.send_json({"ok": False, "message": f"Couldn't reach {base}: {e}"})
                canvas_sync.save_token(TOKEN_FILE, tok)
                save_profile({"canvas_url": base})
                return self.send_json({"ok": True, "message": f"Connected as {me.get('name', '?')}."})
            if path == "/api/canvas/sync":
                tok = canvas_sync.load_token(TOKEN_FILE)
                if not tok:
                    return self.err("No Canvas token saved yet.")
                canvas_sync.start_sync(load_profile().get("canvas_url"), tok, DRC_HOME)
                return self.send_json(canvas_status())
            if path == "/api/canvas/forget":
                try:
                    TOKEN_FILE.unlink()
                except OSError:
                    pass
                return self.send_json(canvas_status())
            if path == "/api/course/add":
                code = re.sub(r"\s+", " ", (body.get("code") or "").strip().upper())
                if not re.match(r"^[A-Z]{2,5} ?\d{3,4}[A-Z]{0,2}$", code):
                    return self.err("Write the class code like AE 2010 or ARO 1011L.")
                c = add_manual_course(code, (body.get("title") or "").strip(), (body.get("professor") or "").strip())
                load_courses(force=True)
                return self.send_json({"course": c, "courses": load_courses()})
            if path == "/api/update/check":
                if UPDATE:
                    UPDATE.manifest_url = manifest_url()
                    UPDATE.check()
                    threading.Thread(target=auto_stage, daemon=True).start()
                return self.send_json(update_status())
            if path == "/api/update/install":
                if not UPDATE:
                    return self.err("Updates only work in the installed app.")
                try:
                    UPDATE.stage()
                except Exception as e:
                    return self.send_json({**update_status(), "error": str(e)})
                UPDATE.apply(os.getpid(), relaunch_python(), launch_cmd(reuse=True))
                threading.Timer(0.8, shutdown, args=("installing update",)).start()
                return self.send_json({"ok": True, "restarting": True})
            if path == "/api/update/seen":
                if UPDATE:
                    st = UPDATE.read_state()
                    if st:
                        st["shown"] = True
                        UPDATE.write_state(st)
                return self.send_json(update_status())
            if path == "/api/command/send":
                txt = (body.get("text") or "").strip()
                if not txt:
                    return self.err("empty message")
                hist = [m for m in (body.get("history") or []) if isinstance(m, dict)][-10:]
                past = "\n".join(f"{'Student' if m.get('role') == 'user' else 'Command'}: {str(m.get('text', ''))[:600]}" for m in hist)
                return self.send_json(command_ask((f"Earlier in this chat:\n{past}\n\n" if past else "") + f"Student: {txt}"))
            if path == "/api/command/propose":
                return self.send_json({"proposals": RULES.propose(body.get("changes") or [])})
            if path == "/api/command/apply":
                n = RULES.apply(body.get("changes") or [], body.get("source") or "command")
                if body.get("why_log"):
                    RULES.log_feedback(body["why_log"], body.get("source") or "command")
                after_rules_change()
                return self.send_json({"applied": n, **command_state()})
            if path == "/api/command/inbox":
                it = RULES.take_inbox(str(body.get("id", "")))
                n = 0
                if it and body.get("accept") and it.get("proposal"):
                    n = RULES.apply([it["proposal"]["change"]], "check-in")
                    after_rules_change()
                return self.send_json({"applied": n, **command_state()})
            if path == "/api/command/retro":
                sid = body.get("sid", "")
                meta = get_session(sid)
                if not meta:
                    return self.err("unknown session", 404)
                chat = "\n\n".join(f"{m['role'].upper()}: {m.get('text', '')}" for m in load_chat(sid) if m.get("role") in ("user", "assistant"))
                if len(chat) > 24000:
                    chat = chat[:4000] + "\n…\n" + chat[-20000:]
                res = command_ask(f"Retro for the study session \"{meta.get('title', '')}\" ({meta.get('course_code', '')}). Read the chat below. "
                                  "Look for moments where the student was confused, corrected the tutor, got bored, or where something clearly worked. "
                                  "Reply with 2-4 lines on what you noticed, then propose AT MOST 3 rule changes (fixes for what went wrong, "
                                  "or rules that lock in what worked). Quote the student's words as the why.\n\n" + chat, max_changes=3)
                RULES.log_feedback(f"Retro of '{meta.get('title', '')}': {res['reply'][:300]}", "retro", meta.get("course_code", ""))
                return self.send_json(res)
            if path == "/api/chat/stop":
                return self.send_json({"stopped": stop_turn(body.get("sid", ""))})
            if path == "/api/chat/rename":
                s = get_session(body.get("sid", ""))
                if s and body.get("title"):
                    s["title"] = str(body["title"])[:120]
                    save_session(s)
                return self.send_json({"ok": True})
            if path == "/api/chat/send":
                return self.chat_send(body)
            if path == "/api/side/ask":
                qtext = (body.get("q") or "").strip()
                if not qtext:
                    return self.err("empty question")
                c = get_course(body.get("course", ""))
                ctx = []
                if c:
                    ctx.append(f"Class: {c['code']} {c['title']}.")
                if body.get("current"):
                    ctx.append(f"The practice question they are on in the main chat right now: {body['current']}")
                prompt = ("\n".join(ctx) + "\n\nTheir quick question: " + qtext) if ctx else qtext
                text, sid = run_side(prompt, body.get("sid"))
                return self.send_json({"text": text, "sid": sid})
            if path == "/api/clip/rate":
                rate_clip(str(body.get("id", "")), int(body.get("vote", 0)), body.get("q", ""))
                return self.send_json({"ok": True})
            if path == "/api/thoughts/add":
                c = get_course(body.get("course", ""))
                if not (body.get("text") or "").strip():
                    return self.err("empty thought")
                add_thought(c, body["text"], body.get("current", ""))
                return self.send_json(load_thoughts(c))
            if path == "/api/thoughts/insight":
                c = get_course(body.get("course", ""))
                th = load_thoughts(c)
                if not th["items"]:
                    return self.send_json({"text": "Write a few thoughts first, then I can look for patterns."})
                lines = "\n".join(f"- {t['when']}{' (' + t['q'] + ')' if t['q'] else ''}: {t['text']}" for t in th["items"][-60:])
                prompt = INSIGHT_PROMPT.format(name=who(), course=f"{c['code']} {c['title']}" if c else "their classes", thoughts=lines)
                if c and c.get("record"):
                    _, mast = find_section(read_text(c["record"]), "Mastery")
                    if mast:
                        prompt += "\n\nTheir Mastery section (use it to connect the dots):\n" + mast[:3000]
                text, _ = run_side(prompt, None, system="You are a sharp, kind study coach. Short answers.")
                return self.send_json({"text": text})
            return self.err("not found", 404)
        except PermissionError as e:
            return self.err(e, 403)
        except FileNotFoundError as e:
            return self.err(f"Not found: {e}", 404)
        except Exception as e:
            log.exception("POST %s", path)
            return self.err(e, 500)

    def chat_send(self, body):
        text = (body.get("text") or "").strip()
        sid = body.get("sid") or ""
        now = dt.datetime.now().isoformat(timespec="seconds")
        if sid:
            meta = get_session(sid)
            if not meta:
                return self.err("unknown session", 404)
            if sid in RUNNING:
                return self.err("Dr. Claude is still answering. Press Stop first.", 409)
            if not text and not body.get("files"):
                return self.err("empty message")
            first = False
            c = get_course(meta["course"]) or {"code": meta.get("course_code", meta["course"]), "title": ""}
            prev = [m for m in load_chat(sid) if m.get("role") == "assistant"]
            if prev and CHECKIN_RE.search(prev[-1].get("text", "")):
                threading.Thread(target=checkin_to_inbox, args=(prev[-1]["text"], text, c["code"]), daemon=True).start()
            prompt = text
            user_msg = {"role": "user", "text": text, "ts": now}
        else:
            c = get_course(body.get("course", ""))
            mode = body.get("mode") or "Office Hours"
            if not c:
                return self.err("Pick a course first.")
            if mode not in MODES:
                return self.err("unknown mode")
            sid = str(uuid.uuid4())
            first = True
            title = f"{mode} · {c['code']} · {dt.date.today().strftime('%b')} {dt.date.today().day}"
            meta = {"id": sid, "course": c["id"], "course_code": c["code"], "mode": mode, "title": title,
                    "created": now, "updated": now, "turns": 0}
            prompt = kickoff_prompt(mode, c, text)
            user_msg = ({"role": "user", "text": text, "ts": now} if text else
                        {"role": "note", "text": f"Started **{mode}** for **{c['code']}**", "ts": now})
        mode = meta["mode"]
        vnote = str(body.get("voice_note") or "")[:400]
        if vnote.startswith("[voice read") and SETTINGS.get("voice_conf"):
            prompt = prompt + NL2 + vnote   # hidden from the chat; only the tutor sees it
        new_files = self.take_attachments(body, sid)
        if new_files:
            user_msg = {"role": "user", "text": text, "ts": now,
                        "files": [{"name": p.name, "url": media_url(p), "image": p.suffix.lower() in IMAGE_EXTS, "size": p.stat().st_size}
                                  for p in new_files]}
            if not text and first:
                prompt = kickoff_prompt(mode, c, "(no message, just the attached files)")

        # SSE response (streamed over this POST; the page reads it with fetch)
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        alive = [True]

        def emit(obj):
            if not alive[0]:
                return
            try:
                self.wfile.write(f"data: {json.dumps(obj, ensure_ascii=False)}\n\n".encode("utf-8"))
                self.wfile.flush()
            except OSError:
                alive[0] = False  # window closed or navigated; keep the turn running and save it

        save_session(meta)
        append_chat(sid, user_msg)
        emit({"t": "session", "session": meta})

        # built-in study timer: starts with every study mode
        if SETTINGS.get("logpose") and mode in STUDY_MODES and sid not in TIMER["active"]:
            TIMER["active"][sid] = c["code"]
            logpose_async("start", c["code"])
            emit({"t": "timer", "text": f"Study timer started ({c['code']})"})

        history = [m for m in load_chat(sid) if m.get("role") in ("user", "assistant")][:-1]
        since, pics = time.time(), []
        final, tools, ok = run_turn(sid, meta, prompt, history, c, first, emit, new_files, pics)
        try:
            final = finish_pictures(polish_reply(final), sid, get_brain(), since, pics, emit)
        except Exception:
            log.exception("pictures")
        try:
            final = finish_made(final, sid, emit)
        except Exception:
            log.exception("make")
        notes = apply_record_updates(final, get_course(meta["course"]))
        for n in notes:
            tools.append({"icon": "✏️", "text": n})
            emit({"t": "tool", "icon": "✏️", "text": n})
        final = voice_conf.take_voicecal(VOICE_PROFILE, final)
        shown = strip_markers(final)
        markers = MARKER_RE.findall(final)
        timer_note = ""
        if markers and SETTINGS.get("logpose") and mode in STUDY_MODES:
            act, mins = markers[-1]
            act = act.split()[0].lower()
            if act == "problem":
                logpose_async("problem", c["code"])
                timer_note = f"Problem timer: ~{mins} min"
            elif act == "clear":
                logpose_async("clear")
                timer_note = "Explaining (no problem pending)"
            elif act == "end":
                TIMER["active"].pop(sid, None)
                logpose_async("end")
                timer_note = "Study session saved"
        if shown or tools:
            append_chat(sid, {"role": "assistant", "text": shown, "tools": tools,
                              "ts": dt.datetime.now().isoformat(timespec="seconds"), "timer": timer_note})
        meta["updated"] = dt.datetime.now().isoformat(timespec="seconds")
        meta["turns"] = meta.get("turns", 0) + 1
        save_session(meta)
        emit({"t": "done", "session": meta, "timer": timer_note, "ok": ok})

    def voice_api(self, path, body):
        """🎤 Voice upgrade (Whisper) + voice confidence reader. Audio stays in memory; only numbers are saved."""
        if path == "/api/stt/status":
            st = stt.status()
            st.update(conf=bool(SETTINGS.get("voice_conf")), model=SETTINGS.get("voice_model") or "")
            st["available"] = st["available"] and bool(SETTINGS.get("voice_model")) and stt.model_ready(SETTINGS.get("voice_model"))
            return self.send_json(st)
        if path == "/api/voice/info":
            return self.send_json(dict(voice_setup.info(), settings={"voice_model": SETTINGS.get("voice_model") or "",
                                                                    "voice_conf": bool(SETTINGS.get("voice_conf"))},
                                       profile=voice_conf.summary(VOICE_PROFILE)))
        if path == "/api/voice/setup":
            model = body.get("model") or stt.DEFAULT_MODEL
            if model not in stt.MODEL_INFO:
                return self.err("unknown model")
            return self.send_json(start_voice_install(model))
        if path == "/api/voice/remove":
            SETTINGS.update(save_settings({"voice_model": "", "voice_conf": False}))
            return self.send_json(voice_setup.remove())
        if path == "/api/voice/conf":
            SETTINGS.update(save_settings({"voice_conf": bool(body.get("on"))}))
            return self.send_json({"voice_conf": bool(SETTINGS.get("voice_conf"))})
        if path == "/api/voice/forget":
            voice_conf.Profile(VOICE_PROFILE).forget()
            return self.send_json({"ok": True, "profile": voice_conf.summary(VOICE_PROFILE)})
        model = SETTINGS.get("voice_model") or ""
        if not model or not stt.available():
            return self.send_json({"text": "", "label": "OFF", "note": ""})
        c = get_course(body.get("course", "")) if body.get("course") else None
        prompt = stt.prompt_for(c["code"] if c else "", (c.get("title") or "") if c else "",
                                load_profile().get("major", ""), voice_topics(c))
        wav = base64.b64decode(body.get("wav", ""))
        if path == "/api/stt":
            return self.send_json({"text": stt.transcribe_wav(wav, prompt, model)})
        if path == "/api/voice/read":
            if not SETTINGS.get("voice_conf"):
                return self.send_json({"label": "OFF", "note": ""})
            pd = body.get("pre_delay")
            r = voice_conf.read_answer(VOICE_PROFILE, voice_conf.wav_to_pcm(wav), stt.load(model),
                                       float(pd) if isinstance(pd, (int, float)) else None, prompt)
            log.info("voice read: %s p=%s raw=%s", r.get("label"), r.get("p"), r.get("raw"))
            return self.send_json({"label": r["label"], "note": r["note"], "calibrate": r.get("calibrate", False)})
        return self.err("unknown voice route", 404)

    def take_attachments(self, body, sid):
        """Move the files picked for this message from the draft folder into the chat's own folder."""
        names = [str(n) for n in body.get("files") or []]
        if not names or not body.get("draft"):
            return []
        src = draft_dir(body["draft"])
        out = []
        for n in names:
            p = src / Path(n).name
            if p.is_file():
                dest = unique_path(chat_media(sid, "files"), p.name)
                shutil.move(str(p), dest)
                out.append(dest)
        shutil.rmtree(src, ignore_errors=True)
        return out

    def attach(self):
        """Raw file body -> MEDIA/_drafts/<draft>/<name> (a chat attachment, not the class library)."""
        q = {k: v[0] for k, v in urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).items()}
        n = int(self.headers.get("Content-Length") or 0)
        if n > 50 * 1024 * 1024:
            return self.err("That file is over 50 MB. Put big files in the Library instead.")
        name = canvas_sync.safe_name(Path(q.get("name", "")).name or "file")
        if Path(name).suffix.lower() not in IMAGE_EXTS | TEXT_EXTS | {".docx", ".pptx", ".py", ".c", ".cpp", ".h", ".java", ".m", ".tex", ".json"}:
            return self.err("Dr. Claude can read pictures (PNG, JPG), PDFs, Word, PowerPoint and text files.")
        dest = unique_path(draft_dir(q.get("draft", "")), name)
        data = self.rfile.read(n) if n else b""
        if len(data) != n:
            return self.err("upload was cut off")
        dest.write_bytes(data)
        return self.send_json({"ok": True, "name": dest.name, "url": media_url(dest), "size": n,
                               "image": dest.suffix.lower() in IMAGE_EXTS})

    def serve_media(self, rel):
        parts = [urllib.parse.unquote(x) for x in rel.split("/") if x]
        p = MEDIA.joinpath(*parts).resolve() if parts else MEDIA
        if not str(p).startswith(str(MEDIA.resolve()) + os.sep) or not p.is_file():
            return self.err("not found", 404)
        b = p.read_bytes()
        rng = re.match(r"bytes=(\d*)-(\d*)$", self.headers.get("Range") or "")
        lo, hi = 0, len(b) - 1
        if rng and (rng.group(1) or rng.group(2)):
            if rng.group(1):
                lo, hi = int(rng.group(1)), min(int(rng.group(2) or hi), hi)
            else:
                lo = max(0, len(b) - int(rng.group(2)))
            if lo > hi:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{len(b)}")
                self.end_headers()
                return
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {lo}-{hi}/{len(b)}")
        else:
            self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(str(p))[0] or "application/octet-stream")
        self.send_header("Content-Length", str(hi - lo + 1))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Cache-Control", "private, max-age=86400")
        if p.suffix.lower() in (".html", ".htm"):
            self.send_header("Content-Security-Policy", "sandbox allow-scripts allow-modals allow-forms")
        self.end_headers()
        self.wfile.write(b[lo:hi + 1])

    def upload(self):
        """Raw file body -> <course>\\My Files\\<rel>. ?course=<id>&rel=<relative path from the picker>"""
        if self.headers.get("X-Dr-Claude") != "1":
            return self.err("missing app header", 403)
        q = {k: v[0] for k, v in urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).items()}
        c = get_course(q.get("course", ""))
        if not c or not c.get("folder"):
            return self.err("Pick a class first.")
        n = int(self.headers.get("Content-Length") or 0)
        if n > 300 * 1024 * 1024:
            return self.err("That file is over 300 MB.")
        parts = [canvas_sync.safe_name(x) for x in re.split(r"[\\/]+", q.get("rel", "")) if x not in ("", ".", "..")]
        if not parts:
            return self.err("missing file name")
        root = (Path(c["folder"]) / "My Files").resolve()
        dest = root.joinpath(*parts).resolve()
        if not str(dest).startswith(str(root) + os.sep):
            return self.err("bad path", 403)
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_name(dest.name + ".part")
        left = n
        with open(tmp, "wb") as f:
            while left > 0:
                chunk = self.rfile.read(min(left, 1 << 20))
                if not chunk:
                    break
                f.write(chunk)
                left -= len(chunk)
        if left:
            tmp.unlink(missing_ok=True)
            return self.err("upload was cut off")
        os.replace(tmp, dest)
        return self.send_json({"ok": True, "path": str(dest)})


def canvas_status():
    st = {k: canvas_sync.STATE.get(k) for k in ("running", "phase", "course", "done", "total", "files_new",
                                                "files_same", "errors", "started", "finished", "courses")}
    st["log"] = canvas_sync.STATE.get("log", [])[-12:]
    st["has_token"] = TOKEN_FILE.exists()
    st["url"] = load_profile().get("canvas_url", "")
    try:
        idx = json.loads(COURSES_FILE.read_text(encoding="utf-8"))
        st["synced"], st["via"] = idx.get("synced"), idx.get("via", "token" if st["has_token"] else "")
    except (OSError, ValueError):
        st["synced"], st["via"] = None, ""
    st["connected"] = st["has_token"] or (st["via"] == "browser" and bool(st["synced"]))
    st["bridge_port"] = canvas_bridge.Config.port
    return st


# ----------------------------------------------------------------------------- updates
def update_status():
    out = {"version": VERSION, "installed": bool(UPDATE), "auto": SETTINGS.get("auto_update", True)}
    if UPDATE:
        out.update(UPDATE.status)
        st = UPDATE.read_state()
        if st.get("status") in ("ok", "rolled_back") and not st.get("shown"):
            out["event"] = {"kind": st["status"], "from": st.get("from"), "to": st.get("to"), "notes": st.get("notes", "")}
    return out


def relaunch_python():
    exe = Path(sys.executable)
    w = exe.with_name("pythonw.exe")
    return str(w) if exe.name.lower() == "python.exe" and w.exists() and not os.environ.get("DRC_NO_WINDOW") else str(exe)


def launch_cmd(reuse=False):
    """How the updater restarts the app. reuse=True: same port, no new window (the open window reconnects)."""
    args, skip = [], False
    for a in sys.argv[1:]:
        if skip:
            skip = False
        elif a == "--port":
            skip = True
        elif a != "--reuse-window":
            args.append(a)
    if reuse and State.port:
        args += ["--port", str(State.port), "--reuse-window"]
    return [relaunch_python(), str(APP_DIR / "dr_claude.py")] + args


def auto_stage():
    """Auto-update on: download + verify a found update now; it installs the next time the app starts."""
    st = UPDATE.status
    if st.get("available") and not st.get("staged") and SETTINGS.get("auto_update", True) and not st.get("too_old") and not st.get("failed_before"):
        try:
            UPDATE.stage()
        except Exception as e:
            UPDATE.status["error"] = str(e)
            log.warning("auto stage failed: %s", e)


def update_loop():
    time.sleep(float(os.environ.get("DRC_UPDATE_FIRST_CHECK") or 8))
    while True:
        UPDATE.manifest_url = manifest_url()
        UPDATE.check()
        auto_stage()
        time.sleep(updates.CHECK_EVERY)


def apply_staged_at_start():
    """Auto-install: a verified update downloaded last time gets installed before the app starts."""
    if not (UPDATE and SETTINGS.get("auto_update", True)):
        return False
    v = UPDATE.staged_version()
    st = UPDATE.read_state()
    if not v or updates.vtuple(v) <= updates.vtuple(VERSION) or (st.get("status") == "rolled_back" and st.get("to") == v):
        return False
    log.info("installing staged update %s at start", v)
    UPDATE.apply(os.getpid(), relaunch_python(), launch_cmd())
    return True


def report_started():
    """Tell a waiting updater that this (new) version is up and on which port."""
    if not UPDATE:
        return
    st = UPDATE.read_state()
    if st.get("status") == "testing" and st.get("to") == VERSION:
        st.update(status="started", port=State.port, pid=os.getpid())
        UPDATE.write_state(st)


# ----------------------------------------------------------------------------- launch / lifecycle
SERVER_FILE = DATA / "server.json"


def existing_server():
    try:
        info = json.loads(SERVER_FILE.read_text(encoding="utf-8"))
        with urllib.request.urlopen(f"http://127.0.0.1:{info['port']}/api/ping", timeout=1.5) as r:
            if json.loads(r.read()).get("app") == "dr-claude":
                return info["port"]
    except Exception:
        return None


def open_window(port):
    if os.environ.get("DRC_NO_WINDOW"):  # tests
        return None
    edge = SETTINGS.get("edge")
    url = f"http://127.0.0.1:{port}/"
    if edge and os.path.isfile(edge):
        prof = DATA / "edge-profile"
        return subprocess.Popen([edge, f"--app={url}", "--window-size=1280,860", f"--user-data-dir={prof}",
                                 "--no-first-run", "--no-default-browser-check", "--disable-features=Translate"])
    import webbrowser
    webbrowser.open(url)
    return None


def shutdown(reason):
    log.info("shutting down: %s", reason)
    for sid in list(RUNNING):
        stop_turn(sid)
    if TIMER["active"] and SETTINGS.get("logpose"):
        logpose("end")  # closing the app = done studying; banks the block
    try:
        SERVER_FILE.unlink()
    except OSError:
        pass
    os._exit(0)


def monitor(edge_proc):
    started = time.time()
    while True:
        time.sleep(2)
        now = time.time()
        if RUNNING and now - State.last_beat < 600:
            continue  # let a tutor turn finish if the page is just busy/hidden
        if State.bye_at and now - State.bye_at > 8 and State.last_beat < State.bye_at:
            shutdown("window closed")
        if now - State.last_beat > 180:
            shutdown("no heartbeat")
        if edge_proc is not None and edge_proc.poll() is not None and now - started > 15 and now - State.last_beat > 20:
            shutdown("edge exited")


def main():
    if apply_staged_at_start():
        return
    headless = "--headless" in sys.argv
    reuse = "--reuse-window" in sys.argv  # restarted by the updater: the open window reconnects by itself
    port = None
    if "--port" in sys.argv:
        port = int(sys.argv[sys.argv.index("--port") + 1])
    if not headless and not reuse:
        p = existing_server()
        if p:  # already running: just open another window
            open_window(p)
            return
    shutil.rmtree(MEDIA / "_drafts", ignore_errors=True)  # attachments picked but never sent
    books.clear_pending(PENDING)  # textbook downloads nobody said yes to
    if port is None:
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            port = s.getsockname()[1]
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    except OSError:  # the old port is taken: pick a new one and open a fresh window
        srv, reuse = ThreadingHTTPServer(("127.0.0.1", 0), Handler), False
        port = srv.server_address[1]
    State.port = port
    srv.daemon_threads = True
    State.server = srv
    if not headless:
        SERVER_FILE.write_text(json.dumps({"port": port, "pid": os.getpid()}), encoding="utf-8")
    log.info("serving on http://127.0.0.1:%s headless=%s version=%s", port, headless, VERSION)
    try:
        bp = canvas_bridge.serve(DATA, DRC_HOME, lambda: load_profile().get("canvas_url", ""), lambda: load_courses(force=True))
        log.info("canvas browser bridge on port %s", bp)
    except Exception as e:  # never let the bridge stop the app from starting
        log.warning("canvas bridge failed: %r", e)
    threading.Thread(target=ensure_guide_course, daemon=True).start()
    threading.Thread(target=auto_voice_once, daemon=True).start()   # v1.4.4: voice on for everyone by default
    if SETTINGS.get("voice_model"):
        stt.warm_async(SETTINGS["voice_model"])  # loads Whisper in the background so the first phrase is fast
    threading.Thread(target=IDEAS.send_waiting, daemon=True).start()
    report_started()
    if UPDATE:
        threading.Thread(target=update_loop, daemon=True).start()
    if headless:
        print(f"Dr. Claude running at http://127.0.0.1:{port}/", flush=True)
        srv.serve_forever()
        return
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    State.last_beat = time.time()
    edge = None if reuse else open_window(port)
    monitor(edge)


if __name__ == "__main__":
    main()
