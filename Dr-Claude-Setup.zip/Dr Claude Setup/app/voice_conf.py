"""Voice confidence reader (2026-11-11). Same file in his App and in Dist\\Dr Claude Portable.

When a student answers OUT LOUD, Whisper hears the whole answer with word timings and this module measures
HOW it was said: start delay, pauses, fillers (um/uh), restarts, hedges (I think / maybe), speech rate and
whether the pitch rises at the end (question tone). Each number is compared ONLY to that student's own normal
(running mean/std in voice_profile.json), never to other people: a natural stutter or slow talker is not "unsure".

Research basis (Report 8 section 6, verified): Smith & Clark 1993 and Brennan & Williams 1995 found that longer
answer delays, fillers and rising intonation go with lower "feeling of knowing". These were small lab trivia
studies, so the result is a HINT for the tutor, never a verdict, and the tutor never comments on how anyone talks.

Privacy: audio arrives in memory, is analyzed, and is dropped. Only the numbers below are saved.
"""
import json
import math
import re
import threading
import time
from pathlib import Path

FEATURES = ["start_delay", "gap_mean", "gap_max", "long_gaps", "fillers", "restarts", "hedges", "slowness", "pitch_rise"]
# smallest believable spread per feature, so a very steady talker doesn't turn tiny wobbles into big z-scores
STD_FLOOR = {"start_delay": 1.5, "gap_mean": 0.08, "gap_max": 0.35, "long_gaps": 0.6, "fillers": 0.6,
             "restarts": 0.4, "hedges": 0.4, "slowness": 0.3, "pitch_rise": 0.06}
BASELINE_N = 8          # answers needed before labels start
CALIBRATE_EVERY = 5     # every Nth labeled answer, the tutor asks "how sure, 1-5?"
FIT_AFTER = 15          # self-ratings needed before per-person weights replace equal weights

FILLER_PROMPT = "Umm, uh, let me think, like, hmm, so, uh, I mean, um. "
FILLERS = {"um", "umm", "ummm", "uh", "uhh", "uhm", "er", "erm", "hmm", "hm", "mm", "mmm", "ah", "eh"}
HEDGES = ("i think", "i guess", "maybe", "probably", "not sure", "i'm not sure", "kind of", "sort of", "might be",
          "i believe", "possibly", "perhaps", "or something", "i don't know", "idk")
RESTART_PHRASES = ("no wait", "wait no", "i mean", "actually", "scratch that", "sorry", "let me rephrase", "no no")

_lock = threading.Lock()


def _norm(w):
    return re.sub(r"[^a-z']", "", w.lower())


# ------------------------------------------------------------------ pitch (simple autocorrelation)
def _pitch_track(pcm, sr=16000):
    """Return (times, f0) for voiced 40 ms frames (10 ms hop), f0 in Hz. Pure numpy, no extra packages."""
    import numpy as np
    frame, hop = int(0.04 * sr), int(0.01 * sr)
    if len(pcm) < frame:
        return np.array([]), np.array([])
    n = 1 + (len(pcm) - frame) // hop
    idx = np.arange(frame)[None, :] + hop * np.arange(n)[:, None]
    fr = pcm[idx] * np.hanning(frame)[None, :]
    energy = (fr ** 2).mean(axis=1)
    thr = max(1e-6, np.percentile(energy, 60) * 0.3)
    spec = np.fft.rfft(fr, n=2 * frame, axis=1)
    ac = np.fft.irfft(np.abs(spec) ** 2, axis=1)[:, :frame]
    ac = ac / np.maximum(ac[:, :1], 1e-12)
    lo, hi = int(sr / 400), int(sr / 70)            # 70-400 Hz voice range
    seg = ac[:, lo:hi]
    lag = seg.argmax(axis=1) + lo
    peak = seg.max(axis=1)
    voiced = (energy > thr) & (peak > 0.35)
    t = (np.arange(n) * hop + frame / 2) / sr
    return t[voiced], (sr / lag[voiced]).astype(float)


def _pitch_rise(pcm, end_t, sr=16000):
    """Pitch over the last ~400 ms of speech vs the answer's median. +0.15 = ends 15% higher (question tone)."""
    import numpy as np
    t, f0 = _pitch_track(pcm, sr)
    if len(f0) < 15:
        return None
    med = float(np.median(f0))
    tail = f0[(t >= end_t - 0.4) & (t <= end_t + 0.05)]
    if len(tail) < 4 or med <= 0:
        return None
    return float(np.median(tail[-max(4, len(tail) // 2):]) / med - 1.0)


# ------------------------------------------------------------------ features from one spoken answer
def analyze(pcm, model, pre_delay=None, prompt=""):
    """pcm = float32 mono 16 kHz. model = a faster_whisper.WhisperModel. pre_delay = seconds between the tutor's
    question appearing and the mic starting (None if unknown). Returns dict(features, words, text, dur)."""
    segs, _ = model.transcribe(pcm, language="en", beam_size=5, word_timestamps=True, vad_filter=False,
                               condition_on_previous_text=False, initial_prompt=(FILLER_PROMPT + (prompt or ""))[:800])
    words = []
    for s in segs:
        for w in (s.words or []):
            if w.word.strip():
                words.append((w.word.strip(), float(w.start), float(w.end)))
    text = " ".join(w for w, _, _ in words)
    out = {"text": text, "words": len(words), "dur": len(pcm) / 16000.0, "features": None}
    try:  # 11/12: no confidence read from a junk transcript or a too-short clip
        import stt
        if len(pcm) < 16000 * stt.MIN_SECONDS or stt.looks_junk(text):
            return out
    except Exception:
        pass
    real = [w for w in words if _norm(w[0]) not in FILLERS]
    if len(real) < 2:
        return out
    toks = [_norm(w) for w, _, _ in words]
    nw = max(1, len(real))
    per10 = 10.0 / nw
    gaps = [max(0.0, words[i + 1][1] - words[i][2]) for i in range(len(words) - 1)]
    joined = " " + " ".join(toks) + " "
    restarts = sum(1 for i in range(len(toks) - 1) if toks[i] and toks[i] == toks[i + 1] and toks[i] not in FILLERS)
    restarts += sum(joined.count(" " + p + " ") for p in RESTART_PHRASES)
    hedges = sum(joined.count(" " + h + " ") for h in HEDGES)
    span = max(0.3, real[-1][2] - real[0][1])
    first_word = words[0][1]
    f = {
        "start_delay": min(120.0, (pre_delay if pre_delay is not None and pre_delay >= 0 else 0.0) + first_word),
        "gap_mean": sum(gaps) / len(gaps) if gaps else 0.0,
        "gap_max": max(gaps) if gaps else 0.0,
        "long_gaps": sum(1 for g in gaps if g > 0.6) * per10,
        "fillers": sum(1 for t in toks if t in FILLERS) * per10,
        "restarts": restarts * per10,
        "hedges": hedges * per10,
        "slowness": -(nw / span),                      # words per second, negated so "higher = more unsure"
        "pitch_rise": _pitch_rise(pcm, words[-1][2]),
    }
    if pre_delay is None:
        f["start_delay"] = None                        # unknown: don't guess
    out["features"] = f
    out["raw"] = {"fillers": sum(1 for t in toks if t in FILLERS), "restarts": restarts, "hedges": hedges,
                  "long_gaps": sum(1 for g in gaps if g > 0.6), "wps": round(nw / span, 2)}
    return out


# ------------------------------------------------------------------ the student's own normal
class Profile:
    def __init__(self, path):
        self.path = Path(path)
        self.d = self._load()

    def _load(self):
        try:
            d = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            d = {}
        d.setdefault("stats", {})
        d.setdefault("answers", 0)
        d.setdefault("labeled", 0)
        d.setdefault("pairs", [])
        d.setdefault("weights", None)
        d.setdefault("pending", None)
        return d

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.d, indent=1), encoding="utf-8")
        tmp.replace(self.path)

    def forget(self):
        try:
            self.path.unlink()
        except FileNotFoundError:
            pass
        self.d = self._load()

    def _std(self, k):
        s = self.d["stats"].get(k)
        if not s or s["n"] < 2:
            return STD_FLOOR[k]
        return max(STD_FLOOR[k], math.sqrt(s["m2"] / (s["n"] - 1)))

    def z(self, f):
        z = {}
        for k in FEATURES:
            v, s = f.get(k), self.d["stats"].get(k)
            if v is None or not s or s["n"] < 3:
                continue
            z[k] = max(-4.0, min(4.0, (v - s["mean"]) / self._std(k)))
        return z

    def update(self, f):
        for k in FEATURES:
            v = f.get(k)
            if v is None:
                continue
            s = self.d["stats"].setdefault(k, {"n": 0, "mean": 0.0, "m2": 0.0})
            s["n"] += 1
            dlt = v - s["mean"]
            s["mean"] += dlt / s["n"]
            s["m2"] += dlt * (v - s["mean"])
        self.d["answers"] += 1

    def p_unsure(self, z):
        if not z:
            return 0.5
        w = self.d.get("weights")
        if w:
            x = sum(w["w"].get(k, 0.0) * v for k, v in z.items()) + w["b"]
        else:
            x = 1.4 * sum(z.values()) / math.sqrt(len(z))   # equal weights; sqrt keeps it from overreacting
        return 1.0 / (1.0 + math.exp(-x))

    # -------------------------------------------------------------- calibration ("how sure, 1-5?")
    def add_pair(self, sure, correct):
        p = self.d.get("pending")
        if not p:
            return False
        self.d["pairs"].append({"z": p["z"], "sure": int(sure), "correct": correct, "ts": int(time.time())})
        self.d["pending"] = None
        if len(self.d["pairs"]) >= FIT_AFTER:
            self.fit()
        return True

    def fit(self):
        """Per-person logistic weights: which of THIS student's voice signals predict a low self-rating (1-2)."""
        import numpy as np
        P = [p for p in self.d["pairs"] if p.get("z")]
        if len(P) < FIT_AFTER:
            return
        X = np.array([[p["z"].get(k, 0.0) for k in FEATURES] for p in P], dtype=float)
        y = np.array([1.0 if p["sure"] <= 2 else 0.0 for p in P])
        if y.min() == y.max():
            return                                      # all sure or all unsure: nothing to learn yet
        w, b = np.zeros(len(FEATURES)), 0.0
        for _ in range(800):                            # L2-regularized gradient descent, tiny data
            pr = 1 / (1 + np.exp(-(X @ w + b)))
            gw = X.T @ (pr - y) / len(y) + 0.1 * w
            gb = float((pr - y).mean())
            w -= 0.3 * gw
            b -= 0.3 * gb
        self.d["weights"] = {"w": {k: round(float(v), 4) for k, v in zip(FEATURES, w)}, "b": round(b, 4), "n": len(P)}


REASON = {"start_delay": "long start", "gap_mean": "slower pauses", "gap_max": "a long pause",
          "long_gaps": "several pauses", "fillers": "fillers", "restarts": "restarted",
          "hedges": "hedging words", "slowness": "slower than usual", "pitch_rise": "rising end"}
REASON_LOW = {"start_delay": "quick start", "fillers": "no fillers", "slowness": "steady pace", "pitch_rise": "falling end"}


def read_answer(profile_path, pcm, model, pre_delay=None, prompt=""):
    """Analyze one spoken answer, label it against the student's own normal, update the normal, and return
    {label, note, calibrate, p, reasons, raw}. label: SURE / MIXED / UNSURE, or LEARNING (baseline not ready)."""
    a = analyze(pcm, model, pre_delay, prompt)
    if not a["features"]:
        return {"label": "NONE", "note": "", "calibrate": False, "text": a["text"]}
    f = a["features"]
    with _lock:
        prof = Profile(profile_path)
        ready = prof.d["answers"] >= BASELINE_N
        z = prof.z(f) if ready else {}
        p = prof.p_unsure(z) if ready else 0.5
        prof.update(f)
        calibrate = False
        if ready:
            prof.d["labeled"] += 1
            calibrate = prof.d["labeled"] % CALIBRATE_EVERY == 0
            if calibrate:
                prof.d["pending"] = {"z": z, "ts": int(time.time())}
        prof.save()
        n = prof.d["answers"]
    raw = a.get("raw", {})
    if not ready:
        label = "LEARNING"
        note = f"[voice read: still learning this student's normal ({n}/{BASELINE_N} answers), no label yet]"
    else:
        strong = [k for k, v in z.items() if v >= 1.0]
        # a label needs real evidence: lots of tiny wobbles adding up is just a normal answer
        if p >= 0.65 and (len(strong) >= 2 or any(z[k] >= 2.0 for k in strong)):
            label = "UNSURE"
        elif not strong or p <= 0.4:
            label = "SURE"
        else:
            label = "MIXED"
        hi = sorted(strong, key=lambda k: -z[k])[:3]
        lo = [k for k, v in z.items() if v <= -1.0 and k in REASON_LOW][:2]
        bits = []
        for k in hi:
            r = REASON[k]
            if k == "fillers" and raw.get("fillers"):
                r = f"{raw['fillers']} filler{'s' if raw['fillers'] != 1 else ''}"
            if k == "start_delay" and f.get("start_delay") is not None:
                r = f"long start ({f['start_delay']:.0f}s)"
            bits.append(r)
        if label == "SURE":
            bits = [REASON_LOW[k] for k in lo] or ["matches their usual steady voice"]
        note = f"[voice read (hint only): likely {label}" + (f": {', '.join(bits)}" if bits else "") + "]"
        if calibrate:
            note += (" [calibrate: BEFORE saying if it's right, ask 'how sure were you, 1-5?'; when they answer, "
                     "end your reply with [[voicecal sure=N correct=yes|no]]]")
    return {"label": label, "note": note, "calibrate": calibrate, "p": round(p, 3),
            "z": {k: round(v, 2) for k, v in z.items()}, "features": {k: (None if v is None else round(v, 3)) for k, v in f.items()},
            "raw": raw, "text": a["text"]}


VOICECAL_RE = re.compile(r"\[\[\s*voicecal\s+sure\s*=\s*([1-5])\s+correct\s*=\s*(yes|no)\s*\]\]", re.I)


def take_voicecal(profile_path, text):
    """Strip [[voicecal sure=N correct=yes|no]] tags from a tutor reply and save the calibration pair."""
    m = VOICECAL_RE.findall(text or "")
    if m:
        with _lock:
            prof = Profile(profile_path)
            sure, corr = m[-1]
            if prof.add_pair(int(sure), corr.lower() == "yes"):
                prof.save()
    return VOICECAL_RE.sub("", text or "").rstrip()


def summary(profile_path):
    prof = Profile(profile_path)
    d = prof.d
    return {"answers": d["answers"], "baseline_ready": d["answers"] >= BASELINE_N, "baseline_n": BASELINE_N,
            "ratings": len(d["pairs"]), "personal_weights": bool(d.get("weights"))}


def wav_to_pcm(wav_bytes):
    import io
    import wave
    import numpy as np
    with wave.open(io.BytesIO(wav_bytes)) as w:
        sr, n, ch = w.getframerate(), w.getnframes(), w.getnchannels()
        pcm = np.frombuffer(w.readframes(n), dtype=np.int16).astype("float32") / 32768.0
    if ch > 1:
        pcm = pcm.reshape(-1, ch).mean(axis=1)
    if sr != 16000:
        idx = np.linspace(0, len(pcm) - 1, int(len(pcm) * 16000 / sr))
        pcm = np.interp(idx, np.arange(len(pcm)), pcm).astype("float32")
    return pcm
