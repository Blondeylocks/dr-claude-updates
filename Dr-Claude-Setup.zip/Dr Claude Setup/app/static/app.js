// Dr. Claude front end (plain JS, no build step, no libraries).
// The system:  hash router  ->  screen renderers  ->  /api/* on the local Python server (127.0.0.1 only).
// Classroom chat streams over POST /api/chat/send (Server-Sent Events read with fetch).
(function () {
  'use strict';

  // ------------------------------------------------------------------ helpers
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
  const h = s => MD.esc(String(s == null ? '' : s));
  const md = s => MD.render(s || '');
  const view = $('#view');
  const STATUS = ['✅', '🟡', '❌', '⬜'];
  const MCLASS = { '✅': 'm-ok', '🟡': 'm-shaky', '❌': 'm-no', '⬜': 'm-none' };
  const MODE_INFO = {
    'Lecture': 'Teaches the next topic on the Pacing Calendar.',
    'Homework': "A problem set like your professor's. You try first.",
    'Quiz': 'A quiz in the real quiz format, one question at a time.',
    'Mock Exam': 'A practice exam built like the real one, graded at the end.',
    'Office Hours': "Ask about anything you're stuck on.",
    'Replay a Course': 'Re-take a course week by week.',
    'Log a Class': "Tell Dr. Claude what today's real class covered.",
  };
  const STUDY_MODES = new Set(Object.keys(MODE_INFO).filter(m => m !== 'Log a Class'));

  const APP = { state: null, tok: 0 };

  async function api(path, body) {
    const opt = body === undefined ? {} : {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Dr-Claude': '1' },
      body: JSON.stringify(body),
    };
    const r = await fetch(path, opt);
    let j = {};
    try { j = await r.json(); } catch (e) { /* not json */ }
    if (!r.ok) throw new Error(j.error || `${r.status} ${r.statusText}`);
    return j;
  }

  let toastTimer = 0;
  function toast(msg, ms = 2600) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), ms);
  }

  const lsGet = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* private mode */ } };

  const dateOf = iso => new Date(iso.length <= 10 ? iso + 'T12:00:00' : iso);
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const DAY = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const fmtDay = iso => { const d = dateOf(iso); return `${DAY[d.getDay()]} ${MON[d.getMonth()]} ${d.getDate()}`; };
  const fmtTime = iso => dateOf(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const fmtStamp = iso => iso ? `${fmtDay(iso)}, ${fmtTime(iso)}` : '';
  const fmtMin = m => m >= 60 ? `${Math.floor(m / 60)}h ${Math.round(m % 60)}m` : `${Math.round(m)}m`;
  const fmtSize = b => b < 1024 ? `${b} B` : b < 1048576 ? `${(b / 1024).toFixed(0)} KB` : `${(b / 1048576).toFixed(1)} MB`;
  const baseName = p => String(p || '').split(/[\\/]/).filter(Boolean).pop() || p;
  const courses = (past = false) => (APP.state ? APP.state.courses : []).filter(c => !!c.past === past);
  const courseById = id => (APP.state ? APP.state.courses : []).find(c => c.id === id);
  const stripMarkers = s => String(s || '').replace(/```record-update[\s\S]*?(```|$)/g, '')
    .replace(/[ \t]*\[\[\s*(?:logpose|timer)[^\]]*\]\][ \t]*\n?/gi, '').replace(/\[\[\s*[lt]?[a-z]*[^\]]*$/i, '').trimEnd();

  function mbar(counts) {
    const total = STATUS.reduce((a, s) => a + (counts[s] || 0), 0);
    if (!total) return '<div class="mbar"></div>';
    return '<div class="mbar">' + STATUS.map(s => counts[s] ?
      `<span class="${MCLASS[s]}" style="width:${(100 * counts[s] / total).toFixed(2)}%" title="${counts[s]} ${s}"></span>` : '').join('') + '</div>';
  }
  const mcounts = counts => `<div class="mcounts">${STATUS.map(s => `<span>${s} ${counts[s] || 0}</span>`).join('')}</div>`;

  function emptyBox(icon, title, text, extra = '') {
    return `<div class="empty"><div class="big">${icon}</div><h2>${h(title)}</h2><p>${text}</p>${extra}</div>`;
  }

  async function openPath(path, how = 'default') {
    try {
      await api('/api/open', { path, how });
      toast(how === 'reveal' ? 'Showing it in File Explorer…' : `Opening ${baseName(path)}…`);
    } catch (e) { toast(e.message, 4000); }
  }

  // ------------------------------------------------------------------ theme
  const THEMES = ['system', 'light', 'dark'];
  const THEME_ICON = { system: '◐', light: '☀', dark: '☾' };
  function applyTheme(t) {
    if (!THEMES.includes(t)) t = 'system';
    const root = document.documentElement;
    if (t === 'system') root.removeAttribute('data-theme'); else root.setAttribute('data-theme', t);
    lsSet('drc-theme', t);
    $('#themeIcon').textContent = THEME_ICON[t];
    $('#themeBtn').title = `Theme: ${t} (click to switch)`;
    return t;
  }
  $('#themeBtn').addEventListener('click', async () => {
    const cur = (APP.state && APP.state.settings.theme) || lsGet('drc-theme') || 'system';
    const t = applyTheme(THEMES[(THEMES.indexOf(cur) + 1) % THEMES.length]);
    toast(`Theme: ${t}`);
    try { const r = await api('/api/settings', { theme: t }); APP.state.settings = r.settings; } catch (e) { /* keep local */ }
  });

  // ------------------------------------------------------------------ router
  function parseHash() {
    const raw = location.hash.replace(/^#\/?/, '');
    const [p, qs] = raw.split('?');
    const parts = (p || '').split('/');
    return { route: parts[0] || 'home', arg: decodeURIComponent(parts.slice(1).join('/') || ''), q: new URLSearchParams(qs || '') };
  }

  const ROUTES = {
    home: renderHome, classroom: renderClassroom, courses: renderCourses, library: renderLibrary,
    gradebook: renderGradebook, command: renderCommand, settings: renderSettings, welcome: renderWelcome,
    guide: renderGuide, ideas: renderIdeas,
  };

  async function route() {
    let { route: r, arg, q } = parseHash();
    if (APP.state && !APP.state.profile.onboarded && r !== 'welcome') { history.replaceState(null, '', '#/welcome'); r = 'welcome'; }
    const fn = ROUTES[r] || renderHome;
    const tok = ++APP.tok;
    $$('.nav a').forEach(a => a.classList.toggle('active', a.dataset.route === (ROUTES[r] ? r : 'home')));
    view.classList.toggle('flush', r === 'classroom');
    document.body.classList.toggle('setup', r === 'welcome');
    if (r !== 'classroom') view.scrollTop = 0;
    try {
      await fn(tok, arg, q);
    } catch (e) {
      console.error(e);
      if (tok === APP.tok) view.innerHTML = emptyBox('⚠️', 'Something went wrong', h(e.message),
        '<button class="btn" onclick="location.reload()">Reload</button>');
    }
  }
  const stale = tok => tok !== APP.tok;
  window.addEventListener('hashchange', route);

  // ------------------------------------------------------------------ HOME / office
  const firstName = () => ((APP.state && APP.state.profile && APP.state.profile.name) || '').trim().split(/\s+/)[0];
  function greeting() {
    const hr = new Date().getHours();
    const n = firstName() ? ', ' + h(firstName()) : '';
    return (hr < 5 ? 'Up late' : hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening') + n;
  }

  function weeklyChart(rows) {
    if (!rows.length) return '<p class="muted small">No study sessions yet. Study modes time themselves.</p>';
    const max = Math.max(30, ...rows.map(r => Math.max(r.this, r.last)));
    const W = 300, L = 74, R = 48, rowH = 34;
    const bw = v => Math.max(2, (W - L - R) * v / max);
    let s = `<svg viewBox="0 0 ${W} ${rows.length * rowH + 2}" role="img" aria-label="Study minutes per class, this week and last week">`;
    rows.forEach((r, i) => {
      const y = i * rowH + 2;
      s += `<text x="0" y="${y + 16}">${h(r.class)}</text>`;
      s += `<rect x="${L}" y="${y + 2}" width="${bw(r.this)}" height="13" rx="3" style="fill:var(--gold)"><title>This week: ${fmtMin(r.this)}</title></rect>`;
      s += `<text class="val" x="${L + bw(r.this) + 6}" y="${y + 13}">${r.this ? fmtMin(r.this) : '0'}</text>`;
      s += `<rect x="${L}" y="${y + 19}" width="${bw(r.last)}" height="8" rx="3" style="fill:var(--surface-3)"><title>Last week: ${fmtMin(r.last)}</title></rect>`;
      if (r.last) s += `<text x="${L + bw(r.last) + 6}" y="${y + 27}" style="font-size:10.5px">${fmtMin(r.last)}</text>`;
    });
    return s + '</svg>';
  }

  function deadlineRow(d) {
    const dt = dateOf(d.date);
    const heat = d.days <= 1 ? ' hot' : d.days <= 3 ? ' warm' : '';
    const exam = d.kind === 'exam' || /\b(quiz|midterm|final|exam|test)\b/i.test(d.title);
    return `<div class="deadline"><div class="dday${heat}"><b>${dt.getDate()}</b><span>${MON[dt.getMonth()]}</span></div>
      <div><div class="dl-title">${h(d.title)}</div>
      <div class="small muted">${h(d.when)}${d.time ? ' · ' + h(d.time) : ''} ${d.class ? `<span class="chip${exam ? ' exam' : ''}">${h(d.class)}</span>` : ''}</div></div></div>`;
  }

  function courseCard(c) {
    const next = c.next ? `${h(c.next.title)} <span class="faint">(${h(c.next.when)})</span>` : '<span class="faint">nothing coming up</span>';
    const last = c.last_studied_days == null ? 'not yet' : c.last_studied_days === 0 ? 'today' :
      c.last_studied_days === 1 ? 'yesterday' : `${c.last_studied_days} days ago`;
    const total = STATUS.reduce((a, s) => a + (c.counts[s] || 0), 0);
    return `<div class="card course-card">
      <div><div class="code">${h(c.code)}</div><div class="title">${h(c.title)}</div></div>
      <dl class="kv"><dt>Professor</dt><dd>${h(c.professor || '?')}</dd>
        ${c.meets && c.meets !== '?' ? `<dt>Meets</dt><dd>${h(c.meets.split('(')[0].trim())}</dd>` : ''}
        <dt>Next up</dt><dd>${next}</dd><dt>Last studied</dt><dd>${last}</dd></dl>
      ${total ? mbar(c.counts) + mcounts(c.counts) : '<div class="small faint">Mastery fills in as you study.</div>'}
      <div class="row"><a class="btn sm" href="#/courses/${encodeURIComponent(c.id)}">Course record</a>
        <a class="btn sm ghost" href="#/library?course=${encodeURIComponent(c.id)}">Files</a></div>
      <a class="btn primary big" href="#/classroom?course=${encodeURIComponent(c.id)}">Study ${h(c.code)}</a>
    </div>`;
  }

  async function renderHome(tok) {
    view.innerHTML = '<div class="loading">Opening the office…</div>';
    const [d, cv] = await Promise.all([api('/api/dashboard'), api('/api/canvas/status').catch(() => ({}))]);
    if (stale(tok)) return;
    const b = d.bounty || {};
    const today = dateOf(d.today);
    const plan = d.plan.length ? d.plan.map((p, i) => `<div class="plan-item"><div class="plan-num">${i + 1}</div>
        <div><b>${h(p.title)}</b><div class="why">${h(p.why)}</div></div>
        <a class="btn sm primary" href="#/classroom?course=${encodeURIComponent(p.course)}&mode=${encodeURIComponent(p.mode)}" title="Open the Classroom in ${h(p.mode)} mode">${h(p.mode)}</a></div>`).join('')
      : '<p class="muted">Nothing urgent. Pick any class below, or open Office Hours.</p>';
    // a quiet "last synced" line (no pop-ups): turns gold after a week so it's easy to notice, never nags
    const syncDays = cv.synced ? Math.floor((Date.now() - new Date(cv.synced)) / 86400000) : null;
    const syncAgo = syncDays === null ? 'not yet' : syncDays < 1 ? 'today' : syncDays === 1 ? 'yesterday' : `${syncDays} days ago`;
    const syncLine = cv.connected ? `<span class="${syncDays >= 7 ? 'sync-old' : ''}" title="${cv.synced ? h(fmtStamp(cv.synced)) : ''}">Last Canvas sync: ${syncAgo}${syncDays >= 7 ? ' · worth a re-sync' : ''}</span>` : 'Canvas not connected';
    view.innerHTML = `
      <div class="hero"><div><div class="eyebrow">Dr. Claude's office</div><h1>${greeting()}</h1>
        <div class="date">${today.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</div></div>
        <div class="bounty"><div class="label">Studied today</div><div class="amount">${fmtMin(b.todayMin || 0)}</div>
        <div class="meta">${fmtMin(b.weekMin || 0)} this week · ${b.streakDays || 0}-day streak${b.running ? ' · ⏱ timer running' : ''}</div></div></div>
      <div class="grid g-home">
        <div class="card"><h2>⏰ Coming up <span class="count">from Canvas</span></h2>
          ${d.deadlines.length ? d.deadlines.map(deadlineRow).join('') : '<p class="muted">Nothing due. Nice.</p>'}</div>
        <div class="card chart"><h2>📊 Study minutes <span class="count">week of ${fmtDay(d.week_start)}</span></h2>
          ${weeklyChart(d.weekly)}
          <div class="legend"><span><i style="background:var(--gold)"></i>This week</span><span><i style="background:var(--surface-3)"></i>Last week</span></div></div>
        <div class="card plan"><h2>🧭 Today's plan</h2>${plan}</div>
      </div>
      <div class="row" style="margin:26px 0 12px;justify-content:space-between"><h2 style="font-size:19px;margin:0">Your classes</h2>
        <div class="row"><span class="small faint" id="syncLine">${syncLine}</span>
        ${cv.has_token ? '<button class="btn sm" id="resync" title="Download anything new from Canvas">⟳ Re-sync Canvas</button>'
          : cv.connected ? `<a class="btn sm" href="${h(cv.url || 'https://canvas.cpp.edu')}" target="_blank" rel="noopener" title="Open Canvas, then click 🎓 Sync Dr. Claude on your bookmarks bar">⟳ Re-sync (opens Canvas)</a>`
          : '<a class="btn sm" href="#/settings">Connect Canvas</a>'}</div></div>
      <div id="syncBox"></div>
      <div id="booksBox"></div>
      ${d.courses.length ? `<div class="grid g-courses">${d.courses.map(courseCard).join('')}</div>`
        : emptyBox('📚', 'No classes yet', cv.connected ? 'Re-sync Canvas to pull in your classes.' : 'Connect Canvas in Settings, or add a class by hand in Courses and upload your own files.',
          '<div class="row" style="justify-content:center"><a class="btn primary" href="#/settings">Connect Canvas</a><a class="btn" href="#/courses?add=1">Add a class by hand</a></div>')}`;
    // v1.4.5: textbook finder removed from the public build
    const rs = $('#resync');
    if (rs) rs.addEventListener('click', async () => {
      try { await api('/api/canvas/sync', {}); watchSync($('#syncBox'), tok, () => { refreshState().then(() => { if (!stale(tok)) route(); }); }); }
      catch (e) { toast(e.message, 4000); }
    });
    if (cv.running) watchSync($('#syncBox'), tok, () => { refreshState().then(() => { if (!stale(tok)) route(); }); });
  }

  async function refreshState() { try { APP.state = await api('/api/state'); } catch (e) { /* keep old */ } }

  // Canvas sync progress box (Home, Settings, setup). Polls until the sync stops, then calls done().
  function watchSync(box, tok, done) {
    if (!box) return;
    const draw = st => {
      const pct = st.total ? Math.round(100 * st.done / st.total) : 0;
      box.innerHTML = `<div class="card sync-card"><div class="row" style="justify-content:space-between"><b>${st.running ? '⟳ ' : ''}${h(st.phase || 'Canvas')}</b>
          <span class="small muted">${st.files_new || 0} new file${st.files_new === 1 ? '' : 's'} · ${st.files_same || 0} already here</span></div>
        ${st.running ? `<div class="progress"><span style="width:${st.total ? pct : 8}%"></span></div>` : ''}
        ${st.course ? `<div class="small muted">${h(st.course)}</div>` : ''}
        <div class="sync-log small faint">${(st.log || []).slice(-5).map(x => `<div>${h(x)}</div>`).join('')}</div>
        ${(st.errors || []).length ? `<details class="small"><summary>${st.errors.length} thing${st.errors.length === 1 ? '' : 's'} couldn't be downloaded</summary>${st.errors.map(x => `<div>${h(x)}</div>`).join('')}</details>` : ''}</div>`;
    };
    const tick = async () => {
      if (stale(tok) && tok !== -1) return;
      let st;
      try { st = await api('/api/canvas/status'); } catch (e) { return; }
      draw(st);
      if (st.running) setTimeout(tick, 1200);
      else if (done) done(st);
    };
    tick();
  }

  // ------------------------------------------------------------------ CLASSROOM
  const CHAT = { sid: null, meta: null, messages: [], course: '', mode: 'Office Hours', sessions: [], running: false, poll: 0 };
  let LIVE = null;           // the one turn this window is streaming: {sid, text, tools, status, timer, error, ctrl}
  let REC = null;            // speech recognition
  let recOn = false;
  let DICT = null;           // live dictation state (see startMic)

  function courseOptions(sel) {
    const opt = c => `<option value="${h(c.id)}"${c.id === sel ? ' selected' : ''}>${h(c.code)} ${h(c.title)}</option>`;
    return `<option value="">Pick a class…</option>${courses().map(opt).join('')}`;
  }

  async function loadSessions() {
    try { const r = await api('/api/sessions'); CHAT.sessions = r.sessions || []; } catch (e) { CHAT.sessions = []; }
  }

  function historyHtml() {
    if (!CHAT.sessions.length) return '<p class="small faint" style="padding:6px 10px">No saved sessions yet. Your chats show up here so you can pick up where you left off.</p>';
    const now = new Date(); const day0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const group = s => {
      const d = dateOf(s.updated || s.created);
      const diff = Math.floor((day0 - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 864e5);
      return diff <= 0 ? 'Today' : diff === 1 ? 'Yesterday' : diff < 7 ? 'This week' : 'Earlier';
    };
    let out = '', last = '';
    for (const s of CHAT.sessions) {
      const g = group(s);
      if (g !== last) { out += `<div class="hist-group">${g}</div>`; last = g; }
      out += `<button class="hist-item${s.id === CHAT.sid ? ' active' : ''}" data-sid="${h(s.id)}" title="Double-click to rename">
        <span class="hist-del" data-del-sid="${h(s.id)}" title="Delete this chat (and the files attached to it)">🗑</span>
        <div class="t">${h(s.title)}</div><div class="m">${h(s.mode)} · ${s.turns || 0} turn${s.turns === 1 ? '' : 's'} · ${fmtTime(s.updated || s.created)}</div></button>`;
    }
    return out;
  }

  // chat attachments: pictures show as thumbnails, other files as chips (both open on click)
  function filesHtml(files, removable) {
    if (!files || !files.length) return '';
    return `<div class="att-list">${files.map((f, i) => `<div class="att${f.image ? ' pic' : ''}${f.uploading ? ' busy' : ''}" title="${h(f.name)}">
      ${f.image && f.url ? `<img src="${h(f.url)}" alt="${h(f.name)}" class="chat-img">` : `<span class="att-ic">📄</span><span class="att-nm">${h(f.name)}</span>`}
      ${removable ? `<button class="att-x" data-unattach="${i}" title="Remove">✕</button>` : ''}</div>`).join('')}</div>`;
  }

  function msgHtml(m) {
    if (m.role === 'user') return `<div class="msg user">${filesHtml(m.files)}${m.text ? `<div class="bubble">${h(m.text)}</div>` : ''}</div>`;
    if (m.role === 'note') return `<div class="msg note"><div class="bubble md">${MD.inline(m.text)}</div></div>`;
    if (m.role === 'error') return `<div class="msg error"><div class="who">Problem</div><div class="bubble md">${md(m.text)}</div></div>`;
    const tools = (m.tools || []).length ? `<div class="tools">${m.tools.map(t => `<div class="tool">${h(t.icon)} ${h(t.text)}</div>`).join('')}</div>` : '';
    return `<div class="msg assistant"><div class="who">Dr. Claude</div>${tools}
      ${m.text ? `<div class="bubble md">${md(m.text)}</div>` : ''}${m.timer ? `<div class="timer-note">⏱ ${h(m.timer)}</div>` : ''}</div>`;
  }

  function emptyChatHtml() {
    const c = courseById(CHAT.course);
    return `<div class="empty-chat"><div class="big-cap">🎓</div>
      <h2>${c ? `${h(c.code)}: what are we doing?` : 'Pick a class, then a mode'}</h2>
      <p>${c ? 'Choose a mode below to start, or just type your first message.' : 'Choose the class at the top left. Then pick a mode or type a message.'}
      Study modes start the study timer by themselves.</p>
      <div class="mode-help">${APP.state.modes.map(m => `<button data-start="${h(m)}"><b>${h(m)}</b><span>${h(MODE_INFO[m] || '')}</span></button>`).join('')}</div></div>`;
  }

  function liveHtml() {
    const L = LIVE;
    const tools = L.tools.length ? `<div class="tools">${L.tools.map(t => `<div class="tool">${h(t.icon)} ${h(t.text)}</div>`).join('')}</div>` : '';
    const text = stripMarkers(L.text);
    return `<div class="who">Dr. Claude</div>${tools}${text ? `<div class="bubble md">${md(text)}</div>` : ''}
      <div class="thinking"><span class="dots"><i></i><i></i><i></i></span><span>${h(L.status || 'Thinking…')}</span></div>`;
  }

  const liveHere = () => LIVE && LIVE.sid === CHAT.sid;
  const busy = () => liveHere() || CHAT.running;

  function nearBottom(el) { return el.scrollHeight - el.scrollTop - el.clientHeight < 120; }
  function toBottom(force) {
    const box = $('#messages');
    if (box && (force || nearBottom(box))) box.scrollTop = box.scrollHeight;
  }

  function drawMessages(force = true) {
    const box = $('#messages');
    if (!box) return;
    const wasNear = nearBottom(box);
    if (!CHAT.sid && !CHAT.messages.length && !liveHere()) {
      box.innerHTML = emptyChatHtml();
      return;
    }
    let html = CHAT.messages.map(msgHtml).join('');
    if (liveHere()) html += `<div class="msg assistant" id="liveMsg">${liveHtml()}</div>`;
    else if (CHAT.running) html += `<div class="msg assistant"><div class="thinking"><span class="dots"><i></i><i></i><i></i></span><span>Still answering in the background… (this updates by itself)</span></div></div>`;
    box.innerHTML = html;
    if (force || wasNear) box.scrollTop = box.scrollHeight;
    drawQbar(); MD.hydrate($('#messages'));
  }

  // Sticky "current question" bar: the newest "## ▶ NOW: ..." heading the professor wrote.
  function currentQuestion() {
    const texts = CHAT.messages.filter(m => m.role === 'assistant').map(m => m.text || '');
    if (liveHere()) texts.push(LIVE.text || '');
    for (let k = texts.length - 1; k >= 0; k--) {
      const hits = [...texts[k].matchAll(/^\s{0,3}#{1,6}\s*▶\s*(.+?)\s*#*\s*$/gm)];
      if (hits.length) return hits[hits.length - 1][1];
    }
    return '';
  }
  // hooks for tools.js (side drawer)
  window.DRC = {
    api, toast, md,
    course: () => CHAT.course || (APP.state && APP.state.courses[0] ? APP.state.courses[0].id : ''),
    courses: () => (APP.state ? APP.state.courses : []),
    current: () => currentQuestion(),
    // put words in the message box (cursor at the end) so the student only finishes the sentence
    ask: text => { const t = $('#input'); if (!t) return; t.value = text; t.focus(); t.setSelectionRange(text.length, text.length); t.dispatchEvent(new Event('input')); },
  };

  function drawQbar() {
    const bar = $('#qbar');
    if (!bar) return;
    const q = currentQuestion();
    bar.style.display = q ? '' : 'none';
    if (q) $('#qbarText').innerHTML = MD.inline('▶ ' + q);
  }

  let liveRaf = 0;
  function drawLive() {
    if (liveRaf) return;
    liveRaf = requestAnimationFrame(() => {
      liveRaf = 0;
      const el = $('#liveMsg');
      if (!el || !liveHere()) return;
      const box = $('#messages');
      const near = nearBottom(box);
      el.innerHTML = liveHtml();
      if (near) box.scrollTop = box.scrollHeight;
      drawQbar(); MD.hydrate($('#messages'));
    });
  }

  function drawTop() {
    const top = $('#chatTop');
    if (!top) return;
    const started = !!CHAT.sid;
    const mode = started && CHAT.meta ? CHAT.meta.mode : CHAT.mode;
    const timerOn = started && APP.timerActive && APP.timerActive[CHAT.sid];
    $('#courseSel', top).innerHTML = courseOptions(started && CHAT.meta ? CHAT.meta.course : CHAT.course);
    $('#courseSel', top).disabled = started;
    $('#sessTitle', top).textContent = started && CHAT.meta ? CHAT.meta.title : 'New session';
    $('#timerPill', top).style.display = timerOn || (liveHere() && LIVE.timer) ? '' : 'none';
    $('#endStudy', top).style.display = started && STUDY_MODES.has(mode) && APP.state.settings.logpose ? '' : 'none';
    $('#retroBtn', top).style.display = started && CHAT.messages.length > 2 ? '' : 'none';
    $('#modes', top).innerHTML = APP.state.modes.map(m =>
      `<button class="mode${m === mode ? ' on' : ''}" data-mode="${h(m)}"${started ? ' disabled' : ''} title="${h(MODE_INFO[m] || '')}">${h(m)}</button>`).join('');
  }

  function drawComposer() {
    const btn = $('#sendBtn');
    if (!btn) return;
    const b = busy();
    btn.className = 'icon-btn ' + (b ? 'stop' : 'send');
    btn.textContent = b ? '■' : '➤';
    btn.title = b ? 'Stop Dr. Claude' : 'Send (Enter)';
    const ta = $('#input');
    ta.placeholder = CHAT.sid ? 'Answer or ask anything… (Enter to send, Shift+Enter for a new line)'
      : 'Type your first message, or pick a mode above to start…';
  }

  function drawHistory() {
    const el = $('#historyList');
    if (el) el.innerHTML = historyHtml();
  }

  function drawChat() { drawTop(); drawMessages(); drawComposer(); drawHistory(); }

  async function openSession(sid) {
    clearTimeout(CHAT.poll);
    const r = await api('/api/chat/history?sid=' + encodeURIComponent(sid));
    if (!r.session) { toast("That session wasn't found."); return newChat(); }
    CHAT.sid = sid; CHAT.meta = r.session; CHAT.messages = r.messages || [];
    CHAT.course = r.session.course; CHAT.mode = r.session.mode;
    CHAT.running = !!r.running && !(LIVE && LIVE.sid === sid);
    if (CHAT.running) CHAT.poll = setTimeout(() => { if (CHAT.sid === sid && parseHash().route === 'classroom') openSession(sid); }, 4000);
    else if (CHAT.wasRunning === sid) loadSessions().then(drawHistory);
    CHAT.wasRunning = CHAT.running ? sid : null;
    drawChat();
  }

  function newChat(course, mode) {
    clearTimeout(CHAT.poll);
    CHAT.sid = null; CHAT.meta = null; CHAT.messages = []; CHAT.running = false;
    if (course !== undefined) CHAT.course = course;
    if (mode && APP.state.modes.includes(mode)) CHAT.mode = mode;
    if (location.hash.startsWith('#/classroom/')) history.replaceState(null, '', '#/classroom');
    drawChat();
  }

  async function renderClassroom(tok, arg, q) {
    view.innerHTML = `<div class="classroom" id="classroom">
      <aside class="history"><div class="history-head"><h2>Sessions</h2><button class="btn sm" id="newBtn" title="Start a new session">＋ New</button></div>
        <div class="history-list" id="historyList"></div></aside>
      <section class="chat">
        <div class="chat-top" id="chatTop">
          <div class="row1">
            <button class="btn sm ghost only-narrow" id="histToggle" title="Show saved sessions">☰</button>
            <select class="course-select" id="courseSel" aria-label="Class"></select>
            <span class="session-title" id="sessTitle"></span>
            <span class="pill" id="timerPill" title="The study timer is running for this session"><span class="dot"></span>Timer on</span>
            <span class="spacer"></span>
            <button class="btn sm" data-tools-toggle title="Calculator, quick questions, and your thoughts">🧰 Tools</button>
            <button class="btn sm" id="retroBtn" title="Command reads this session and suggests up to 3 changes to how Dr. Claude teaches you">🔁 Retro</button>
            <button class="btn sm" id="endStudy" title="Save the study time and stop the timer">⏹ End study session</button>
          </div>
          <div class="modes" id="modes"></div>
        </div>
        <div class="qbar" id="qbar" style="display:none" title="The question you're working on right now">
          <span class="qbar-label">Working on</span><span class="qbar-text" id="qbarText"></span>
          <button class="btn sm ghost" id="qbarJump" title="Scroll to this question">Show ↓</button></div>
        <div class="messages" id="messages"></div>
        <div class="composer"><div id="attachTray"></div><div class="composer-box">
          <button class="icon-btn" id="attachBtn" title="Attach pictures or files to this chat only (they don't go in the Library)">📎</button>
          <input type="file" id="attachIn" multiple hidden accept="image/*,.pdf,.docx,.pptx,.txt,.md,.csv,.html,.py,.c,.cpp,.h,.java,.m,.tex,.json">
          <textarea id="input" rows="1" aria-label="Message"></textarea>
          <button class="icon-btn" id="micBtn" title="Talk instead of typing (Ctrl+M)">🎤</button>
          <button class="icon-btn send" id="sendBtn" title="Send (Enter)">➤</button>
        </div>
        <div class="hint"><span>Enter = send · Shift+Enter = new line · hold Space = talk · Ctrl+M = mic · 📎 or paste/drop a picture to attach</span><span class="interim" id="interim"></span></div></div>
      </section></div>`;
    wireClassroom();
    if (stale(tok)) return;
    try { const st = await api('/api/logpose/status'); APP.timerActive = st.active || {}; } catch (e) { APP.timerActive = {}; }
    await loadSessions();
    if (stale(tok)) return;
    if (arg) {
      if (arg !== CHAT.sid || !CHAT.meta) await openSession(arg);
      else drawChat();
    } else if (q.get('course') || q.get('mode')) {
      newChat(q.get('course') || CHAT.course, q.get('mode') || CHAT.mode);
      history.replaceState(null, '', '#/classroom');
    } else if (CHAT.sid) {
      history.replaceState(null, '', '#/classroom/' + CHAT.sid);
      await openSession(CHAT.sid);
    } else drawChat();
    if (!stale(tok)) $('#input').focus();
  }

  function autosize() {
    const ta = $('#input');
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 220) + 'px';
  }

  // ---- chat attachments (live only in the chat they're sent in; never added to the Library)
  const ATT = { draft: '', files: [] };
  const newDraft = () => Array.from(crypto.getRandomValues(new Uint8Array(16)), b => b.toString(16).padStart(2, '0')).join('');
  function drawAttach() {
    const t = $('#attachTray');
    if (t) t.innerHTML = ATT.files.length ? filesHtml(ATT.files, true) : '';
  }
  async function attachFiles(list) {
    list = Array.from(list || []).filter(f => f && f.size);
    if (!list.length) return;
    if (!ATT.draft) ATT.draft = newDraft();
    for (const f of list) {
      const name = f.name && f.name !== 'image.png' ? f.name : `pasted-${Date.now()}.png`;
      const item = { name, image: /^image\//.test(f.type), url: '', uploading: true };
      ATT.files.push(item); drawAttach();
      try {
        const r = await fetch(`/api/chat/attach?draft=${ATT.draft}&name=${encodeURIComponent(name)}`,
          { method: 'POST', headers: { 'X-Dr-Claude': '1', 'Content-Type': 'application/octet-stream' }, body: f });
        const j = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(j.error || r.statusText);
        Object.assign(item, { name: j.name, url: j.url, image: j.image, uploading: false });
      } catch (e) {
        ATT.files.splice(ATT.files.indexOf(item), 1);
        toast(`Couldn't attach ${name}: ${e.message}`, 5000);
      }
      drawAttach();
    }
  }
  function clearAttach() { ATT.draft = ''; ATT.files = []; drawAttach(); }

  // click a picture in the chat = see it big (click again or Esc to close)
  document.addEventListener('click', e => {
    const img = e.target.closest('.chat-img');
    const box = $('#lightbox');
    if (box && (e.target === box || e.target.closest('#lightbox'))) { box.remove(); return; }
    if (!img) return;
    const lb = document.createElement('div');
    lb.id = 'lightbox'; lb.className = 'lightbox'; lb.title = 'Click to close';
    lb.innerHTML = `<img src="${h(img.getAttribute('src'))}" alt="${h(img.alt)}">`;
    document.body.appendChild(lb);
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && $('#lightbox')) $('#lightbox').remove(); });

  function wireClassroom() {
    const root = $('#classroom');
    const ta = $('#input');
    ta.addEventListener('input', autosize);
    drawAttach();
    $('#attachBtn').addEventListener('click', () => $('#attachIn').click());
    $('#attachIn').addEventListener('change', e => { attachFiles(e.target.files); e.target.value = ''; });
    ta.addEventListener('paste', e => {
      const fs = Array.from(e.clipboardData && e.clipboardData.files || []);
      if (fs.length) { e.preventDefault(); attachFiles(fs); }
    });
    const chatEl = $('.chat', root);
    chatEl.addEventListener('dragover', e => { if (e.dataTransfer.types.includes('Files')) { e.preventDefault(); chatEl.classList.add('drop-over'); } });
    chatEl.addEventListener('dragleave', e => { if (!chatEl.contains(e.relatedTarget)) chatEl.classList.remove('drop-over'); });
    chatEl.addEventListener('drop', e => {
      if (!e.dataTransfer.files.length) return;
      e.preventDefault(); chatEl.classList.remove('drop-over');
      attachFiles(e.dataTransfer.files);
    });
    $('#attachTray').addEventListener('click', async e => {
      const x = e.target.closest('[data-unattach]');
      if (!x) return;
      e.stopPropagation();
      const f = ATT.files.splice(+x.dataset.unattach, 1)[0];
      drawAttach();
      if (f && !f.uploading) api('/api/chat/attach/remove', { draft: ATT.draft, name: f.name }).catch(() => {});
    });
    ta.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); if (!busy()) submit(); }
    });
    $('#sendBtn').addEventListener('click', () => busy() ? stopTurn() : submit());
    $('#micBtn').addEventListener('click', toggleMic);
    $('#qbarJump').addEventListener('click', () => {
      const hs = $('#messages').querySelectorAll('.qhead');
      if (hs.length) hs[hs.length - 1].scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    $('#newBtn').addEventListener('click', () => { root.classList.remove('show-history'); newChat(CHAT.course); ta.focus(); });
    $('#histToggle').addEventListener('click', () => root.classList.toggle('show-history'));
    $('#courseSel').addEventListener('change', e => { CHAT.course = e.target.value; drawMessages(); });
    $('#endStudy').addEventListener('click', async () => {
      try {
        const r = await api('/api/logpose', { action: 'end', sid: CHAT.sid || '' });
        APP.timerActive = {};
        drawTop();
        toast(r.text || 'Study session ended.', 5000);
      } catch (e) { toast(e.message, 4000); }
    });
    $('#retroBtn').addEventListener('click', () => { if (CHAT.sid) location.hash = '#/command?retro=' + encodeURIComponent(CHAT.sid); });
    $('#modes').addEventListener('click', e => {
      const b = e.target.closest('[data-mode]');
      if (b && !b.disabled) { CHAT.mode = b.dataset.mode; drawTop(); ta.focus(); }
    });
    $('#messages').addEventListener('click', e => {
      const b = e.target.closest('[data-start]');
      if (!b) return;
      CHAT.mode = b.dataset.start;
      drawTop();
      submit();
    });
    const hl = $('#historyList');
    hl.addEventListener('click', async e => {
      const d = e.target.closest('[data-del-sid]');
      if (d) {
        e.stopPropagation();
        const s = CHAT.sessions.find(x => x.id === d.dataset.delSid);
        if (!s || !confirm(`Delete "${s.title}"?\n\nThe chat and any files or pictures attached to it are deleted for good.`)) return;
        try {
          await api('/api/chat/delete', { sid: s.id });
          CHAT.sessions = CHAT.sessions.filter(x => x.id !== s.id);
          if (CHAT.sid === s.id) newChat(CHAT.course); else drawHistory();
          toast('Chat deleted.');
        } catch (err) { toast(err.message, 4000); }
        return;
      }
      const b = e.target.closest('[data-sid]');
      if (!b) return;
      root.classList.remove('show-history');
      if (b.dataset.sid !== CHAT.sid) location.hash = '#/classroom/' + b.dataset.sid;
    });
    hl.addEventListener('dblclick', async e => {
      const b = e.target.closest('[data-sid]');
      if (!b) return;
      const s = CHAT.sessions.find(x => x.id === b.dataset.sid);
      const title = s && prompt('Rename this session:', s.title);
      if (!title || !title.trim()) return;
      await api('/api/chat/rename', { sid: s.id, title: title.trim() });
      s.title = title.trim();
      if (CHAT.meta && CHAT.meta.id === s.id) CHAT.meta.title = s.title;
      drawHistory(); drawTop();
    });
  }

  function submit() {
    const ta = $('#input');
    const text = ta.value.trim();
    if (ATT.files.some(f => f.uploading)) { toast('Still attaching… one second.'); return; }
    if (CHAT.sid && !text && !ATT.files.length) return;
    if (!CHAT.sid && !CHAT.course) { toast('Pick a class first (top left).'); $('#courseSel').focus(); return; }
    if (LIVE) { toast('Dr. Claude is still answering another session. Wait or press Stop there.'); return; }
    if (recOn) stopMic();
    const vp = text ? voiceRead(CHAT.course) : (voiceTake(), null);
    ta.value = ''; autosize();
    const files = ATT.files.slice(), draft = ATT.draft;
    clearAttach();
    sendTurn(text, files, draft, vp);
  }

  async function sendTurn(text, files = [], draft = '', voiceP = null) {
    const startSid = CHAT.sid;
    const body = startSid ? { sid: startSid, text } : { course: CHAT.course, mode: CHAT.mode, text };
    if (files.length) Object.assign(body, { draft, files: files.map(f => f.name) });
    const c = courseById(CHAT.course);
    CHAT.messages.push(text || files.length ? { role: 'user', text, files } : { role: 'note', text: `Started **${CHAT.mode}** for **${c ? c.code : CHAT.course}**` });
    const L = LIVE = { sid: startSid, text: '', tools: [], status: 'Waking Dr. Claude…', timer: '', error: '', ctrl: new AbortController() };
    drawMessages(true); drawComposer();
    let doneEv = null, gotSession = false;
    const handle = ev => {
      switch (ev.t) {
        case 'session':
          L.sid = ev.session.id; gotSession = true;
          if (CHAT.sid === startSid && !startSid && parseHash().route === 'classroom') {
            CHAT.sid = ev.session.id; CHAT.meta = ev.session;
            history.replaceState(null, '', '#/classroom/' + CHAT.sid);
            loadSessions().then(drawHistory);
            drawTop();
          }
          break;
        case 'timer':
          L.timer = ev.text;
          APP.timerActive = Object.assign({}, APP.timerActive, { [L.sid]: true });
          toast('⏱ ' + ev.text);
          drawTop();
          break;
        case 'status': L.status = ev.text; break;
        case 'tool': L.tools.push({ icon: ev.icon, text: ev.text }); L.status = ev.text + '…'; break;
        case 'text': L.text += ev.delta || ''; L.status = 'Writing…'; break;
        case 'error': L.error = ev.text; break;
        case 'done': doneEv = ev; break;
      }
      drawLive();
    };
    try {
      if (voiceP) {                       // spoken answer: wait (max ~9 s) for the confidence hint, then send
        L.status = 'Hearing how you said it…'; drawLive();
        const note = await voiceP;
        if (note) body.voice_note = note;
      }
      const res = await fetch('/api/chat/send', {
        method: 'POST', signal: L.ctrl.signal,
        headers: { 'Content-Type': 'application/json', 'X-Dr-Claude': '1' }, body: JSON.stringify(body),
      });
      if (!res.ok || !res.body) {
        let j = {}; try { j = await res.json(); } catch (e) { /* ignore */ }
        throw new Error(j.error || `${res.status} ${res.statusText}`);
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      for (;;) {
        const { value, done } = await reader.read();
        if (value) buf += dec.decode(value, { stream: true });
        let k;
        while ((k = buf.indexOf('\n\n')) >= 0) {
          const chunk = buf.slice(0, k); buf = buf.slice(k + 2);
          for (const line of chunk.split('\n')) {
            if (line.startsWith('data:')) { try { handle(JSON.parse(line.slice(5))); } catch (e) { console.warn('bad event', line); } }
          }
        }
        if (done) break;
      }
    } catch (e) {
      if (e.name !== 'AbortError') L.error = L.error || e.message;
    }
    // finish: the server's saved chat is the source of truth
    LIVE = null;
    VOICE.qShown = Date.now();            // the reply is on screen: the next answer's start delay counts from here
    if (doneEv && doneEv.timer) toast('⏱ ' + doneEv.timer);
    if (doneEv && /ended|saved/i.test(doneEv.timer || '')) delete APP.timerActive[L.sid];
    const here = L.sid && CHAT.sid === L.sid;
    if (here) {
      try {
        const r = await api('/api/chat/history?sid=' + encodeURIComponent(L.sid));
        CHAT.meta = r.session || CHAT.meta;
        CHAT.messages = r.messages || CHAT.messages;
      } catch (e) {
        if (L.text) CHAT.messages.push({ role: 'assistant', text: stripMarkers(L.text), tools: L.tools, timer: doneEv && doneEv.timer });
      }
    } else if (!L.sid && !CHAT.sid) {
      // never got a session (server refused): keep the user's text so it isn't lost
      CHAT.messages = [];
    }
    const ta = $('#input');
    if (!gotSession && text && ta && !ta.value) ta.value = text;  // server refused: give the text back
    if (!gotSession && files.length && !ATT.files.length) { ATT.draft = draft; ATT.files = files; drawAttach(); }  // ...and the attachments
    if (L.error && (here || (!L.sid && !CHAT.sid))) CHAT.messages.push({ role: 'error', text: L.error });
    if (!here && L.sid && !L.error) toast('Dr. Claude finished answering in another session.');
    await loadSessions();
    if (parseHash().route === 'classroom') drawChat();
  }

  async function stopTurn() {
    if (CHAT.running && !liveHere()) {
      await api('/api/chat/stop', { sid: CHAT.sid }).catch(() => {});
      toast('Stopping…');
      return;
    }
    if (!LIVE) return;
    if (LIVE.sid) {
      try { await api('/api/chat/stop', { sid: LIVE.sid }); } catch (e) { LIVE.ctrl.abort(); }
    } else LIVE.ctrl.abort();
    toast('Stopped.');
  }

  // Join two speech pieces without doubling: if the new piece repeats words the text already ends with
  // (or is the whole text again plus more), only the new words are added.
  function mergeSpeech(acc, piece) {
    const p = piece.trim(); if (!p) return acc;
    if (!acc) return p;
    const norm = w => w.toLowerCase().replace(/[^\w']/g, '');
    const A = acc.split(/\s+/), P = p.split(/\s+/);
    if ((A.length >= 2 || norm(A[0]).length > 3) && P.length >= A.length && A.every((w, i) => norm(w) === norm(P[i]))) return p;   // whole thing again
    for (let n = Math.min(A.length, P.length); n >= 1; n--) {                          // longest overlap
      let ok = true;
      for (let i = 0; i < n; i++) if (norm(A[A.length - n + i]) !== norm(P[i])) { ok = false; break; }
      if (ok && (n >= 2 || norm(P[0]).length > 3)) {                                   // 1-word overlap only for long words ("the the" can be real)
        const rest = P.slice(n).join(' ');
        return rest ? acc + ' ' + rest : acc;
      }
    }
    return acc + ' ' + p;
  }

  // ---- voice typing (Web Speech API)
  function toggleMic() { recOn ? stopMic() : startMic(); }
  function stopMic() {
    recOn = false;
    if (DICT) DICT.stopped = true;   // Edge sends one more "final" copy AFTER stop: keep DICT so it lands in place, not twice
    if (REC) try { REC.stop(); } catch (e) { /* already stopped */ }
    setTimeout(() => { if (!recOn) whisperStop(); }, 4000);
    const b = $('#micBtn'); if (b) b.classList.remove('listening');
    const i = $('#interim'); if (i) i.textContent = '';
  }

  // ---- Whisper fix-up (optional Voice upgrade in Settings). Edge types live; each time Edge finishes a phrase,
  // that stretch of audio goes to Whisper with the class's word list (fixes D vs Z, "flip-flop", etc.), and the better text
  // replaces Edge's guess about half a second later. If Whisper isn't installed, plain Edge typing still works.
  const WH = { ok: null, conf: false, ctx: null, stream: null, node: null, chunks: [], start: 0, total: 0, cut: 0, full: [], fullLen: 0 };
  // ---- Voice confidence reader (11/11): the whole spoken answer (every mic stretch since the last send) goes to
  // /api/voice/read when you press Send. The server compares HOW it was said (start delay, pauses, um/uh, hedges,
  // pitch at the end) to YOUR own normal and hands the tutor a hidden hint. Audio is never saved, only numbers.
  const VOICE = { parts: [], micStart: 0, qShown: Date.now() };
  function voiceKeep() {
    if (!WH.full.length) return;
    const all = new Float32Array(WH.fullLen); let o = 0;
    for (const c of WH.full) { all.set(c, o); o += c.length; }
    VOICE.parts.push(all); WH.full = []; WH.fullLen = 0;
  }
  function voiceTake() {
    voiceKeep();
    const n = VOICE.parts.reduce((a, b) => a + b.length, 0);
    const out = { pcm: null, preDelay: VOICE.micStart && VOICE.qShown ? Math.max(0, (VOICE.micStart - VOICE.qShown) / 1000) : null };
    if (n >= 16000 * 0.8) { out.pcm = new Float32Array(n); let o = 0; for (const p of VOICE.parts) { out.pcm.set(p, o); o += p.length; } }
    VOICE.parts = []; VOICE.micStart = 0;
    return out;
  }
  function voiceRead(course) {
    const v = voiceTake();
    if (!v.pcm || !WH.conf) return null;
    const pd = v.preDelay !== null && v.preDelay < 600 ? v.preDelay : null;
    return Promise.race([
      api('/api/voice/read', { wav: wavBase64(v.pcm), pre_delay: pd, course: course || '' }).then(r => (r && r.note) || '').catch(() => ''),
      new Promise(res => setTimeout(() => res(''), 9000)),       // never hold the message up for long
    ]);
  }
  async function whisperStart() {
    if (WH.ok === null) { try { const st = await api('/api/stt/status', {}); WH.ok = !!st.available; WH.conf = st.conf !== false; } catch (e) { WH.ok = false; } }
    if (!WH.ok || WH.ctx) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true } });
      if (!recOn || WH.ctx) { stream.getTracks().forEach(t => t.stop()); return; }
      WH.stream = stream;
      WH.ctx = new AudioContext({ sampleRate: 16000 });
      const src = WH.ctx.createMediaStreamSource(stream);
      WH.node = WH.ctx.createScriptProcessor(4096, 1, 1);
      WH.chunks = []; WH.start = 0; WH.total = 0; WH.cut = 0;
      WH.node.onaudioprocess = ev => {
        const d = new Float32Array(ev.inputBuffer.getChannelData(0));
        WH.chunks.push(d); WH.total += d.length;
        if (recOn && VOICE.micStart && WH.fullLen < 16000 * 120) { WH.full.push(d); WH.fullLen += d.length; }
        while (WH.chunks.length > 1 && WH.start + WH.chunks[0].length < WH.cut - 32000) { WH.start += WH.chunks[0].length; WH.chunks.shift(); }
      };
      src.connect(WH.node); WH.node.connect(WH.ctx.destination);
    } catch (e) { whisperStop(); }
  }
  function whisperStop() {
    if (VOICE.micStart) voiceKeep(); else { WH.full = []; WH.fullLen = 0; }
    try { if (WH.node) WH.node.disconnect(); } catch (e) { /* gone */ }
    try { if (WH.stream) WH.stream.getTracks().forEach(t => t.stop()); } catch (e) { /* gone */ }
    try { if (WH.ctx) WH.ctx.close(); } catch (e) { /* gone */ }
    WH.ctx = WH.stream = WH.node = null; WH.chunks = []; WH.start = WH.total = WH.cut = 0;
  }
  function whisperSlice(from, to) {
    const out = new Float32Array(Math.max(0, to - from));
    let pos = WH.start;
    for (const c of WH.chunks) {
      const s0 = Math.max(from, pos), s1 = Math.min(to, pos + c.length);
      if (s1 > s0) out.set(c.subarray(s0 - pos, s1 - pos), s0 - from);
      pos += c.length;
    }
    return out;
  }
  function wavBase64(f32) {
    const n = f32.length, buf = new ArrayBuffer(44 + n * 2), v = new DataView(buf);
    const w = (o, str) => { for (let i = 0; i < str.length; i++) v.setUint8(o + i, str.charCodeAt(i)); };
    w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true);
    v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, 16000, true); v.setUint32(28, 32000, true);
    v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 2, true);
    for (let i = 0; i < n; i++) v.setInt16(44 + i * 2, Math.max(-1, Math.min(1, f32[i])) * 32767, true);
    const bytes = new Uint8Array(buf); let bin = '';
    for (let i = 0; i < bytes.length; i += 32768) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 32768));
    return btoa(bin);
  }
  async function whisperPhrase(dict, k, edgeText) {
    if (!WH.ctx) return;
    const from = Math.max(WH.start, WH.cut - 6400), to = WH.total;   // 0.4 s back so the first word isn't clipped
    WH.cut = to;
    if (to - from < 4800) return;
    let w = '';
    try { w = ((await api('/api/stt', { wav: wavBase64(whisperSlice(from, to)), course: CHAT.course || '' })).text || '').trim(); }
    catch (e) { return; }
    const nw = s => s.trim().split(/\s+/).filter(Boolean).length;
    const ne = nw(edgeText);
    if (!w || (ne > 2 && (nw(w) < ne * 0.4 || nw(w) > ne * 2.5))) return;   // looks wrong: keep Edge's words
    const ta = $('#input'); if (!ta) return;
    if (DICT === dict && ta.value === dict.last) { dict.over[k] = w; renderDict(); return; }
    // the box moved on (new mic stretch / he typed): swap the phrase in place if it's still there
    const e = edgeText.trim(), at = e ? ta.value.lastIndexOf(e) : -1;
    if (at < 0) return;
    const nv = ta.value.slice(0, at) + w + ta.value.slice(at + e.length);
    const wasLast = DICT && ta.value === DICT.last;
    if (DICT && DICT.base.length >= at + e.length) DICT.base = DICT.base.slice(0, at) + w + DICT.base.slice(at + e.length);
    ta.value = nv; if (wasLast) DICT.last = nv;
    autosize();
  }
  function renderDict() {
    const ta = $('#input'), d = DICT; if (!ta || !d) return;
    // Edge often repeats the end of one phrase at the start of the next (or sends the whole thing again).
    // mergeSpeech keeps one copy, so words never double.
    let heard = '', fin = '';
    for (let k = d.from; k < d.pieces.length; k++) {
      heard = mergeSpeech(heard, d.over[k] || d.pieces[k]);
      if (k === d.nfinal - 1) fin = heard;
    }
    if (d.nfinal <= d.from) fin = '';
    d.first = Math.max(d.nfinal, d.from);
    d.guess = heard.slice(fin.length).trim() ? heard.slice(fin.length) : '';
    ta.value = (d.base + heard).replace(/  +/g, ' ');
    d.last = ta.value;
    ta.selectionStart = ta.selectionEnd = ta.value.length;
    ta.scrollTop = ta.scrollHeight;
    autosize();
  }

  function startMic() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { toast("Voice typing isn't available in this window. Use Windows voice typing instead (Win+H).", 5000); return; }
    REC = new SR();
    const me = REC;                  // ignore events from an older mic session
    DICT = null;
    REC.lang = 'en-US'; REC.continuous = true; REC.interimResults = true;
    // LIVE typing: words appear in the box while you talk (gray "guess" words get corrected in place),
    // like Claude's own voice mode. DICT.base = what was in the box before this stretch of talking;
    // every result rewrites base + everything heard since. If you type in the box mid-talk, it re-bases.
    REC.onresult = e => {
      if (REC !== me) return;
      const ta = $('#input'); if (!ta) return;
      if (DICT && DICT.stopped && ta.value !== DICT.last) return;   // mic is off and the box was sent/edited: drop the late copy
      let first = e.results.length;                 // first result that is still a guess (not final)
      for (let k = 0; k < e.results.length; k++) if (!e.results[k].isFinal) { first = k; break; }
      if (!DICT || ta.value !== DICT.last) {
        let v = ta.value, from = 0;
        if (DICT) {                                 // he typed mid-talk: keep his edit, drop the old guess words
          if (DICT.guess && v.endsWith(DICT.guess)) v = v.slice(0, -DICT.guess.length);
          from = DICT.first;
        }
        DICT = { base: v && !/\s$/.test(v) ? v + ' ' : v, from, last: '', guess: '', first: from,
                 pieces: [], over: {}, nfinal: 0, sent: from, stopped: DICT ? DICT.stopped : false };
      }
      const d = DICT;
      d.pieces = Array.from(e.results, r => r[0].transcript);
      d.nfinal = first;
      for (let k = Math.max(d.sent, d.from); k < first; k++) whisperPhrase(d, k, d.pieces[k]);  // a phrase just finished
      d.sent = Math.max(d.sent, first);
      renderDict();
      const i = $('#interim'); if (i && recOn) i.textContent = WH.ctx ? '🎤 listening… (Whisper fixes each phrase)' : '🎤 listening…';
    };
    REC.onerror = e => {
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') toast('Microphone is blocked. Allow it in the address-bar prompt, or use Win+H.', 5000);
      else if (e.error === 'network') toast("Voice typing needs internet. Try Win+H (Windows voice typing).", 5000);
      else if (e.error !== 'no-speech' && e.error !== 'aborted') toast('Mic error: ' + e.error);
      if (e.error !== 'no-speech') stopMic();
    };
    REC.onend = () => { if (REC !== me) return; DICT = null; if (recOn) { try { REC.start(); } catch (e) { stopMic(); } } else whisperStop(); };
    try {
      REC.start();
      recOn = true;
      if (!VOICE.micStart) VOICE.micStart = Date.now();
      $('#micBtn').classList.add('listening');
      $('#interim').textContent = '🎤 listening…';
      whisperStart();
    } catch (e) { toast('Could not start the mic: ' + e.message); }
  }

  // ------------------------------------------------------------------ COURSES
  const TABS = [
    ['overview', 'Overview'], ['pacing', 'Pacing Calendar'], ['assessments', 'Assessment Log'],
    ['mastery', 'Mastery'], ['patterns', 'Professor habits'], ['timeline', 'Canvas calendar'],
  ];
  const TAB_EMPTY = {
    overview: 'No course facts in the Course Record yet.',
    pacing: 'No Pacing Calendar yet. After class, open the Classroom in <b>Log a Class</b> mode and tell Claude what was covered.',
    assessments: 'No quizzes or exams logged yet. Log them in <b>Log a Class</b> mode.',
    mastery: 'No mastery table yet. It fills in as you study with Dr. Claude.',
    patterns: "No professor habits logged yet (how they write quizzes, what they repeat, what they grade hard).",
    timeline: 'No Canvas calendar for this class (it fills in when Canvas syncs).',
  };

  async function renderCourses(tok, arg, q) {
    const list = courses();
    const id = arg || lsGet('drc-course') || (list[0] && list[0].id);
    const tab = q.get('tab') || lsGet('drc-course-tab') || 'overview';
    const picker = `<div class="course-pick">${list.map(c => `<button class="cpick${c.id === id ? ' on' : ''}" data-c="${h(c.id)}"><b>${h(c.code)}</b><span>${h(c.professor || c.title)}</span></button>`).join('')}</div>`;
    if (!id || q.get('add')) {
      view.innerHTML = `<div class="page-head"><div><div class="eyebrow">Course records</div><h1>Courses</h1></div></div>${list.length ? picker : ''}
        ${list.length ? '' : emptyBox('📚', 'No classes yet', 'Connect Canvas in Settings to bring them in, or add one by hand below.')}<div id="addBox"></div>`;
      addClassForm($('#addBox'), c => { location.hash = '#/library?course=' + encodeURIComponent(c); });
      const pk = view.querySelector('.course-pick');
      if (pk) pk.addEventListener('click', e => { const b = e.target.closest('[data-c]'); if (b) location.hash = `#/courses/${encodeURIComponent(b.dataset.c)}`; });
      return;
    }
    view.innerHTML = `<div class="page-head"><div><div class="eyebrow">Course records</div><h1>Courses</h1></div></div>${picker}<div class="loading">Loading…</div>`;
    view.querySelector('.course-pick').addEventListener('click', e => {
      const b = e.target.closest('[data-c]');
      if (b) location.hash = `#/courses/${encodeURIComponent(b.dataset.c)}?tab=${tab}`;
    });
    const d = await api('/api/course?id=' + encodeURIComponent(id));
    if (stale(tok)) return;
    lsSet('drc-course', id); lsSet('drc-course-tab', tab);
    const c = d.course, sec = d.sections || {};
    const body = sec[tab] ? `<div class="doc md">${md(sec[tab])}</div>` : emptyBox('📝', 'Nothing here yet', TAB_EMPTY[tab] || '');
    const total = STATUS.reduce((a, s) => a + (d.counts[s] || 0), 0);
    view.innerHTML = `<div class="page-head"><div><div class="eyebrow">Course record</div><h1>${h(c.code)} ${h(c.title)}</h1>
        <div class="sub">${h(c.professor || '')}${c.term ? ' · ' + h(c.term) : ''}</div></div>
        <div class="row"><a class="btn primary" href="#/classroom?course=${encodeURIComponent(c.id)}">🎓 Study this</a>
        ${c.record ? '<button class="btn" id="openRec" title="Open the Course Record file">Open record</button>' : ''}
        <a class="btn ghost" href="#/library?course=${encodeURIComponent(c.id)}">📁 Files</a>
        <a class="btn ghost" href="#/courses?add=1" title="Add a class that isn't on Canvas">＋ Class</a></div></div>
      ${picker}
      ${total ? `<div class="card" style="margin-bottom:16px;padding:14px 18px"><div class="row" style="justify-content:space-between"><b>Mastery</b>${mcounts(d.counts)}</div><div style="margin-top:8px">${mbar(d.counts)}</div></div>` : ''}
      <div class="tabs">${TABS.map(([k, n]) => `<button class="tab${k === tab ? ' on' : ''}" data-tab="${k}">${n}</button>`).join('')}</div>
      ${body}`;
    view.querySelector('.course-pick').addEventListener('click', e => {
      const b = e.target.closest('[data-c]');
      if (b) location.hash = `#/courses/${encodeURIComponent(b.dataset.c)}?tab=${tab}`;
    });
    view.querySelector('.tabs').addEventListener('click', e => {
      const b = e.target.closest('[data-tab]');
      if (b) location.hash = `#/courses/${encodeURIComponent(id)}?tab=${b.dataset.tab}`;
    });
    const orb = $('#openRec');
    if (orb) orb.addEventListener('click', () => openPath(c.record));
  }

  // ------------------------------------------------------------------ LIBRARY
  const ICONS = [
    [/\.pdf$/i, '📕'], [/\.(docx?|rtf|odt)$/i, '📘'], [/\.(xlsx?|csv)$/i, '📗'], [/\.(pptx?)$/i, '📙'],
    [/\.(md|txt|log)$/i, '📝'], [/\.(png|jpe?g|gif|bmp|svg|webp|heic)$/i, '🖼️'], [/\.(zip|7z|rar)$/i, '🗜️'],
    [/\.(c|h|cpp|hpp|py|java|js|m|v|sv|vhd|ipynb|ps1)$/i, '💻'], [/\.(asc|raw|kicad_\w+|sch|brd|net)$/i, '⚡'],
    [/\.(mp4|mov|mkv|mp3|wav|m4a)$/i, '🎞️'], [/\.(html?|url|lnk)$/i, '🔗'],
  ];
  const fileIcon = f => f.dir ? '📁' : (ICONS.find(([re]) => re.test(f.name)) || [0, '📄'])[1];

  function fileRow(f, rel) {
    return `<div class="file" data-path="${h(f.path)}" data-dir="${f.dir ? 1 : 0}" title="${f.dir ? 'Open folder' : 'Open with its normal app'} · right-click: show in Explorer">
      <span class="ic">${fileIcon(f)}</span>
      <span class="nm">${h(f.name)}${rel ? `<span class="rel">${h(rel)}</span>` : ''}</span>
      <span class="sz">${f.dir ? '' : f.size != null ? fmtSize(f.size) : ''}</span>
      <span class="dt">${f.mtime ? h(fmtStamp(f.mtime)) : ''}</span></div>`;
  }

  async function renderLibrary(tok, arg, q) {
    const docs = APP.state.docs_root;
    const cid = q.has('course') ? q.get('course') : (lsGet('drc-lib-course') || '');
    const c = courseById(cid);
    const root = c && c.folder ? c.folder : docs;
    const path = q.get('path') || root;
    const query = q.get('q') || '';
    lsSet('drc-lib-course', c ? c.id : '');
    const chipList = courses().slice();
    if (c && c.past) chipList.push(c);
    const link = (o) => {
      const p = new URLSearchParams();
      const cc = 'course' in o ? o.course : (c ? c.id : '');
      p.set('course', cc);
      if (o.path) p.set('path', o.path);
      if (o.q) p.set('q', o.q);
      return '#/library?' + p.toString();
    };
    view.innerHTML = `<div class="page-head"><div><div class="eyebrow">Class files</div><h1>Library</h1>
        <div class="sub">Click a file to open it. Right-click to show it in File Explorer.</div></div></div>
      <div id="upBox"></div>
      <div id="bookBox"></div>
      <div class="qchips">${[`<a class="qchip${!c ? ' on' : ''}" href="${link({ course: '' })}">All classes</a>`]
        .concat(chipList.map(x => `<a class="qchip${c && x.id === c.id ? ' on' : ''}" href="${link({ course: x.id })}">${h(x.code)}</a>`)).join('')}</div>
      <div class="qchips" id="quick"></div>
      <div class="lib-bar"><label class="search">🔎<input id="libSearch" type="search" placeholder="Search file names in ${h(baseName(path))}…" value="${h(query)}"></label>
        <button class="btn" id="revealBtn" title="Open this folder in File Explorer">Open in Explorer</button></div>
      <div class="crumbs" id="crumbs"></div>
      <div id="fileList"><div class="loading">Loading files…</div></div>`;

    // crumbs: root -> current
    const sep = /[\\/]/;
    const rootParts = root.split(sep).filter(Boolean), pathParts = path.split(sep).filter(Boolean);
    const inside = pathParts.slice(0, rootParts.length).join('\\').toLowerCase() === rootParts.join('\\').toLowerCase();
    const crumbs = [];
    if (inside) {
      let acc = root;
      crumbs.push({ name: c ? c.code : 'Dr. Claude', path: root });
      for (const part of pathParts.slice(rootParts.length)) { acc = acc.replace(/[\\/]$/, '') + '\\' + part; crumbs.push({ name: part, path: acc }); }
    } else crumbs.push({ name: path, path });
    $('#crumbs').innerHTML = crumbs.map((x, i) => (i ? '<span class="faint">›</span>' : '') +
      `<button data-go="${h(x.path)}">${h(x.name)}</button>`).join('');
    $('#crumbs').addEventListener('click', e => {
      const b = e.target.closest('[data-go]');
      if (b) location.hash = link({ path: b.dataset.go });
    });
    $('#revealBtn').addEventListener('click', () => openPath(path));
    if (c && c.folder) uploadBox($('#upBox'), c, () => { if (!stale(tok)) showFiles(''); });
    // v1.4.5: textbook finder removed from the public build (upload your own book PDF with the upload box)

    const list = $('#fileList');
    list.addEventListener('click', e => {
      const r = e.target.closest('.file');
      if (!r) return;
      if (r.dataset.dir === '1') location.hash = link({ path: r.dataset.path });
      else openPath(r.dataset.path);
    });
    list.addEventListener('contextmenu', e => {
      const r = e.target.closest('.file');
      if (!r) return;
      e.preventDefault();
      openPath(r.dataset.path, 'reveal');
    });
    let deb = 0;
    $('#libSearch').addEventListener('input', e => {
      clearTimeout(deb);
      const v = e.target.value.trim();
      deb = setTimeout(() => { history.replaceState(null, '', link({ path: q.get('path') || '', q: v })); showFiles(v); }, 300);
    });

    if (c && c.folder) {
      api('/api/quickdirs?course=' + encodeURIComponent(c.id)).then(r => {
        if (stale(tok) || !r.dirs.length) return;
        $('#quick').innerHTML = r.dirs.map(d => `<a class="qchip${d.toLowerCase() === path.toLowerCase() ? ' on' : ''}" href="${link({ path: d })}">📂 ${h(baseName(d))}</a>`).join('');
      }).catch(() => {});
    }

    async function showFiles(qq) {
      const mytok = APP.tok;
      if (qq) {
        list.innerHTML = '<div class="loading">Searching…</div>';
        const r = await api(`/api/search?root=${encodeURIComponent(path)}&q=${encodeURIComponent(qq)}`);
        if (mytok !== APP.tok || $('#libSearch').value.trim() !== qq) return;
        list.innerHTML = r.results.length ? `<p class="small faint">${r.results.length}${r.results.length >= 300 ? '+' : ''} match${r.results.length === 1 ? '' : 'es'}</p><div class="files">${r.results.map(f => fileRow(f, f.rel)).join('')}</div>`
          : emptyBox('🔍', 'No matches', `Nothing named like “${h(qq)}” in ${h(baseName(path))}.`);
      } else {
        const r = await api('/api/files?path=' + encodeURIComponent(path));
        if (mytok !== APP.tok) return;
        list.innerHTML = r.items.length ? `<div class="files">${r.items.map(f => fileRow(f)).join('')}</div>` : emptyBox('📂', 'Empty folder', 'Nothing in here yet.');
      }
    }
    await showFiles(query);
  }

  // ------------------------------------------------------------------ GRADEBOOK
  async function renderGradebook(tok) {
    view.innerHTML = '<div class="loading">Loading grades…</div>';
    const r = await api('/api/gradebook');
    if (stale(tok)) return;
    const head = `<div class="page-head"><div><div class="eyebrow">Mock quiz & exam scores</div><h1>Gradebook</h1>
      <div class="sub">Dr. Claude writes your scores here after each Quiz or Mock Exam.</div></div>
      <button class="btn" id="gbFolder">Open folder</button></div>`;
    const body = r.books.length ? r.books.map(b => `<div class="card" style="margin-bottom:16px"><h2>📒 ${h(b.name)}
        <span class="count">updated ${h(fmtStamp(b.mtime))}</span></h2>
        <div class="doc md">${md(b.content)}</div>
        <div class="row" style="margin-top:10px"><button class="btn sm" data-open="${h(b.path)}">Open file</button></div></div>`).join('')
      : emptyBox('📒', 'No grades yet', 'When you finish a Quiz or Mock Exam in the Classroom, your score and the topics you missed land here.',
        '<a class="btn primary" href="#/classroom?mode=Mock%20Exam">Take a mock exam</a>');
    view.innerHTML = head + body;
    $('#gbFolder').addEventListener('click', () => openPath(r.folder));
  }

  // ------------------------------------------------------------------ GUIDE (Dr. Claude 101: the app, Codex, Codex in Chrome, good prompts)
  async function renderGuide(tok) {
    view.innerHTML = '<div class="loading">Loading the guide…</div>';
    const r = await api('/api/guide');
    if (stale(tok)) return;
    const ask = `#/classroom?course=${encodeURIComponent(r.course)}&mode=${encodeURIComponent('Office Hours')}`;
    const heads = (r.markdown.match(/^## .+$/gm) || []).map(x => x.slice(3));
    view.innerHTML = `<div class="page-head"><div><div class="eyebrow">Dr. Claude 101</div><h1>Guide</h1>
        <div class="sub">What Dr. Claude and Codex can do, and how to get the most out of AI. Got a question this doesn't answer? Ask it.</div></div>
        <a class="btn primary" href="${ask}">💬 Ask Dr. Claude about this</a></div>
      <div class="guide-toc">${heads.map((t, i) => `<button class="chip" data-gi="${i}">${h(t.replace(/^\d+\.\s*/, ''))}</button>`).join('')}</div>
      <div class="card"><div class="doc md guide-doc">${md(r.markdown.replace(/^# .+\n/, ''))}</div></div>
      <div class="row" style="margin:16px 0"><a class="btn primary" href="${ask}">💬 Ask Dr. Claude a question</a><a class="btn" href="#/ideas">💡 Send an idea</a></div>`;
    view.querySelectorAll('[data-gi]').forEach(b => b.addEventListener('click', () => {
      const hs = view.querySelectorAll('.guide-doc h2');
      if (hs[+b.dataset.gi]) hs[+b.dataset.gi].scrollIntoView({ behavior: 'smooth', block: 'start' });
    }));
  }

  // ------------------------------------------------------------------ IDEAS (send ideas / problems / wishes to whoever set up this Dr. Claude)
  const IDEA_ICON = { Idea: '💡', Problem: '🐞', Wish: '✨', Question: '❓' };
  async function renderIdeas(tok) {
    view.innerHTML = '<div class="loading">Loading…</div>';
    const r = await api('/api/ideas');
    if (stale(tok)) return;
    let kind = 'Idea';
    const status = it => it.sent ? '✅ Sent' : '⏳ Waiting to send';
    const list = r.ideas.length ? r.ideas.map(it => `<div class="idea-row">
        <div class="idea-main"><b>${IDEA_ICON[it.kind] || '💡'} ${h(it.kind)}</b> <span class="faint small">${h(fmtStamp(it.when))}</span>
          <div class="idea-text">${h(it.text)}</div></div>
        <div class="idea-side"><span class="pill">${status(it)}</span>
          ${it.sent ? '' : `<button class="btn sm" data-resend="${h(it.id)}">Send</button>`}
          <button class="btn sm ghost" data-del="${h(it.id)}" title="Remove from this list">🗑</button></div></div>`).join('')
      : '<div class="faint">Nothing sent yet. Your ideas will show up here.</div>';
    view.innerHTML = `<div class="page-head"><div><div class="eyebrow">Make Dr. Claude better</div><h1>💡 Ideas</h1>
        <div class="sub">Something you wish it did, something that's broken, or a question? Write it like a text. It goes straight to the person who set up your Dr. Claude (no email needed), and changes show up by themselves in a later update.</div></div></div>
      <div class="card"><div class="chips" id="ideaKinds">${r.kinds.map(k => `<button class="chip${k === kind ? ' on' : ''}" data-kind="${h(k)}">${IDEA_ICON[k] || ''} ${h(k)}</button>`).join('')}</div>
        <textarea id="ideaText" class="idea-in" rows="4" placeholder="e.g. &quot;Can the quiz show a timer?&quot;  ·  &quot;The sync button didn't work on Tuesday&quot;  ·  &quot;I wish it made flashcards&quot;"></textarea>
        <div class="row"><button class="btn primary" id="ideaSend">Send</button><span class="faint small">Tip: 🎤 Win+H lets you talk instead of type.</span></div>
</div>
      <div class="card" style="margin-top:16px"><h2>What you've sent</h2><div class="idea-list">${list}</div></div>`;
    $('#ideaKinds').addEventListener('click', e => {
      const b = e.target.closest('[data-kind]'); if (!b) return;
      kind = b.dataset.kind;
      $$('#ideaKinds .chip').forEach(x => x.classList.toggle('on', x === b));
    });
    const after = res => {
      if (res.idea.sent) toast('Sent. Thank you! 🙌');
      else toast(res.idea.error || "Saved. It will send by itself once you're online.", 5000);
      renderIdeas(APP.tok);
    };
    $('#ideaSend').addEventListener('click', async () => {
      const text = $('#ideaText').value.trim();
      if (!text) return toast('Write your idea first.');
      $('#ideaSend').disabled = true;
      try { const res = await api('/api/ideas/add', { kind, text }); $('#ideaText').value = ''; after(res); }
      catch (err) { toast(err.message, 4000); }
      $('#ideaSend').disabled = false;
    });
    view.querySelectorAll('[data-resend]').forEach(b => b.addEventListener('click', async () => {
      try { after(await api('/api/ideas/resend', { id: b.dataset.resend })); view.scrollTop = 0; } catch (err) { toast(err.message, 4000); }
    }));
    view.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
      await api('/api/ideas/delete', { id: b.dataset.del }); renderIdeas(APP.tok);
    }));
  }

  // ------------------------------------------------------------------ shared setup panels (Settings + first-run setup)
  const PREF_HELP = {
    learning_mode: 'Off = Dr. Claude just explains and answers.',
    labels: 'The question you’re on stays pinned at the top.',
    steps: 'Methods play like a short video, one step at a time.',
    videos: 'A short YouTube clip, jumped to the right spot.',
  };
  function prefsHtml(p) {
    return `<div class="prefs">${(APP.state.prefs || []).map(x => `<label class="pref"><input type="checkbox" data-pref="${h(x.key)}"${p.prefs[x.key] ? ' checked' : ''}>
      <span><b>${h(x.label)}</b>${PREF_HELP[x.key] ? `<small>${h(PREF_HELP[x.key])}</small>` : ''}</span></label>`).join('')}</div>`;
  }
  const readPrefs = el => Object.fromEntries($$('[data-pref]', el).map(i => [i.dataset.pref, i.checked]));

  // "Brain" = the AI that does the teaching. ChatGPT through OpenAI's Codex app (school account), or a Gemini key.
  function brainPanel(box, tok, onReady) {
    const draw = async () => {
      const s = APP.state.settings;
      const k = s.brain || '';
      box.innerHTML = `<div class="seg big-seg" id="brainSeg">
          <button type="button" data-v="claude" class="${k === 'claude' ? 'on' : ''}"><b>Claude</b><small>have Claude? best teacher</small></button>
          <button type="button" data-v="codex" class="${k === 'codex' ? 'on' : ''}"><b>ChatGPT</b><small>school account, through Codex</small></button>
          <button type="button" data-v="gemini" class="${k === 'gemini' ? 'on' : ''}"><b>Google Gemini</b><small>free key, backup option</small></button></div>
        <div id="brainBody" style="margin-top:14px">${k ? '<div class="loading">Checking…</div>' : '<p class="muted">Pick one. You can switch any time in Settings.</p>'}</div>`;
      $('#brainSeg', box).addEventListener('click', async e => {
        const b = e.target.closest('[data-v]');
        if (!b) return;
        const r = await api('/api/settings', { brain: b.dataset.v });
        APP.state.settings = r.settings;
        draw();
      });
      if (!k) return;
      const body = $('#brainBody', box);
      const st = await api('/api/brain/status?brain=' + k).catch(e => ({ ready: false, message: e.message }));
      if (stale(tok) && tok !== -1) return;
      const status = `<div class="status ${st.ready ? 'ok' : 'warn'}">${st.ready ? '✅' : '⚠️'} ${MD.inline(st.message || '')}</div>`;
      if (k === 'claude') {
        body.innerHTML = macify(`${status}
          <ol class="steps-list">
            <li>${st.installed === false ? '<button class="btn primary" id="clInstall">Install Claude</button> <span class="small muted">Anthropic’s official installer opens in a black window. Wait for “Done”, then close it.</span>'
              : '<span class="muted">Claude is installed.</span>'}</li>
            <li><button class="btn${st.installed !== false && !st.ready ? ' primary' : ''}" id="clLogin"${st.installed === false ? ' disabled' : ''}>Sign in to Claude</button>
              <div class="small muted">A browser page opens. Sign in with the same account you use on claude.ai, then click <b>Authorize</b>.</div></li>
            <li><button class="btn" id="clCheck">Check again</button> <button class="btn ghost" id="bTest"${st.ready ? '' : ' disabled'}>Test a reply</button> <span class="small" id="bTestOut"></span></li>
          </ol>
          <div class="small muted">Uses your own Claude plan (Pro or Max). Dr. Claude only works inside your <code>Dr. Claude</code> folder.</div>`);
        const on = (id, fn) => { const el = $('#' + id, body); if (el) el.addEventListener('click', fn); };
        on('clInstall', async () => { await api('/api/brain/claude/install', {}); toast('Installer opened in a new window.', 4000); });
        on('clLogin', async () => { try { await api('/api/brain/claude/login', {}); toast('Sign-in opened. Finish it in the browser, then click Check again.', 6000); } catch (e) { toast(e.message, 5000); } });
        on('clCheck', draw);
      } else if (k === 'codex') {
        body.innerHTML = macify(`${status}
          <ol class="steps-list">
            <li>${st.installed === false ? '<button class="btn primary" id="cxInstall">Install Codex</button> <span class="small muted">OpenAI’s official installer opens in a black window. Wait for “Done”, then close it.</span>'
              : '<span class="muted">Codex is installed.</span>'}</li>
            <li><button class="btn${st.installed !== false && !st.ready ? ' primary' : ''}" id="cxLogin"${st.installed === false ? ' disabled' : ''}>Sign in with your school ChatGPT</button>
              <button class="btn ghost sm" id="cxDevice"${st.installed === false ? ' disabled' : ''} title="Use this if the browser sign-in doesn't come back">Use a code instead</button>
              <div class="small muted">A browser page opens. Choose <b>Sign in with ChatGPT</b> and use your school email (it goes through your school’s sign-in).</div></li>
            <li><button class="btn" id="cxCheck">Check again</button> <button class="btn ghost" id="bTest"${st.ready ? '' : ' disabled'}>Test a reply</button> <span class="small" id="bTestOut"></span></li>
          </ol>
          <details class="small"><summary>Advanced</summary>
            <div class="field"><label>File access</label>${seg('codex_sandbox', [['workspace-write', 'Can update my Course Records'], ['read-only', 'Read only']], s.codex_sandbox)}
            <div class="help">Codex can only ever touch the <code>Dr. Claude</code> folder. Pick “Read only” if updates fail.</div></div>
            <div class="field"><label for="cxModel">Model (optional)</label><input id="cxModel" value="${h(s.codex_model)}" placeholder="blank = Codex’s default"></div>
            <button class="btn sm" id="cxSave">Save</button></details>`);
        const on = (id, fn) => { const el = $('#' + id, body); if (el) el.addEventListener('click', fn); };
        on('cxInstall', async () => { await api('/api/brain/codex/install', {}); toast('Installer opened in a new window.', 4000); });
        on('cxLogin', async () => { try { await api('/api/brain/codex/login', {}); toast('Sign-in opened. Finish it in the browser, then click Check again.', 6000); } catch (e) { toast(e.message, 5000); } });
        on('cxDevice', async () => { try { await api('/api/brain/codex/login', { device: true }); toast('A window shows a code and a link. Open the link and type the code.', 7000); } catch (e) { toast(e.message, 5000); } });
        on('cxCheck', draw);
        on('cxSave', async () => {
          const r = await api('/api/settings', { codex_sandbox: $('[data-seg="codex_sandbox"] .on', body).dataset.v, codex_model: $('#cxModel', body).value.trim() });
          APP.state.settings = r.settings; toast('Saved.');
        });
        $$('[data-seg]', body).forEach(wireSeg);
      } else {
        body.innerHTML = `${status}
          <ol class="steps-list">
            <li>Open <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">aistudio.google.com/apikey</a>, sign in with a Google account, click <b>Create API key</b>, and copy it.</li>
            <li><div class="row"><input id="gmKey" type="password" placeholder="${st.has_key ? 'A key is saved. Paste a new one to replace it.' : 'Paste the key here'}" style="flex:1;min-width:220px" spellcheck="false">
              <button class="btn primary" id="gmSave">Save &amp; test</button></div>
              <div class="small muted">Saved ${IS_MAC ? 'in your Mac’s Keychain' : 'encrypted with your Windows account'} (it never leaves this laptop except to talk to Google).</div></li>
            <li><button class="btn ghost" id="bTest"${st.ready ? '' : ' disabled'}>Test a reply</button> <span class="small" id="bTestOut"></span></li>
          </ol>
          <p class="small warn-note">Heads-up: on the free tier, Google may use what you send to improve its products, and people may review it. Don’t paste anything private.</p>`;
        $('#gmSave', body).addEventListener('click', async () => {
          const key = $('#gmKey', body).value.trim();
          try { const r = await api('/api/brain/gemini/key', { key }); toast(r.ready ? 'Key works!' : r.message, 5000); draw(); } catch (e) { toast(e.message, 5000); }
        });
      }
      const t = $('#bTest', body);
      if (t) t.addEventListener('click', async () => {
        const out = $('#bTestOut', body);
        out.textContent = 'Asking…';
        try { const r = await api('/api/brain/test', {}); out.innerHTML = r.ok ? '✅ ' + h(r.text) : '⚠️ ' + h(r.error || 'No answer.'); }
        catch (e) { out.textContent = '⚠️ ' + e.message; }
      });
      if (st.ready && onReady) onReady();
    };
    draw();
  }

  function canvasPanel(box, tok, onSynced) {
    const draw = async () => {
      const st = await api('/api/canvas/status');
      if (stale(tok) && tok !== -1) return;
      const url = st.url || 'https://canvas.cpp.edu';
      box.innerHTML = `${st.has_token ? `<div class="status ok">✅ Canvas is connected${st.synced ? ` · last sync ${h(fmtStamp(st.synced))}` : ''}.</div>`
        : st.connected ? `<div class="status ok">✅ Canvas syncs through your browser${st.synced ? ` · last sync ${h(fmtStamp(st.synced))}` : ''}. Click <b>🎓 Sync Dr. Claude</b> on your Canvas tab to refresh.</div>` : ''}
        <ol class="steps-list">
          <li>Open <a href="${h(url)}/profile/settings" target="_blank" rel="noopener">Canvas → Account → Settings</a>.</li>
          <li>Scroll to <b>Approved Integrations</b> and click <b>+ New Access Token</b>. Purpose: <i>Dr. Claude</i>. Leave the date empty (or pick the end of the term). Click <b>Generate Token</b>.</li>
          <li>Copy the long token (you only see it once) and paste it here:
            <div class="row" style="margin-top:6px"><input id="cvUrl" value="${h(url)}" style="width:210px" spellcheck="false" title="Your school's Canvas address">
            <input id="cvTok" type="password" placeholder="${st.has_token ? 'Saved. Paste a new one to replace it.' : 'Paste the token'}" style="flex:1;min-width:200px" spellcheck="false">
            <button class="btn primary" id="cvTest">Test &amp; connect</button></div>
            <div class="small" id="cvMsg"></div></li>
        </ol>
        <div class="small muted">The token is saved encrypted with your Windows account. It only reads your classes. You can delete it in Canvas any time.</div>
        <details class="card-sub" id="cvBrowser" ${!st.has_token ? 'open' : ''} style="margin-top:12px"><summary><b>No “+ New Access Token” button?</b> Sync through your browser instead (no token)</summary>
          <ol class="steps-list">
            <li>Show your bookmarks bar in Chrome: press <b>Ctrl+Shift+B</b>.</li>
            <li>Drag this button onto the bookmarks bar: <a class="btn primary sm" id="cvBm" href="#" title="Drag me to your bookmarks bar">🎓 Sync Dr. Claude</a>
              <span class="small muted">(Or <a href="#" id="cvBmCopy">copy it</a>, then right-click the bookmarks bar → Add page, Name: Sync Dr. Claude, URL: paste.)</span></li>
            <li>Open <a href="${h(url)}" target="_blank" rel="noopener">Canvas</a> in Chrome and log in like normal.</li>
            <li>Click <b>🎓 Sync Dr. Claude</b> on the bookmarks bar. A small Dr. Claude window opens and syncs your classes. Keep it open until it says <b>Done</b>. If Chrome blocks the pop-up, click <b>Always allow</b>, then click the bookmark again.</li>
          </ol>
          <div class="small muted">Click the bookmark again any time to pull in new files and due dates. It only reads your own classes, using your normal Canvas login.</div>
          <div class="small" id="cvBmMsg"></div></details>
        <div class="row" style="margin-top:10px">${st.has_token ? '<button class="btn" id="cvSync">⟳ Sync now</button><button class="btn ghost sm" id="cvForget">Forget token</button>' : ''}</div>
        <div id="cvProgress"></div>`;
      if (IS_MAC) box.innerHTML = macify(box.innerHTML);
      api('/api/canvas/bridge').then(b => {
        const a = $('#cvBm', box), m = $('#cvBmMsg', box);
        if (!a) return;
        if (!b.bookmarklet) { m.textContent = '⚠️ The browser sync helper didn’t start. Restart Dr. Claude and try again.'; return; }
        a.href = b.bookmarklet;
        a.addEventListener('click', e => { e.preventDefault(); toast('Drag this button to your bookmarks bar, then click it on your Canvas tab.', 4500); });
        $('#cvBmCopy', box).addEventListener('click', async e => {
          e.preventDefault();
          try { await navigator.clipboard.writeText(b.bookmarklet); toast('Copied. Paste it as the URL of a new bookmark.'); } catch (x) { toast('Couldn’t copy. Drag the button instead.'); }
        });
      }).catch(() => {});
      $('#cvTest', box).addEventListener('click', async () => {
        const msg = $('#cvMsg', box);
        msg.textContent = 'Checking…';
        try {
          const r = await api('/api/canvas/token', { url: $('#cvUrl', box).value.trim(), token: $('#cvTok', box).value.trim() });
          msg.innerHTML = (r.ok ? '✅ ' : '⚠️ ') + h(r.message);
          if (r.ok) { await api('/api/canvas/sync', {}); draw(); }
        } catch (e) { msg.textContent = '⚠️ ' + e.message; }
      });
      const sy = $('#cvSync', box);
      if (sy) sy.addEventListener('click', async () => { try { await api('/api/canvas/sync', {}); draw(); } catch (e) { toast(e.message, 4000); } });
      const fg = $('#cvForget', box);
      if (fg) fg.addEventListener('click', async () => { await api('/api/canvas/forget', {}); toast('Token removed from this laptop.'); draw(); });
      if (st.running || st.finished) watchSync($('#cvProgress', box), tok, async s2 => { await refreshState(); if (onSynced) onSynced(s2); });
    };
    draw();
  }

  function seg(name, opts, cur) {
    return `<div class="seg" data-seg="${name}">${opts.map(([v, l]) => `<button type="button" data-v="${v}" class="${String(cur) === String(v) ? 'on' : ''}">${l}</button>`).join('')}</div>`;
  }
  function wireSeg(g, cb) {
    g.addEventListener('click', e => {
      const b = e.target.closest('[data-v]');
      if (!b) return;
      $$('button', g).forEach(x => x.classList.toggle('on', x === b));
      if (cb) cb(b.dataset.v);
    });
  }

  function addClassForm(box, done) {
    box.innerHTML = `<form class="card add-class" autocomplete="off"><h2>➕ Add a class by hand</h2>
      <p class="small muted">For a class that isn’t on Canvas, or if you’d rather upload the files yourself.</p>
      <div class="row"><input name="code" placeholder="Code, e.g. ARO 1011L" required style="width:170px">
      <input name="title" placeholder="Title, e.g. Intro to Aerospace Lab" style="flex:1;min-width:200px">
      <input name="professor" placeholder="Professor (optional)" style="width:190px">
      <button class="btn primary">Add class</button></div></form>`;
    $('form', box).addEventListener('submit', async e => {
      e.preventDefault();
      const f = e.target;
      try {
        const r = await api('/api/course/add', { code: f.code.value, title: f.title.value, professor: f.professor.value });
        APP.state.courses = r.courses;
        toast('Class added. Upload its files in the Library.');
        if (done) done(r.course);
      } catch (err) { toast(err.message, 5000); }
    });
  }

  // Textbook finder: ISBN -> book details + free copies -> web search (filetype:pdf) -> download -> the student checks it
  // -> only then it goes into <class>\My Files\Textbooks\. Nothing is kept until they say "yes, that's the right book".
  // 📚 "No textbook yet" notice: which classes have no book in their files, and what their syllabus names
  async function booksNotice(box, tok) {
    if (!box) return;
    let r;
    try { r = await api('/api/books/needs'); } catch (e) { return; }
    if (stale(tok) || !box.isConnected) return;
    const miss = r.courses.filter(c => !c.has_book && !c.dismissed);
    if (!miss.length) { box.innerHTML = ''; return; }
    const findLink = (c, b) => {
      const p = new URLSearchParams({ course: c.id });
      if (b && b.isbn) p.set('book_isbn', b.isbn);
      else if (b) { p.set('book_title', b.title || ''); if (b.authors && b.authors[0]) p.set('book_author', b.authors[0]); if (b.edition) p.set('book_ed', b.edition); }
      else p.set('book_open', '1');
      return '#/library?' + p.toString();
    };
    const bookLine = (c, b) => `<div class="bk-line"><span>📘 <b>${h(b.title || 'ISBN ' + b.isbn)}</b>${b.authors && b.authors.length ? ' · ' + h(b.authors.join(', ')) : ''}${b.edition ? ' · ' + h(b.edition) : ''}${b.isbn && b.title ? ' · ISBN ' + h(b.isbn) : ''}${b.required === false ? ' <span class="chip">optional</span>' : ''}</span>
        <a class="btn sm primary" href="${findLink(c, b)}">🔎 Find it</a></div>`;
    box.innerHTML = `<div class="card books-card"><h2>📚 Missing textbooks <span class="count">${miss.length}</span></h2>
      <p class="small muted">Dr. Claude teaches best with the real book. These classes don't have one in their files yet.</p>
      ${miss.map(c => `<div class="bk-course"><div class="bk-head"><b>${h(c.code)}</b> <span class="muted small">${h(c.title)}</span>
          <span class="spacer"></span><button class="btn sm ghost" data-nobook="${h(c.id)}" title="Hide this: the class has no textbook, or you have a paper copy">I don't need one</button></div>
        ${c.books.length ? c.books.map(b => bookLine(c, b)).join('') + (c.books.some(b => !b.title) && c.mentions.length ? `<div class="small muted">From your syllabus: “${h(c.mentions[0].slice(0, 200))}”</div>` : '')
          : `<div class="bk-line"><span class="small muted">${c.mentions.length ? 'Your syllabus mentions books, but I couldn\'t pin down the title yet.' : 'I didn\'t find a textbook named in your syllabus.'} If your class uses one, add it by its ISBN.</span>
            <a class="btn sm" href="${findLink(c, null)}">📕 Add one</a></div>`}</div>`).join('')}</div>`;
    box.querySelectorAll('[data-nobook]').forEach(b => b.addEventListener('click', async () => {
      await api('/api/books/dismiss', { course: b.dataset.nobook, why: 'not needed' }).catch(() => {});
      toast('Hidden. You can still add a book any time in the Library.'); booksNotice(box, APP.tok);
    }));
  }

  const BOOK = { book: null, results: null, job: null, open: false, busy: '' };
  function bookFinder(box, c, done, pre) {
    const draw = () => {
      const B = BOOK;
      const bk = B.book;
      let html = `<details class="card book-finder"${B.open || bk ? ' open' : ''}><summary><b>📕 Find a textbook by ISBN</b>
          <span class="small muted">The ISBN is on the back cover above the barcode, or on the copyright page.</span></summary>
        <div class="row" style="margin-top:10px"><input id="isbnIn" class="input" placeholder="ISBN, e.g. 978-0-262-04630-5" value="${h(bk ? bk.isbn : '')}" style="max-width:260px">
          <button class="btn primary sm" id="isbnGo">Find it</button>${B.busy ? `<span class="small muted">${h(B.busy)}</span>` : ''}</div>`;
      if (bk) {
        html += `<div class="book-card">${bk.cover ? `<img src="${h(bk.cover)}" alt="" class="book-cover">` : '<div class="book-cover none">📘</div>'}
          <div><div class="book-title">${h(bk.title)}${bk.subtitle ? `: <span class="muted">${h(bk.subtitle)}</span>` : ''}</div>
          <div class="small">${h((bk.authors || []).join(', '))}</div>
          <div class="small muted">${[bk.edition, bk.publisher, bk.year, bk.pages ? bk.pages + ' pages' : '', bk.isbn ? 'ISBN ' + bk.isbn : ''].filter(Boolean).map(h).join(' · ')}</div>
          ${(bk.free || []).map(f => `<div class="book-free">🎁 ${h(f.label)} ${f.kind === 'pdf' ? `<button class="btn sm" data-dl="${h(f.url)}">⬇ Download &amp; check</button>` : `<button class="btn sm" data-url="${h(f.url)}">Open</button>`}</div>`).join('')}
          <div class="row" style="margin-top:8px"><button class="btn sm" id="bookWeb">🔎 Search the web for a PDF</button>
            <button class="btn sm ghost" id="bookGoogle" title="Opens the same filetype:pdf search in your web browser">Open this search in Google</button></div></div></div>`;
      }
      if (B.job) {
        const j = B.job;
        if (j.state === 'downloading') html += `<div class="book-job">⬇ Downloading… ${j.got ? fmtSize(j.got) : ''}${j.total ? ' of ' + fmtSize(j.total) : ''} <button class="btn sm ghost" data-discard>Cancel</button></div>`;
        else if (j.state === 'error') html += `<div class="book-job bad">⚠️ ${h(j.error)}</div>`;
        else if (j.state === 'done') {
          const v = { likely: ['ok', '✅ This looks like the right book.'], unsure: ['warn', '🤔 Not sure this is the right book.'], unlikely: ['bad', '❌ This probably isn\'t the right book.'] }[j.verdict] || ['warn', ''];
          html += `<div class="book-job ${v[0]}"><b>Is this the right book? Check it before I keep it.</b>
            <div>${h(v[1])} ${j.pages ? `${j.pages} pages · ` : ''}${fmtSize(j.size || 0)}${j.pdf_title ? ` · titled “${h(j.pdf_title)}”` : ''}</div>
            <ul class="small">${(j.signs || []).map(s => `<li>${h(s)}</li>`).join('')}</ul>
            ${j.preview ? `<div class="book-preview small">${h(j.preview)}…</div>` : ''}
            <div class="row"><button class="btn sm" data-bookopen>👀 Open it to look</button>
              <button class="btn sm primary" data-keep>✅ Yes, that's it: add to ${h(c ? c.code + ' ' : '')}Library</button>
              <button class="btn sm" data-discard>❌ No, delete it</button></div></div>`;
        }
      }
      if (B.results) {
        const rs = B.results.results || [];
        if (rs.length) html += `<div class="book-how small"><b>How to get it:</b> click <b>🌐 Open link</b> to look at it first. If it's the right book, save it with the
          <b>⬇ download button</b> in the PDF viewer (or press <b>Ctrl+S</b>), then drag it into the <b>Add your own files</b> box above (or click <b>Pick files</b>).
          Or click <b>⬇ Let Dr. Claude download it</b>: it checks the title and ISBN and asks you before keeping it.</div>
          <p class="small faint">Only keep copies you're allowed to use: free/open textbooks (like OpenStax), your school library, or a book you own.</p>`;
        html += `<div class="small muted" style="margin:10px 0 4px">Searched: ${(B.results.queries || []).map(q => `<code>${h(q)}</code>`).join(' · ')}</div>`;
        html += rs.length ? `<div class="book-results">${rs.map(r => `<div class="book-res"><div><div class="t">${r.pdf ? '<span class="chip">PDF</span> ' : ''}${h(r.title || r.url)}</div>
            <div class="small faint">${h(r.site)}</div>${r.snippet ? `<div class="small muted">${h(r.snippet.slice(0, 180))}</div>` : ''}</div>
            <div class="row"><button class="btn sm primary" data-url="${h(r.url)}" title="Opens it in your web browser so you can look first">🌐 Open link</button>
              <button class="btn sm" data-copy="${h(r.url)}" title="Copy the link">📋 Copy link</button>
              <button class="btn sm ghost" data-dl="${h(r.url)}" title="Dr. Claude downloads it, checks it's the right book, and asks you before keeping it">⬇ Let Dr. Claude download it</button></div></div>`).join('')}</div>`
          : `<p class="small muted">${h(B.results.error || 'No PDFs found.')} Try "Open this search in Google".</p>`;
      }
      box.innerHTML = html + '</details>';
    };
    const poll = async () => {
      if (!BOOK.job || BOOK.job.state !== 'downloading') return;
      try { BOOK.job = Object.assign(BOOK.job, await api('/api/book/job?id=' + BOOK.job.id)); } catch (e) { /* try again */ }
      if (BOOK.job.state === 'gone') BOOK.job = null;
      if (box.isConnected) draw();
      if (BOOK.job && BOOK.job.state === 'downloading') setTimeout(poll, 700);
    };
    const find = async () => {
      const isbn = ($('#isbnIn', box).value || '').trim();
      if (!isbn) return;
      BOOK.busy = 'Looking it up…'; BOOK.results = null; draw();
      try { BOOK.book = (await api('/api/book/lookup', { isbn })).book; } catch (e) { BOOK.book = null; toast(e.message, 6000); }
      BOOK.busy = ''; draw();
    };
    box.addEventListener('toggle', e => { if (e.target.matches('details')) BOOK.open = e.target.open; }, true);
    box.addEventListener('keydown', e => { if (e.target.id === 'isbnIn' && e.key === 'Enter') find(); });
    box.addEventListener('click', async e => {
      const t = e.target;
      if (t.closest('#isbnGo')) return find();
      if (t.closest('#bookWeb')) {
        BOOK.busy = 'Searching the web for a PDF…'; draw();
        try { BOOK.results = await api('/api/book/search', { book: BOOK.book }); } catch (err) { toast(err.message, 5000); }
        BOOK.busy = ''; return draw();
      }
      if (t.closest('#bookGoogle')) {
        const q = `"${BOOK.book.title.replace(/\s*[:(].*$/, '')}" ${((BOOK.book.authors || [''])[0] || '').split(' ').pop()} filetype:pdf`;
        return api('/api/openurl', { url: 'https://www.google.com/search?q=' + encodeURIComponent(q) }).catch(err => toast(err.message));
      }
      const cp = t.closest('[data-copy]');
      if (cp) { try { await navigator.clipboard.writeText(cp.dataset.copy); toast('Link copied. Paste it in your browser.'); } catch (err) { toast('Could not copy.'); } return; }
      const u = t.closest('[data-url]');
      if (u) return api('/api/openurl', { url: u.dataset.url }).catch(err => toast(err.message));
      const dl = t.closest('[data-dl]');
      if (dl) {
        if (BOOK.job && BOOK.job.id) await api('/api/book/discard', { id: BOOK.job.id }).catch(() => {});
        try { BOOK.job = await api('/api/book/download', { url: dl.dataset.dl, book: BOOK.book }); } catch (err) { return toast(err.message, 5000); }
        draw(); box.querySelector('.book-job') && box.querySelector('.book-job').scrollIntoView({ block: 'nearest' });
        return poll();
      }
      if (t.closest('[data-bookopen]')) return api('/api/book/open', { id: BOOK.job.id }).catch(err => toast(err.message));
      if (t.closest('[data-discard]')) {
        await api('/api/book/discard', { id: BOOK.job.id }).catch(() => {});
        BOOK.job = null; toast('Deleted. Try another result.'); return draw();
      }
      if (t.closest('[data-keep]')) {
        try {
          const r = await api('/api/book/keep', { id: BOOK.job.id, course: c ? c.id : '' });
          BOOK.job = null; draw();
          toast(`Added to the Library: ${baseName(r.path)}`, 5000);
          if (done) done();
        } catch (err) { toast(err.message, 5000); }
      }
    });
    draw();
    poll();
    if (pre && (pre.isbn || pre.title || pre.open)) {
      Object.assign(BOOK, { open: true, book: null, results: null });
      (async () => {
        if (pre.isbn) {
          $('#isbnIn', box).value = pre.isbn;
          await find();
        } else if (pre.title) {
          BOOK.book = { title: pre.title, authors: pre.author ? [pre.author] : [], edition: pre.edition, isbn: '', free: [] };
        } else { draw(); box.querySelector('#isbnIn').focus(); return; }
        if (!BOOK.book) return;
        BOOK.busy = 'Searching the web for a PDF…'; draw();
        try { BOOK.results = await api('/api/book/search', { book: BOOK.book }); } catch (err) { toast(err.message, 5000); }
        BOOK.busy = ''; draw();
        if (box.isConnected) box.scrollIntoView({ block: 'start', behavior: 'smooth' });
      })();
    }
  }

  // Upload box: drag files or whole folders in, or pick them. Files land in <class>\My Files\.
  function uploadBox(box, c, done) {
    box.innerHTML = `<div class="dropzone" id="dz"><b>⬆ Add your own files to ${h(c.code)}</b>
      <span class="small muted">Drag files or folders here (slides, notes, old quizzes…), or</span>
      <span class="row"><button class="btn sm" id="pickF">Pick files</button><button class="btn sm" id="pickD">Pick a folder</button></span>
      <input type="file" id="inF" multiple hidden><input type="file" id="inD" webkitdirectory hidden>
      <div class="small" id="upMsg"></div></div>`;
    const dz = $('#dz', box), msg = $('#upMsg', box);
    const send = async list => {
      if (!list.length) return;
      let ok = 0, bad = 0;
      for (const [file, rel] of list) {
        msg.textContent = `Uploading ${ok + bad + 1} of ${list.length}: ${rel}`;
        try {
          const r = await fetch(`/api/upload?course=${encodeURIComponent(c.id)}&rel=${encodeURIComponent(rel)}`,
            { method: 'POST', headers: { 'X-Dr-Claude': '1', 'Content-Type': 'application/octet-stream' }, body: file });
          if (r.ok) ok++; else bad++;
        } catch (e) { bad++; }
      }
      msg.textContent = `Added ${ok} file${ok === 1 ? '' : 's'} to My Files${bad ? ` (${bad} failed)` : ''}.`;
      if (done) done();
    };
    const fromInput = inp => Array.from(inp.files).map(f => [f, f.webkitRelativePath || f.name]);
    $('#pickF', box).addEventListener('click', () => $('#inF', box).click());
    $('#pickD', box).addEventListener('click', () => $('#inD', box).click());
    $('#inF', box).addEventListener('change', e => send(fromInput(e.target)));
    $('#inD', box).addEventListener('change', e => send(fromInput(e.target)));
    const walk = (entry, pre) => new Promise(res => {
      if (entry.isFile) entry.file(f => res([[f, pre + f.name]]), () => res([]));
      else if (entry.isDirectory) {
        const rd = entry.createReader(), all = [];
        const more = () => rd.readEntries(async es => {
          if (!es.length) { const sub = await Promise.all(all.map(x => walk(x, pre + entry.name + '/'))); res(sub.flat()); }
          else { all.push(...es); more(); }
        }, () => res([]));
        more();
      } else res([]);
    });
    dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('over'); });
    dz.addEventListener('dragleave', () => dz.classList.remove('over'));
    dz.addEventListener('drop', async e => {
      e.preventDefault(); dz.classList.remove('over');
      const entries = Array.from(e.dataTransfer.items || []).map(i => i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean);
      const list = entries.length ? (await Promise.all(entries.map(x => walk(x, '')))).flat()
        : Array.from(e.dataTransfer.files).map(f => [f, f.name]);
      send(list);
    });
  }

  // ------------------------------------------------------------------ COMMAND (the student's coach for HOW Dr. Claude teaches)
  const CMD = { chat: [], pending: null };
  const ruleLine = r => r ? `<div class="rule-text">${r.group === 'Per-class' && r.course ? `<span class="chip">${h(r.course)}</span> ` : ''}${h(r.text)}</div>
      ${r.why ? `<div class="small faint">why: “${h(r.why)}”</div>` : ''}` : '<div class="faint">(nothing)</div>';
  function proposalHtml(list, pick) {
    return list.map((p, i) => `<div class="proposal">
      <div class="row" style="justify-content:space-between"><b>${pick ? `<label><input type="checkbox" data-pick="${i}" checked> ` : ''}${h(p.summary)}${pick ? '</label>' : ''}</b>
        <span class="chip">${h((p.after || p.before).group)}</span></div>
      <div class="ba">${p.before ? `<div class="before"><div class="small faint">Before</div>${ruleLine(p.before)}${p.after && p.after.on === false ? '' : ''}</div>` : ''}
        <div class="after"><div class="small faint">${p.after ? (p.after.on === false ? 'After (paused)' : 'After') : 'After'}</div>${p.after ? ruleLine(p.after) : '<div class="faint">removed</div>'}</div></div></div>`).join('');
  }

  async function renderCommand(tok, arg, q) {
    view.innerHTML = '<div class="loading">Opening Command…</div>';
    const st = await api('/api/command');
    if (stale(tok)) return;
    const groups = st.groups.map(g => {
      const rs = st.rules.filter(r => r.group === g);
      if (!rs.length) return '';
      return `<div class="rule-group"><h3>${h(g)}</h3>${rs.map(r => `<div class="rule${r.on === false ? ' off' : ''}" data-rule="${h(r.id)}">
        <label class="switch" title="${r.on === false ? 'Paused: click to turn on' : 'On: click to pause'}"><input type="checkbox" data-toggle${r.on === false ? '' : ' checked'}><span></span></label>
        <div class="rule-body">${ruleLine(r)}<div class="small faint">${h(r.date || '')}${r.source ? ' · ' + h(r.source) : ''}</div></div>
        <button class="icon-btn" data-edit title="Edit">✏️</button><button class="icon-btn" data-del title="Delete">🗑</button></div>`).join('')}</div>`;
    }).join('');
    const inbox = st.inbox.length ? st.inbox.map(it => `<div class="inbox-item" data-inbox="${h(it.id)}">
        <div class="small muted">${h(it.source)} · ${h(fmtStamp(it.date))}${it.quote ? ` · you said: “${h(it.quote)}”` : ''}</div>
        ${it.proposal ? proposalHtml([it.proposal]) : ''}
        <div class="row"><button class="btn sm primary" data-accept>✔ Approve</button><button class="btn sm ghost" data-dismiss>Dismiss</button></div></div>`).join('')
      : '<p class="small faint">Empty. Answers to the tutor’s “💬 Teaching check-in” questions show up here as suggested rules.</p>';
    view.innerHTML = `<div class="page-head"><div><div class="eyebrow">Your coach</div><h1>🎛️ Command</h1>
        <div class="sub">Tell Command how you like to learn. It turns that into rules Dr. Claude follows on every reply. Nothing changes until you confirm.</div></div>
        <button class="btn" data-open="${h(st.file)}">Open rules file</button></div>
      <div class="grid g-command">
        <div class="card cmd-chat"><h2>💬 Talk to Command</h2>
          <div class="cmd-msgs" id="cmdMsgs"></div>
          <div id="cmdPending"></div>
          <form id="cmdForm" class="row" autocomplete="off"><input id="cmdIn" style="flex:1" placeholder="e.g. “Stop giving me acronyms, use real-life examples”">
            <button class="btn primary" id="cmdSend">Send</button></form>
          <div class="qchips" style="margin-top:8px">${['Explanations are too long', 'Quiz me harder', 'Show the professor’s exact question first', 'I learn by drawing']
            .map(x => `<button class="qchip" data-say="${h(x)}">${h(x)}</button>`).join('')}</div></div>
        <div>
          <div class="card"><h2>📥 Suggestions <span class="count">${st.inbox.length}</span></h2>${inbox}</div>
          <div class="card" style="margin-top:16px"><h2>📜 Teaching Rules <span class="count">${st.rules.filter(r => r.on !== false).length} on</span></h2>
            ${groups || '<p class="faint">No rules yet. Finish setup or tell Command what you like.</p>'}
            <button class="btn sm" id="ruleAdd" style="margin-top:8px">＋ Write a rule myself</button></div>
          ${st.feedback.length ? `<details class="card" style="margin-top:16px"><summary><b>🗒 Feedback log</b></summary>${st.feedback.map(f => `<div class="small"><span class="faint">${h(fmtStamp(f.date))} · ${h(f.source)}</span> ${h(f.text)}</div>`).join('')}</details>` : ''}
        </div></div>`;

    const msgs = $('#cmdMsgs');
    const drawChat = () => {
      msgs.innerHTML = CMD.chat.length ? CMD.chat.map(m => `<div class="msg ${m.role === 'user' ? 'user' : 'assistant'}"><div class="bubble md">${m.role === 'user' ? h(m.text) : md(m.text)}</div></div>`).join('')
        : '<p class="small faint">Say what’s working and what isn’t. Command suggests a rule; you see it before/after and confirm.</p>';
      msgs.scrollTop = msgs.scrollHeight;
    };
    const showPending = (list, opts = {}) => {
      const box = $('#cmdPending');
      CMD.pending = list && list.length ? { list, ...opts } : null;
      if (!CMD.pending) { box.innerHTML = ''; return; }
      box.innerHTML = `<div class="pending"><b>${opts.pick ? 'Pick the changes to keep' : 'Confirm this change?'}</b>${proposalHtml(list, opts.pick)}
        <div class="row"><button class="btn primary" id="pcOk">${opts.pick ? 'Keep selected' : 'Confirm'}</button><button class="btn ghost" id="pcNo">Not now</button></div></div>`;
      $('#pcOk').addEventListener('click', async () => {
        const keep = opts.pick ? list.filter((_, i) => $(`[data-pick="${i}"]`).checked) : list;
        const r = await api('/api/command/apply', { changes: keep.map(p => p.change), source: opts.source || 'command' });
        toast(`Saved ${r.applied} change${r.applied === 1 ? '' : 's'}. Dr. Claude uses ${r.applied === 1 ? 'it' : 'them'} from the next reply.`, 4000);
        CMD.pending = null; route();
      });
      $('#pcNo').addEventListener('click', () => { CMD.chat.push({ role: 'assistant', text: 'OK, nothing changed.' }); showPending(null); drawChat(); });
    };
    drawChat();
    if (CMD.pending) showPending(CMD.pending.list, CMD.pending);

    const ask = async text => {
      CMD.chat.push({ role: 'user', text });
      drawChat();
      $('#cmdSend').disabled = true;
      msgs.insertAdjacentHTML('beforeend', '<div class="msg assistant" id="cmdWait"><div class="thinking"><span class="dots"><i></i><i></i><i></i></span><span>Thinking…</span></div></div>');
      try {
        const r = await api('/api/command/send', { text, history: CMD.chat.slice(0, -1).slice(-8) });
        CMD.chat.push({ role: 'assistant', text: r.reply });
        drawChat(); showPending(r.proposals);
      } catch (e) { CMD.chat.push({ role: 'assistant', text: '⚠️ ' + e.message }); drawChat(); }
      const b = $('#cmdSend'); if (b) b.disabled = false;
    };
    $('#cmdForm').addEventListener('submit', e => { e.preventDefault(); const v = $('#cmdIn').value.trim(); if (v) { $('#cmdIn').value = ''; ask(v); } });
    view.addEventListener('click', e => { const b = e.target.closest('[data-say]'); if (b) ask(b.dataset.say); });

    // rule list: toggle / edit / delete all go through the same before/after confirm
    const ruleOf = el => st.rules.find(r => r.id === el.closest('[data-rule]').dataset.rule);
    const proposeLocal = async (changes, source) => {
      const r = await api('/api/command/propose', { changes });
      showPending(r.proposals, { source });
      $('#cmdPending').scrollIntoView({ behavior: 'smooth', block: 'center' });
    };
    view.addEventListener('change', e => {
      if (!e.target.matches('[data-toggle]')) return;
      const r = ruleOf(e.target);
      e.target.checked = r.on !== false;  // stays as-is until confirmed
      proposeLocal([{ op: 'toggle', id: r.id, on: r.on === false }], 'edited by hand');
    });
    view.addEventListener('click', e => {
      if (e.target.closest('[data-del]')) proposeLocal([{ op: 'delete', id: ruleOf(e.target).id }], 'edited by hand');
      const ed = e.target.closest('[data-edit]');
      if (ed) {
        const r = ruleOf(ed), body = ed.closest('[data-rule]').querySelector('.rule-body');
        body.innerHTML = `<textarea class="rule-edit" rows="2">${h(r.text)}</textarea>
          <div class="row"><select class="rule-grp">${st.groups.map(g => `<option${g === r.group ? ' selected' : ''}>${h(g)}</option>`).join('')}</select>
          <button class="btn sm primary" data-save>Review change</button></div>`;
        $('[data-save]', body).addEventListener('click', () => proposeLocal([{ op: 'edit', id: r.id, text: $('.rule-edit', body).value.trim(), group: $('.rule-grp', body).value }], 'edited by hand'));
      }
      const ib = e.target.closest('[data-inbox]');
      if (ib && (e.target.closest('[data-accept]') || e.target.closest('[data-dismiss]'))) {
        api('/api/command/inbox', { id: ib.dataset.inbox, accept: !!e.target.closest('[data-accept]') })
          .then(r => { toast(r.applied ? 'Rule saved.' : 'Dismissed.'); route(); }).catch(err => toast(err.message, 4000));
      }
    });
    $('#ruleAdd').addEventListener('click', () => {
      $('#cmdPending').innerHTML = `<div class="pending"><b>New rule</b><textarea class="rule-edit" id="nrText" rows="2" placeholder="e.g. Keep explanations under 6 lines, then ask if I want more."></textarea>
        <div class="row"><select id="nrGrp">${st.groups.map(g => `<option>${h(g)}</option>`).join('')}</select><input id="nrCourse" placeholder="Class (Per-class only)" style="width:170px">
        <button class="btn primary" id="nrGo">Review</button></div></div>`;
      $('#nrGo').addEventListener('click', () => proposeLocal([{ op: 'add', text: $('#nrText').value.trim(), group: $('#nrGrp').value, course: $('#nrCourse').value.trim(), why: 'written by hand' }], 'written by hand'));
    });

    // Retro: #/command?retro=<session id>
    const rsid = q.get('retro');
    if (rsid) {
      history.replaceState(null, '', '#/command');
      CMD.chat.push({ role: 'user', text: 'Retro on my last study session, please.' });
      drawChat();
      msgs.insertAdjacentHTML('beforeend', '<div class="msg assistant"><div class="thinking"><span class="dots"><i></i><i></i><i></i></span><span>Reading the session…</span></div></div>');
      try {
        const r = await api('/api/command/retro', { sid: rsid });
        if (stale(tok)) return;
        CMD.chat.push({ role: 'assistant', text: r.reply });
        drawChat(); showPending(r.proposals, { pick: true, source: 'retro' });
      } catch (e) { CMD.chat.push({ role: 'assistant', text: '⚠️ ' + e.message }); drawChat(); }
    }
  }

  // ------------------------------------------------------------------ SETTINGS
  async function renderSettings(tok) {
    const r = await api('/api/state');
    if (stale(tok)) return;
    APP.state = r;
    const s = r.settings, p = r.profile;
    view.innerHTML = `<div class="page-head"><div><div class="eyebrow">Dr. Claude</div><h1>Settings</h1>
        <div class="sub">Everything stays on this laptop, in <code>${h(r.docs_root)}</code>.</div></div>
        <a class="btn" href="#/welcome">Run setup again</a></div>
      <div class="set-grid">
        <div class="card"><h2>🙋 You</h2>
          <form class="form" id="meForm" autocomplete="off">
            <div class="row"><div class="field" style="flex:1"><label>Name</label><input name="name" value="${h(p.name)}"></div>
            <div class="field" style="flex:1"><label>School</label><input name="school" value="${h(p.school)}"></div>
            <div class="field" style="flex:1"><label>Major</label><input name="major" value="${h(p.major)}"></div></div>
            <div class="field"><label>How I like to learn</label>${prefsHtml(p)}
              <div class="help">These are your first Teaching Rules. Fine-tune them in words on the <a href="#/command">Command</a> page.</div></div>
            <div class="field"><label>Anything else Dr. Claude should know (optional)</label><textarea name="notes" rows="3">${h(p.notes)}</textarea></div>
            <button class="btn primary">Save</button></form></div>
        <div class="card"><h2>🧠 AI brain</h2><div id="brainBox"></div></div>
        <div class="card"><h2>🎓 Canvas</h2><div id="canvasBox"></div></div>
        <div class="card"><h2>🎨 App</h2>
          <div class="field"><label>Theme</label>${seg('theme', [['system', 'Match Windows'], ['light', 'Light'], ['dark', 'Dark']], s.theme)}</div>
          <div class="field"><label>Study timer</label>${seg('logpose', [['true', 'On'], ['false', 'Off']], s.logpose)}
            <div class="help">Study modes time themselves; the home screen shows today, this week, and your streak.</div></div>
          <p class="small muted" id="tmStatus"></p>
          <div class="row"><button class="btn sm" id="tmEnd">⏹ End study session now</button></div>
          <div class="field" style="margin-top:12px"><label for="f_edge">Microsoft Edge</label><input id="f_edge" value="${h(s.edge)}" spellcheck="false">
            <div class="help">Used to open the app window. <button class="btn sm ghost" id="edgeSave">Save</button></div></div>
          <p class="small faint">Chats are saved in the app’s data folder. Close the window and the app shuts down by itself.</p></div>
        <div class="card"><h2>🎤 Voice upgrade (Whisper)</h2><div id="voiceBox"><p class="muted small">Loading…</p></div></div>
        <div class="card"><h2>🔄 Updates</h2>
          <p>You have <b>Dr. Claude v${h(r.version || '')}</b>.</p>
          <div class="field"><label>Install updates automatically</label>${seg('auto_update', [['true', 'On'], ['false', 'Off']], s.auto_update)}
            <div class="help">On: new versions download in the background and install the next time you open Dr. Claude. Your notes, rules, chats and keys are never touched.</div></div>
          <div class="row"><button class="btn sm" id="updCheck">Check for updates</button><span class="small" id="updMsg"></span></div></div>
      </div>`;
    $('#meForm').addEventListener('submit', async e => {
      e.preventDefault();
      const f = e.target;
      try {
        const res = await api('/api/profile', { name: f.name.value, school: f.school.value, major: f.major.value, notes: f.notes.value, prefs: readPrefs(f) });
        APP.state.profile = res.profile; toast('Saved.');
      } catch (err) { toast(err.message, 4000); }
    });
    brainPanel($('#brainBox'), tok);
    canvasPanel($('#canvasBox'), tok);
    voicePanel($('#voiceBox'), tok);
    $$('[data-seg="theme"],[data-seg="logpose"],[data-seg="auto_update"]').forEach(g => wireSeg(g, async v => {
      const k = g.dataset.seg;
      if (k === 'theme') applyTheme(v);
      const res = await api('/api/settings', { [k]: k === 'theme' ? v : v === 'true' });
      APP.state.settings = res.settings;
    }));
    $('#edgeSave').addEventListener('click', async () => { const res = await api('/api/settings', { edge: $('#f_edge').value.trim() }); APP.state.settings = res.settings; toast('Saved.'); });
    const tm = async () => { try { const x = await api('/api/logpose/status'); if (!stale(tok)) $('#tmStatus').textContent = x.text; } catch (e) { /* ignore */ } };
    $('#tmEnd').addEventListener('click', async () => { const x = await api('/api/logpose', { action: 'end' }); toast(x.text, 4000); APP.timerActive = {}; tm(); });
    tm();
    $('#updCheck').addEventListener('click', async () => {
      const m = $('#updMsg');
      m.textContent = 'Checking…';
      try {
        const u = await api('/api/update/check', {});
        m.textContent = !u.installed ? 'Updates work in the installed app only.' : u.error ? '⚠️ ' + u.error
          : !u.configured ? 'No update link is set up in this copy.' : u.available ? `v${u.available} is ready.` : 'You’re up to date.';
        updateBanner(u);
      } catch (e) { m.textContent = '⚠️ ' + e.message; }
    });
  }

  // 🎤 Voice upgrade (optional): Whisper hears each phrase again with your class's words, and the confidence
  // reader (on by default since v1.4.4) tells the tutor which answers sounded sure vs unsure compared to YOUR normal voice.
  async function voicePanel(box, tok) {
    let v;
    try { v = await api('/api/voice/info', {}); } catch (e) { box.innerHTML = `<p class="small">⚠️ ${h(e.message)}</p>`; return; }
    if (stale(tok) || !document.body.contains(box)) return;
    const st = v.state || {}, on = !!v.settings.voice_model, working = st.state === 'working';
    const models = v.models || [];
    const pick = models.length > 1
      ? `<div class="field"><label>Model</label><select id="vModel">${models.map(m => `<option value="${h(m.name)}">${h(m.label)}: ${h(m.size)}</option>`).join('')}</select>
           <div class="help">Found your graphics card (${h(v.gpu)}), so the faster, more accurate model is an option.</div></div>`
      : `<p class="small muted">One-time download: ${h((models[0] || {}).size || 'about 750 MB')}. Takes a few minutes.</p>`;
    const prof = v.profile || {};
    box.innerHTML = `
      <p>Voice typing works already. This upgrade makes it <b>much more accurate</b> with your class's words (it runs on this laptop, offline after setup).</p>
      ${on ? `<p class="small">✅ On: <b>${h(v.settings.voice_model)}</b></p>` : working ? '' : pick}
      ${working || st.state === 'error' || (st.state === 'done' && !on) ? `<div class="vprog" style="height:8px;border-radius:4px;background:var(--line,#ddd);overflow:hidden;margin:8px 0">
          <div style="height:100%;width:${Math.max(2, st.pct || 0)}%;background:var(--accent,#f2c14e);transition:width .5s"></div></div>
          <p class="small" id="vStep">${h(st.step || '')}${st.state === 'error' ? `<br><span class="faint">${h(st.error || '')}</span>` : ''}</p>` : ''}
      <div class="row">${on ? '<button class="btn sm ghost" id="vRemove">Remove voice upgrade</button>'
        : `<button class="btn sm primary" id="vOn" ${working ? 'disabled' : ''}>${working ? 'Setting up…' : st.state === 'error' ? 'Try again' : 'Turn on'}</button>`}</div>
      <hr style="margin:14px 0;border:0;border-top:1px solid var(--line,#ddd)">
      <div class="field"><label>Confidence reader ${on ? '' : '<span class="faint">(needs the voice upgrade)</span>'}</label>
        ${seg('voice_conf', [['true', 'On'], ['false', 'Off']], !!v.settings.voice_conf)}
        <div class="help">When you answer <b>out loud</b>, Dr. Claude notices <i>how</i> you said it (how long before you started, pauses, “um”s, “I think…”, a rising voice at the end) and compares it only to <b>your own</b> usual voice, never to anyone else. That tells it which answers you were sure of and which were guesses, so the shaky ones come back for review sooner. It never comments on how you talk.
        <br><b>Privacy:</b> the sound of your voice is never saved. Only a few numbers per answer stay on this laptop.
        ${prof.answers ? `<br>Learned so far: ${prof.answers} answer${prof.answers === 1 ? '' : 's'}${prof.baseline_ready ? '' : ` (needs ${prof.baseline_n} to know your normal)`}.` : ''}</div>
        <button class="btn sm ghost" id="vForget">Forget my voice profile</button></div>`;
    const go = $('#vOn', box);
    if (go) go.addEventListener('click', async () => {
      const m = $('#vModel', box);
      try { await api('/api/voice/setup', { model: m ? m.value : '' }); } catch (e) { toast(e.message, 4000); }
      voicePanel(box, tok);
    });
    const rm = $('#vRemove', box);
    if (rm) rm.addEventListener('click', async () => {
      if (!confirm('Remove the voice upgrade? (Frees the disk space. Plain voice typing keeps working.)')) return;
      const r = await api('/api/voice/remove', {}); toast(r.note || 'Removed.', 4000); WH.ok = null; voicePanel(box, tok);
    });
    $('#vForget', box).addEventListener('click', async () => {
      await api('/api/voice/forget', {}); toast('Forgot your voice profile. It starts learning your normal again.', 4000); voicePanel(box, tok);
    });
    const g = box.querySelector('[data-seg="voice_conf"]');
    if (g) wireSeg(g, async val => {
      if (val === 'true' && !on) { toast('Turn on the voice upgrade first.', 3500); voicePanel(box, tok); return; }
      await api('/api/voice/conf', { on: val === 'true' }); WH.ok = null;
    });
    if (working) setTimeout(() => { if (!stale(tok) && document.body.contains(box)) voicePanel(box, tok); }, 1500);
    else if (st.state === 'done') WH.ok = null;
  }

  // ------------------------------------------------------------------ FIRST-RUN SETUP
  const WZ = { step: 0 };
  async function renderWelcome(tok) {
    await refreshState();
    if (stale(tok)) return;
    const p = APP.state.profile;
    const steps = ['You', 'How you learn', 'AI brain', 'Canvas', 'Done'];
    const nav = (back, next, nextLabel = 'Next →') => `<div class="row wz-nav">${back ? '<button class="btn ghost" id="wzBack">← Back</button>' : ''}<span class="spacer"></span>
      ${next ? `<button class="btn primary" id="wzNext">${nextLabel}</button>` : ''}</div>`;
    const go = n => { WZ.step = n; renderWelcome(tok); };
    let body = '';
    if (WZ.step === 0) body = `<h1>Welcome to Dr. Claude 🎓</h1>
        <p class="muted">Your own study professor. It reads your classes from Canvas and teaches, quizzes, and tests you at your class’s pace, in your professor’s style.</p>
        <div class="field"><label>Your first name</label><input id="wzName" value="${h(p.name)}" placeholder="e.g. Jancy"></div>
        <div class="row"><div class="field" style="flex:1"><label>School</label><input id="wzSchool" value="${h(p.school)}"></div>
        <div class="field" style="flex:1"><label>Major</label><input id="wzMajor" value="${h(p.major)}" placeholder="e.g. Aerospace Engineering"></div></div>
        ${nav(false, true)}`;
    else if (WZ.step === 1) body = `<h1>How do you like to learn?</h1>
        <p class="muted">These start as on. Turn off anything you don’t want. Later, just tell the <b>Command</b> page in your own words (“explanations are too long”) and it updates the rules.</p>
        <div id="wzPrefs">${prefsHtml(p)}</div>${nav(true, true)}`;
    else if (WZ.step === 2) body = `<h1>Pick the AI brain</h1>
        <p class="muted">Dr. Claude needs an AI to do the teaching. Have Claude? Pick it, it’s the best teacher. No Claude? Your school ChatGPT account is free. Gemini is the free backup.</p>
        <div id="wzBrain"></div>${nav(true, true)}`;
    else if (WZ.step === 3) body = `<h1>Connect Canvas</h1>
        <p class="muted">Dr. Claude downloads your classes’ files, syllabus, assignments, and modules, and keeps them up to date.</p>
        <div id="wzCanvas"></div>
        <details class="small" style="margin-top:12px"><summary>Can’t or don’t want to use a token?</summary>
          <p>Use <b>Sync through your browser</b> above: no token needed. Or skip this, add each class by hand on the Courses page, and drag your own files into it in the Library.</p></details>
        ${nav(true, true, 'Next →')}`;
    else body = `<h1>You’re all set${p.name ? ', ' + h(p.name.split(' ')[0]) : ''}! 🎉</h1>
        <ul class="done-list"><li><b>Home</b> shows what’s due and a plan for today.</li>
          <li><b>Classroom</b>: pick a class and a mode (Lecture, Quiz, Mock Exam…).</li>
          <li><b>Command</b>: tell it how you like to learn; it turns that into rules.</li>
          <li><b>🧰 Tools</b>: calculator, quick questions, and your thoughts.</li></ul>
        ${nav(true, true, 'Start studying →')}`;
    view.innerHTML = `<div class="wizard"><div class="wz-steps">${steps.map((x, i) => `<span class="${i === WZ.step ? 'on' : i < WZ.step ? 'done' : ''}">${i < WZ.step ? '✓' : i + 1} ${h(x)}</span>`).join('')}</div>
      <div class="card wz-card">${body}</div>
      <div class="card wz-help" id="wzHelp"></div></div>`;
    setupHelper($('#wzHelp'));
    const back = $('#wzBack'); if (back) back.addEventListener('click', () => go(WZ.step - 1));
    const next = $('#wzNext');
    if (WZ.step === 2) brainPanel($('#wzBrain'), tok);
    if (WZ.step === 3) canvasPanel($('#wzCanvas'), tok);
    next.addEventListener('click', async () => {
      try {
        if (WZ.step === 0) {
          if (!$('#wzName').value.trim()) { toast('Type your name first.'); return; }
          await api('/api/profile', { name: $('#wzName').value, school: $('#wzSchool').value, major: $('#wzMajor').value });
        } else if (WZ.step === 1) {
          await api('/api/profile', { prefs: readPrefs($('#wzPrefs')) });
        } else if (WZ.step === 4) {
          await api('/api/profile', { onboarded: true, prefs: APP.state.profile.prefs });
          await refreshState();
          WZ.step = 0;
          location.hash = '#/home';
          return;
        }
        go(WZ.step + 1);
      } catch (e) { toast(e.message, 4000); }
    });
  }

  // 🙋 Setup helper (v1.4.5): a click-through question tree under every setup screen. Is this your question? -> open it ->
  // here's what to do -> still stuck? -> pick the next question. No typing and no AI, so it always works (even offline).
  // Node = [question, answer, [follow-up nodes]]. Groups: the current screen's group opens first, the rest stay folded.
  // Mac: same app, Mac words (keyboard keys, Terminal, Keychain, Applications)
  const IS_MAC = /Mac/i.test(navigator.platform || navigator.userAgent || '');
  const macify = s => !IS_MAC ? s : s.replace(/Ctrl\+Shift\+B/g, 'Cmd+Shift+B').replace(/black window/g, 'Terminal window')
    .replace(/encrypted with your Windows account/g, 'in your Mac’s Keychain').replace(/encrypted on this laptop only/g, 'in your Mac’s Keychain')
    .replace(/on your Desktop or in the Start menu/g, 'in your Applications folder or on your Desktop').replace(/In Chrome, press/g, 'In Chrome, press');
  const Q = (q, a, more) => [q, a, more || []];
  const STILL_STUCK = Q('Still stuck?', 'Click **Next** to keep going. You can finish any step later in **Settings**, and nothing you did is lost. Or message the person who sent you Dr. Claude and tell them which screen you’re on and what it says.');
  const SETUP_TREE = [
    { steps: [0], title: '👤 Your name, school & major', items: [
      Q('Do I have to fill in school and major?', 'Only your **first name** is needed. School and major are optional, but they help Dr. Claude pick the right words and examples for your classes. Then click **Next →**.', [
        Q('My school isn’t Cal Poly Pomona.', 'No problem. Just type your school’s name. Dr. Claude works with any school. (On the Canvas screen you’ll also type your school’s Canvas web address.)')]),
      Q('What is Dr. Claude, exactly?', 'A study professor that lives on your laptop. It reads your classes from Canvas, then teaches, quizzes, and tests you at your class’s pace, in your professor’s style. Setup is 4 short screens: **You**, **How you learn**, **AI brain**, and **Canvas**.', [
        Q('Does it cost anything?', 'No. Dr. Claude is free. The AI part is free too, with a school ChatGPT account or a free Google Gemini key. You never enter a credit card.')]),
    ] },
    { steps: [1], title: '🧠 How you learn', items: [
      Q('What do these switches mean?', 'Each one is a teaching style, and they all start **on**. Read the short line under each and turn off anything you don’t want. Not sure? Leave them all on and click **Next →**.', [
        Q('Can I change them later?', 'Yes, any time. The easiest way: open the **Command** page and say it in your own words, like “explanations are too long” or “quiz me more.” Dr. Claude turns that into new rules for you.')]),
    ] },
    { steps: [2], title: '🤖 Picking the AI brain', items: [
      Q('Which AI should I pick?', 'Dr. Claude needs an AI to do the teaching. Pick the first one you have: **Claude** (best), then **school ChatGPT**, then **Google Gemini** (free for anyone).', [
        Q('I have Claude (Pro or Max).', 'Pick **Claude**. Then:\n1. Click **Install Claude** (Anthropic’s official installer). A black window opens. Wait until it says **Done**, then close it.\n2. Click **Sign in to Claude**. A browser page opens. Sign in with the same account you use on claude.ai and click **Authorize**.\n3. Come back here and click **Check again**. You should see ✅.', [
          Q('The installer window closed or showed an error.', 'Click **Install Claude** again and wait. It can take a few minutes on slow Wi-Fi. If it fails twice, pick **Google Gemini** for now (free) and switch to Claude later in **Settings**.'),
          Q('I signed in but it still shows ⚠️.', 'Click **Check again** once more. If it still shows ⚠️, click **Sign in to Claude** again and make sure you finish on the browser page (click **Authorize**).'),
          Q('I only have free Claude.', 'Dr. Claude needs a paid Claude plan (Pro or Max) to run through Claude’s app. On the free plan, pick **school ChatGPT** or **Google Gemini** instead.'),
          Q('Does this use someone else’s account?', 'No. It signs in with **your own** Claude account and uses your plan’s normal limits.'),
          STILL_STUCK]),
        Q('Yes, I have school ChatGPT.', 'Pick **ChatGPT**. It’s the best teacher. Then:\n1. Click **Install Codex** (OpenAI’s free helper that connects your account). A black window opens. Wait until it says **Done**, then close it.\n2. Click **Sign in with your school ChatGPT**. A browser page opens. Choose **Sign in with ChatGPT** and use your **school email**.\n3. Come back here and click **Check again**. You should see ✅.', [
          Q('The black Codex window closed or showed an error.', 'Click **Install Codex** again and wait. It can take a few minutes on slow Wi-Fi. If it fails twice, pick **Google Gemini** instead. It works just as well for setup, and you can switch later in **Settings**.'),
          Q('The sign-in page never came back.', 'Click **Use a code instead**. A window shows a link and a short code. Open the link, sign in with your school email, and type the code. Then click **Check again**.'),
          Q('I signed in but it still shows ⚠️.', 'Click **Check again** once more. If it still shows ⚠️, click **Sign in with your school ChatGPT** again and make sure you use your **school** email, not a personal one.'),
          STILL_STUCK]),
        Q('No, I don’t have school ChatGPT.', 'Pick **Google Gemini**. It’s free with any Google (Gmail) account:\n1. Click the **aistudio.google.com/apikey** link on this screen and sign in with Google.\n2. Click **Create API key** and copy it.\n3. Paste it in the box here and click **Save & test**. You should see ✅.', [
          Q('What is an “API key”?', 'A long password-like code that lets Dr. Claude talk to Gemini for you. It’s saved **encrypted on this laptop only**. Don’t share it with anyone.'),
          Q('“Save & test” says the key doesn’t work.', 'Go back to the Google page, click **Create API key** to make a brand-new one, and copy all of it. Paste it with no spaces before or after, then click **Save & test** again.'),
          Q('Is my stuff private with Gemini?', 'On Google’s free tier, Google may use what you send to improve its products, and people may review it. So don’t paste anything private (passwords, ID numbers, health info) into your chats.'),
          STILL_STUCK]),
        Q('I’m not sure if my school has ChatGPT.', 'Try the **ChatGPT** option first: click **Sign in with your school ChatGPT** and use your school email. If your school’s page doesn’t let you in, use **Google Gemini** instead. You can switch any time in **Settings**.')]),
      Q('Can I switch AIs later?', 'Yes. Open **Settings** any time and pick the other one.'),
    ] },
    { steps: [3], title: '🎓 Connecting Canvas', items: [
      Q('How do I connect Canvas?', 'You make a “token” in Canvas (a read-only pass) and paste it here:\n1. Check the left box shows **your school’s Canvas address** (change it if your school isn’t Cal Poly Pomona).\n2. Click the **Canvas → Account → Settings** link on this screen.\n3. Scroll to **Approved Integrations** and click **+ New Access Token**.\n4. Type *Dr. Claude*, leave the date empty, and click **Generate Token**.\n5. Copy the long token (you only see it once), paste it here, and click **Test & connect**.', [
        Q('I don’t see “+ New Access Token”.', 'Some schools hide it. Use **Sync through your browser** on this screen instead (no token needed):\n1. In Chrome, press **Ctrl+Shift+B** to show the bookmarks bar.\n2. Drag the **🎓 Sync Dr. Claude** button onto that bar.\n3. Open Canvas and log in like normal.\n4. Click **🎓 Sync Dr. Claude** on the bar. Keep the small window open until it says **Done**.', [
          Q('Chrome blocked a pop-up.', 'Click **Always allow** on Chrome’s pop-up message, then click the **🎓 Sync Dr. Claude** bookmark again.'),
          Q('I can’t drag the button.', 'Click **copy it** under the button. Then right-click the bookmarks bar → **Add page**, name it *Sync Dr. Claude*, paste into the URL box, and save.'),
          STILL_STUCK]),
        Q('“Test & connect” shows ⚠️.', 'Usually it’s one of these:\n- The left box isn’t your school’s Canvas address. Fix it and try again.\n- Part of the token got cut off. Make a new token and copy **all** of it.\n- Your school blocks tokens. Use **Sync through your browser** instead.'),
        Q('Is giving Dr. Claude a token safe?', 'It only **reads** your own classes. It’s saved encrypted on this laptop, and you can delete it in Canvas any time (same **Approved Integrations** list).')]),
      Q('I don’t use Canvas.', 'Skip it: click **Next →**. Later, add each class by hand on the **Courses** page and drag your own files into it in the **Library**.'),
    ] },
    { steps: [4], title: '🎉 After setup', items: [
      Q('How do I open Dr. Claude again later?', 'Use the **Dr. Claude** icon on your Desktop or in the Start menu.'),
      Q('How do I talk to it out loud?', 'In the **Classroom**, hold the **Space** bar, talk, and let go. Your words appear in the box. Check them, then press **Enter**.'),
      Q('Does it update itself?', 'Yes. When a new version is out, it downloads quietly and installs the next time you open Dr. Claude.'),
    ] },
    { steps: [], title: '🔒 Safety, speed & skipping', items: [
      Q('Is this safe? Where does my stuff go?', 'Your chats, notes, and files stay **on this laptop**. Keys and tokens are saved encrypted with your Windows account. Dr. Claude only talks to the AI you picked and to your Canvas, and it never sees your passwords: you sign in on the real ChatGPT, Google, or Canvas pages.'),
      Q('Why is my laptop busy or loud right now?', 'The first time you open Dr. Claude, it downloads its **voice tools** in the background (about 750 MB, one time, a few minutes). That’s normal and stops on its own.', [
        Q('Can I turn voice off?', 'Yes: **Settings → 🎤 Voice upgrade**. Your voice is never saved either way.')]),
      Q('Can I skip a step?', 'Yes. Click **Next →** and finish it later in **Settings**. Nothing is lost.'),
      STILL_STUCK,
    ] },
  ];
  const WZH = { open: true };
  function setupHelper(box) {
    if (!box) return;
    const node = (n, depth) => `<details class="wzh-q d${depth}"><summary>${h(n[0])}</summary><div class="wzh-a"><div class="md">${md(macify(n[1]))}</div>
        ${n[2].length ? `<div class="wzh-more-label">${depth === 0 ? 'Still stuck? Is it one of these?' : 'Still stuck?'}</div><div class="wzh-kids">${n[2].map(k => node(k, depth + 1)).join('')}</div>` : ''}</div></details>`;
    const group = (g, open) => `<details class="wzh-group"${open ? ' open' : ''}><summary>${h(g.title)}</summary><div class="wzh-kids">${g.items.map(n => node(n, 0)).join('')}</div></details>`;
    const draw = () => {
      const mine = SETUP_TREE.filter(g => g.steps.includes(WZ.step));
      const general = SETUP_TREE.filter(g => !g.steps.length);
      const other = SETUP_TREE.filter(g => g.steps.length && !g.steps.includes(WZ.step));
      box.innerHTML = `<div class="row wzh-head"><b>🙋 Questions about this step?</b><span class="small muted">Click your question to see what to do.</span>
          <span class="spacer"></span><button type="button" class="btn ghost sm" id="wzhToggle">${WZH.open ? 'Hide' : 'Show'}</button></div>
        ${WZH.open ? `<div class="wzh-list">${mine.map(g => group(g, true)).join('')}${general.map(g => group(g, false)).join('')}
          <details class="wzh-group wzh-other"><summary>📚 Questions about the other setup screens</summary><div class="wzh-kids">${other.map(g => group(g, false)).join('')}</div></details></div>` : ''}`;
      $('#wzhToggle', box).addEventListener('click', () => { WZH.open = !WZH.open; draw(); });
    };
    draw();
  }

  // ------------------------------------------------------------------ updates (banner + restart)
  const UPD = { later: '' };
  async function updateBanner(st) {
    const el = $('#updBanner');
    if (!el) return;
    try { st = st || await api('/api/update/status'); } catch (e) { return; }
    APP.update = st;
    let html = '';
    if (st.event && st.event.kind === 'ok') {
      html = `<b>🎉 Updated to v${h(st.event.to)}</b>${st.event.notes ? `<div class="upd-notes md">${md(st.event.notes)}</div>` : ''}
        <div class="row"><button class="btn sm primary" data-upd="seen">Got it</button></div>`;
    } else if (st.event && st.event.kind === 'rolled_back') {
      html = `<b>⚠️ The update to v${h(st.event.to)} didn't start, so Dr. Claude went back to v${h(st.event.from)}.</b>
        <div class="small muted">Nothing of yours was changed. It won't try that version again by itself.</div>
        <div class="row"><button class="btn sm" data-upd="seen">OK</button></div>`;
    } else if (st.available && UPD.later !== st.available) {
      html = st.too_old ? `<b>A new Dr. Claude (v${h(st.available)}) is out.</b><div class="small muted">This copy is too old to update itself; please reinstall it.</div>
          <div class="row"><button class="btn sm ghost" data-upd="later">OK</button></div>`
        : `<b>Update ready: v${h(st.available)}</b>${st.notes ? `<div class="upd-notes md">${md(st.notes)}</div>` : ''}
          ${st.staged && st.auto ? '<div class="small muted">It installs by itself the next time you open Dr. Claude.</div>' : ''}
          <div class="row"><button class="btn sm primary" data-upd="install">Update now</button><button class="btn sm ghost" data-upd="later">Later</button></div>`;
    }
    el.innerHTML = html;
    el.hidden = !html;
  }
  async function installUpdate() {
    const el = $('#updBanner');
    el.innerHTML = '<b>Updating…</b><div class="small muted">Dr. Claude restarts in a few seconds. Don’t close this window.</div>';
    el.hidden = false;
    try {
      const r = await api('/api/update/install', {});
      if (!r.restarting) { toast(r.error || 'Update failed.', 6000); return updateBanner(r); }
    } catch (e) { toast(e.message, 5000); return; }
    const from = APP.update && APP.update.version;
    const t0 = Date.now();
    const poll = async () => {
      try {
        const p = await fetch('/api/ping').then(x => x.json());
        if (p.version && p.version !== from) { location.reload(); return; }
        if (p.version === from && Date.now() - t0 > 8000) { location.reload(); return; }  // rolled back
      } catch (e) { /* restarting */ }
      if (Date.now() - t0 < 120000) setTimeout(poll, 1000);
      else el.innerHTML = '<b>Update is taking long.</b><div class="small muted">Close this window and open Dr. Claude from the Desktop icon.</div>';
    };
    setTimeout(poll, 2500);
  }
  document.addEventListener('click', async e => {
    const b = e.target.closest('[data-upd]');
    if (!b) return;
    const k = b.dataset.upd;
    if (k === 'install') installUpdate();
    else if (k === 'later') { UPD.later = APP.update && APP.update.available; $('#updBanner').hidden = true; }
    else if (k === 'seen') { await api('/api/update/seen', {}).catch(() => {}); $('#updBanner').hidden = true; }
  });

  // ------------------------------------------------------------------ global bits
  // Copy buttons on code blocks (anywhere Markdown is rendered)
  document.addEventListener('click', e => {
    const b = e.target.closest('.codewrap .copy');
    if (!b) return;
    const code = b.parentElement.querySelector('pre code');
    navigator.clipboard.writeText(code ? code.textContent : '').then(() => {
      b.textContent = 'Copied'; setTimeout(() => { b.textContent = 'Copy'; }, 1200);
    }, () => toast("Couldn't copy."));
  });

  // Any [data-open] button opens that file/folder with its normal app
  document.addEventListener('click', e => { const b = e.target.closest('[data-open]'); if (b) openPath(b.dataset.open); });

  // Ctrl+M = mic (Classroom only)
  document.addEventListener('keydown', e => {
    if (e.ctrlKey && !e.shiftKey && !e.altKey && (e.key === 'm' || e.key === 'M') && $('#micBtn')) { e.preventDefault(); toggleMic(); }
  });

  // Hold Space = push-to-talk (Classroom only). A quick tap still types a space; holding it ~0.4 s turns the mic on
  // (and takes back the one space it typed), letting go turns it off. Other text boxes keep Space as normal.
  const PTT = { timer: null, on: false, typed: false };
  document.addEventListener('keydown', e => {
    if (e.code !== 'Space' || e.ctrlKey || e.altKey || e.metaKey || e.shiftKey || !$('#micBtn')) return;
    const el = document.activeElement, ta = $('#input');
    const inChat = el === ta, otherField = !inChat && el && (el.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName));
    const onButton = !inChat && el && /^(BUTTON|A)$/.test(el.tagName);
    if (otherField || (onButton && !e.repeat && !PTT.timer)) return; // Space still presses buttons on a tap
    if (e.repeat || PTT.timer || PTT.on) { e.preventDefault(); return; }
    PTT.typed = inChat;  // the first press types its space normally in the chat box
    if (!inChat) e.preventDefault();
    PTT.timer = setTimeout(() => {
      PTT.timer = null;
      if (PTT.typed && ta.selectionStart === ta.selectionEnd && ta.value[ta.selectionStart - 1] === ' ') {
        const at = ta.selectionStart;
        ta.value = ta.value.slice(0, at - 1) + ta.value.slice(at);
        ta.selectionStart = ta.selectionEnd = at - 1;
      }
      PTT.on = true;
      if (!recOn) startMic();
      const i = $('#interim'); if (i) i.textContent = '🎤 listening… let go of Space to stop';
    }, 400);
  });
  document.addEventListener('keyup', e => {
    if (e.code !== 'Space') return;
    if (PTT.timer) { clearTimeout(PTT.timer); PTT.timer = null; }
    if (!PTT.on) return;
    e.preventDefault();
    PTT.on = false;
    setTimeout(() => { stopMic(); const ta = $('#input'); if (ta) { ta.focus(); ta.selectionStart = ta.selectionEnd = ta.value.length; } }, 500); // let the last words land
  });
  window.addEventListener('blur', () => { if (PTT.timer) { clearTimeout(PTT.timer); PTT.timer = null; } if (PTT.on) { PTT.on = false; stopMic(); } });

  // Heartbeat: the server shuts itself down when the window has been closed for a while.
  const beat = () => fetch('/api/heartbeat', { method: 'POST' }).catch(() => {});
  setInterval(beat, 20000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) beat(); });
  window.addEventListener('pagehide', () => { try { navigator.sendBeacon('/api/bye'); } catch (e) { /* ignore */ } });

  async function boot() {
    beat();
    try {
      APP.state = await api('/api/state');
    } catch (e) {
      view.innerHTML = emptyBox('🔌', "Can't reach Dr. Claude's server", h(e.message), '<button class="btn" onclick="location.reload()">Try again</button>');
      return;
    }
    if (!APP.state.profile.onboarded) history.replaceState(null, '', '#/welcome');
    const urlTheme = new URLSearchParams(location.search).get('theme');
    applyTheme(urlTheme || APP.state.settings.theme || lsGet('drc-theme') || 'system');
    if (!location.hash) history.replaceState(null, '', '#/home');
    route();
    updateBanner();
    setTimeout(updateBanner, 15000);  // the first check runs a few seconds after start
    setInterval(updateBanner, 30 * 60 * 1000);
  }
  boot();
})();
