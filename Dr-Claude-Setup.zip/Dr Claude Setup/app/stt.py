"""Whisper speech-to-text for the Classroom mic (v1.4.2, 2026-11-11). OPTIONAL: nothing here runs until the student
turns on Settings → "🎤 Voice upgrade (Whisper)", which installs faster-whisper into <install>\\voice_libs and the
voice model into <install>\\voice_models (see voice_setup.py). Without it, plain Edge voice typing works as before.

Edge types live; when the student pauses, the app sends that phrase's audio here and Whisper re-hears it with a hint
list of their class's words (fixes sound-alikes like "D flip-flop" vs "the flip flop", "drag" vs "drag coefficient").
Default model: small.en on the CPU (int8). With an NVIDIA GPU the student may pick large-v3-turbo instead.
"""
import importlib
import io
import logging
import os
import sys
import threading
import time
import wave
from pathlib import Path

log = logging.getLogger("drclaude.stt")

APP_DIR = Path(__file__).resolve().parent
INSTALL = APP_DIR.parent if (APP_DIR.parent / "python").is_dir() else None
BASE = Path(os.environ.get("DRC_VOICE_HOME") or (INSTALL if INSTALL else APP_DIR / "data"))
LIBS = BASE / "voice_libs"
MODELS = BASE / "voice_models"

MODEL_INFO = {
    "small.en": {"label": "Standard (small.en, runs on any laptop)", "size": "about 750 MB (voice tools 280 MB + model 465 MB)", "gpu": False},
    "large-v3-turbo": {"label": "Best (large-v3-turbo, needs an NVIDIA graphics card)", "size": "about 2.9 GB (voice tools 280 MB + GPU files ~1 GB + model 1.6 GB)", "gpu": True},
}
DEFAULT_MODEL = "small.en"

_model = None
_model_name = ""
_req_name = ""   # what the caller asked for (may differ from _model_name after the CPU fallback)
_device = ""
_lock = threading.Lock()
_err = ""


def add_libs_path():
    """Put voice_libs on sys.path (embedded Python ignores site-packages outside its own folder)."""
    if LIBS.is_dir() and str(LIBS) not in sys.path:
        sys.path.insert(0, str(LIBS))
        importlib.invalidate_caches()
    base = LIBS / "nvidia"
    if base.is_dir():   # GPU option: cuBLAS / cuDNN wheels keep their DLLs in nvidia\*\bin
        for b in base.glob("*/bin"):
            try:
                os.add_dll_directory(str(b))
                os.environ["PATH"] = str(b) + os.pathsep + os.environ.get("PATH", "")
            except Exception:
                pass


add_libs_path()


def available():
    add_libs_path()
    try:
        import faster_whisper  # noqa: F401
        return True
    except Exception:
        return False


def model_dir(name):
    return MODELS / name


def model_ready(name):
    d = model_dir(name)
    return (d / "model.bin").is_file() and (d / "config.json").is_file()


def has_cuda_libs():
    return (LIBS / "nvidia").is_dir()


def load(name=None):
    """Load once (about 5-20 s). Downloads the model the first time if voice_setup didn't already."""
    global _model, _model_name, _req_name, _device, _err
    name = name or _req_name or _model_name or DEFAULT_MODEL
    req = name
    with _lock:
        if _model is not None and _req_name == req:
            return _model
        add_libs_path()
        from faster_whisper import WhisperModel
        src = str(model_dir(name)) if model_ready(name) else name
        tries = ([("cuda", "float16")] if has_cuda_libs() else []) + [("cpu", "int8")]
        for dev, ct in tries:
            try:
                if dev == "cpu" and name != "small.en" and model_ready("small.en"):
                    # 11/12: the big model on a CPU took 11-166 s per phrase; small.en ~3 s. Use it when the GPU is off.
                    name, src = "small.en", str(model_dir("small.en"))
                m = WhisperModel(src, device=dev, compute_type=ct, download_root=str(MODELS))
                import numpy as np
                list(m.transcribe(np.zeros(16000, dtype="float32"), language="en", beam_size=1)[0])  # proves it runs
                _model, _model_name, _req_name, _device = m, name, req, dev
                log.info("whisper %s ready on %s", name, dev)
                return m
            except Exception as e:
                _err = f"{dev}: {e}"
                log.warning("whisper %s on %s failed: %s", name, dev, e)
        raise RuntimeError("Whisper could not start: " + _err)


def warm_async(name=None):
    if available() and (model_ready(name or DEFAULT_MODEL)):
        threading.Thread(target=lambda: _safe_load(name), daemon=True).start()


def _safe_load(name):
    try:
        load(name)
    except Exception:
        log.exception("whisper load")


def unload():
    global _model, _model_name, _req_name
    with _lock:
        _model, _model_name, _req_name = None, "", ""


def status():
    return {"available": available(), "ready": _model is not None, "model": _model_name, "device": _device, "error": _err}


# Words that show up in classes. Whisper uses them as a "hint" so sound-alikes come out right.
STEM_TERMS = ("derivative, integral, vector, matrix, eigenvalue, free-body diagram, torque, momentum, "
              "KVL, KCL, Thevenin, op-amp, capacitor, inductor, impedance, ")
AERO_TERMS = ("angle of attack, airfoil, lift coefficient, drag coefficient, Bernoulli, Reynolds number, Mach number, "
              "stall, camber, chord, wingspan, aspect ratio, thrust, dynamic pressure, static pressure, "
              "boundary layer, NACA, XFLR5, pitot tube, ")


def terms_for(course_code="", course_title="", major="", topics=()):
    t = STEM_TERMS
    if "aero" in (major or "").lower() or str(course_code).upper().startswith(("ARO", "AERO", "AE")):
        t = AERO_TERMS + t
    if topics:
        t = ", ".join(x for x in topics if x)[:400] + ", " + t
    return t


def prompt_for(course_code="", course_title="", major="", topics=()):
    p = f"{course_code} {course_title}. ".strip() + " Terms: " + terms_for(course_code, course_title, major, topics)
    return p[:800]


HALLUCINATIONS = {"thank you.", "thanks for watching!", "thank you for watching.", "you", "bye.", "."}
MIN_SECONDS = 1.0   # 11/12: clips under ~1 s were mostly noise that Whisper turned into junk ("BOM, BOM, BOM...")


def looks_junk(text, course_code=""):
    """11/12: True if Whisper made something up instead of hearing words: foreign/odd characters, one word repeated
    over and over, or the course code echoed back from the hint prompt."""
    import re
    t = (text or "").strip()
    if not t or t.lower() in HALLUCINATIONS:
        return True
    if re.search(r"[^\x00-\x7F‘’“”—–…°ΩωμπΔθ]", t):
        return True   # non-English characters / escape junk (ohm, mu, pi, delta, theta still allowed)
    words = re.findall(r"[A-Za-z0-9']+", t.lower())
    run = 1
    for a, b in zip(words, words[1:]):
        run = run + 1 if a == b else 1
        if run >= 4:
            return True
    if re.search(r"(\d{3},){3,}", t):
        return True
    cc = (course_code or "").strip().lower()
    if cc and t.lower().rstrip(".").startswith(cc) and len(words) <= 4:
        return True
    return False


def wav_pcm(wav_bytes):
    import numpy as np
    with wave.open(io.BytesIO(wav_bytes)) as w:
        sr, n = w.getframerate(), w.getnframes()
        pcm = np.frombuffer(w.readframes(n), dtype=np.int16).astype("float32") / 32768.0
    if sr != 16000:
        idx = np.linspace(0, len(pcm) - 1, int(len(pcm) * 16000 / sr))
        pcm = np.interp(idx, np.arange(len(pcm)), pcm).astype("float32")
    return pcm


def transcribe_wav(wav_bytes, prompt="", name=None):
    pcm = wav_pcm(wav_bytes)
    if len(pcm) < 16000 * MIN_SECONDS:
        return ""   # too short to trust; the app keeps Edge's live words
    m = load(name)
    t = time.time()
    segs, _ = m.transcribe(pcm, language="en", beam_size=5, initial_prompt=prompt or None,
                           condition_on_previous_text=False, vad_filter=False, without_timestamps=True)
    text = " ".join(s.text.strip() for s in segs).strip()
    log.info("whisper %.1fs audio -> %.2fs on %s", len(pcm) / 16000, time.time() - t, _device)
    course_code = " ".join((prompt or "").split()[:2]).rstrip(".")   # e.g. "ECE 2101"
    if looks_junk(text, course_code):
        log.info("whisper junk dropped (kept Edge's words)")
        return ""
    return text
