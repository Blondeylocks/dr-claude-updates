"""
Dr. Claude's pluggable "brain" (the AI that does the tutoring).

The system:
    server  --send(system, history, user_msg, ctx)-->  Brain  --yields events-->  server emit() -> chat window
    events:  ("text", delta) · ("status", line) · ("tool", line) · ("session", id) · ("error", friendly message)
             · ("image", file path) / ("image_b64", data): a picture the AI drew (the server shows it in the chat)

Brains:
    CodexBrain   OpenAI Codex CLI, signed in with the student's ChatGPT (Edu) account. Stateful: the first turn starts
                 a session (`codex exec --json`), later turns `codex exec resume <id>`. Reads files itself; with the
                 workspace-write sandbox it can update the Course Record in the Dr. Claude folder directly.
    GeminiBrain  Google Gemini API with a free AI Studio key (stored with Windows DPAPI). Stateless REST
                 (streamGenerateContent, SSE). It can't open files, so the app hands it the text it needs (ctx["text"])
                 and applies its ```record-update blocks to the Course Record afterwards.
    To add another provider: subclass Brain, implement status() and send(), register it in BRAINS.
"""
import base64
import json
import os
import re
import shutil
import subprocess
import threading
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0
CREATE_NEW_CONSOLE = 0x00000010 if os.name == "nt" else 0


class Brain:
    key = "none"
    label = "No brain"
    stateful = False   # True = the provider remembers the conversation (session id); False = send history each turn
    can_edit = False   # True = it can write the Course Record itself

    def status(self):
        """-> {"ready": bool, "message": str, ...}"""
        return {"ready": False, "message": "No AI is connected yet. Pick one in Settings."}

    def send(self, system, history, user_msg, ctx, session=None, stop=None):
        """Generator of events. history = [{"role": "user"|"assistant", "text": str}] (oldest first).
        ctx = {"paths": [...], "text": "...", "cwd": folder}. session = provider session id from an earlier turn."""
        yield ("error", self.status()["message"])


# ----------------------------------------------------------------------------- OpenAI Codex CLI
CODEX_INSTALL = 'powershell -NoProfile -ExecutionPolicy ByPass -c "irm https://chatgpt.com/codex/install.ps1 | iex"'


def find_codex(extra=""):
    cands = [extra] if extra else []
    la = os.environ.get("LOCALAPPDATA", "")
    cands += [os.path.join(la, "Programs", "OpenAI", "Codex", "bin", "codex.exe"),
              shutil.which("codex.exe") or "", shutil.which("codex.cmd") or "", shutil.which("codex") or ""]
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return ""


def codex_friendly(msg):
    low = (msg or "").lower()
    if "401" in low or "unauthorized" in low or "not logged in" in low or "missing bearer" in low:
        return ("ChatGPT isn't signed in (or the sign-in expired). Go to Settings → Brain → **Sign in with your school ChatGPT**, "
                "finish in the browser, then try again.")
    if "workspace" in low and ("disabled" in low or "not enabled" in low or "not allowed" in low or "admin" in low):
        return ("Your school's ChatGPT workspace hasn't turned on Codex, so Dr. Claude can't use it. "
                "Switch the Brain to **Gemini** in Settings (free key), or ask CPP IT to enable Codex for ChatGPT Edu.")
    if "usage limit" in low or "rate limit" in low or "429" in low or "quota" in low:
        return "You've hit ChatGPT's usage limit for now. Wait a bit, or switch the Brain to Gemini in Settings."
    if "sandbox" in low:
        return ("Codex's Windows sandbox didn't start. In Settings → Brain, set **Codex file access** to *Read only* and try again. "
                f"\n\n```\n{msg[-600:]}\n```")
    return f"The ChatGPT (Codex) brain had a problem.\n\n```\n{(msg or 'no details')[-1200:]}\n```"


class CodexBrain(Brain):
    key = "codex"
    label = "ChatGPT (Codex), school account"
    stateful = True

    def __init__(self, path="", sandbox="workspace-write", model=""):
        self.path = find_codex(path)
        self.sandbox = sandbox if sandbox in ("workspace-write", "read-only") else "workspace-write"
        self.model = model
        self.can_edit = self.sandbox == "workspace-write"

    def _run(self, args, timeout=20):
        return subprocess.run([self.path] + args, capture_output=True, timeout=timeout, creationflags=CREATE_NO_WINDOW,
                              stdin=subprocess.DEVNULL)

    def status(self):
        if not self.path:
            return {"ready": False, "installed": False,
                    "message": "Codex isn't installed yet. Click **Install Codex** (it runs OpenAI's official installer)."}
        try:
            r = self._run(["login", "status"])
            out = (r.stdout + r.stderr).decode("utf-8", "replace")
            lines = [l for l in out.splitlines() if l.strip() and not l.startswith("WARNING")]
            msg = lines[-1].strip() if lines else ""
            if r.returncode == 0:
                return {"ready": True, "installed": True, "message": msg or "Signed in."}
            return {"ready": False, "installed": True, "message": "Not signed in yet. Click **Sign in with your school ChatGPT**."}
        except (OSError, subprocess.TimeoutExpired) as e:
            return {"ready": False, "installed": True, "message": f"Couldn't run Codex: {e}"}

    def open_login(self, device=False, cwd=None):
        """Opens a console window running `codex login` (browser sign-in, or a device code)."""
        args = [self.path, "login"] + (["--device-auth"] if device else [])
        subprocess.Popen(["cmd.exe", "/k"] + args, creationflags=CREATE_NEW_CONSOLE, cwd=cwd or None)

    @staticmethod
    def open_install():
        subprocess.Popen(["cmd.exe", "/k", CODEX_INSTALL + " && echo. && echo Done. Close this window and click Check again in Dr. Claude."],
                         creationflags=CREATE_NEW_CONSOLE)

    def send(self, system, history, user_msg, ctx, session=None, stop=None):
        if not self.path:
            yield ("error", self.status()["message"])
            return
        cwd = ctx.get("cwd") or None
        # personality=friendly: Codex's chat style instead of its terse coding-agent style (older versions ignore it)
        common = ["--json", "--skip-git-repo-check", "-c", f'sandbox_mode="{self.sandbox}"', "-c", 'personality="friendly"']
        if self.model:
            common += ["-m", self.model]
        if session:  # `resume` may not take --image, so a resumed chat gets image paths in the message instead
            args = ["exec", "resume"] + common + [session, "-"]
            prompt = user_msg
        else:
            # --image is variadic: keep it right after "exec" so the next --flag ends it (never swallows the "-" prompt arg)
            imgs = [x for p in ctx.get("images", [])[:4] for x in ("-i", p)]
            args = ["exec"] + imgs + common + ["-C", cwd or ".", "-"]
            paths = "\n".join(f"- {p}" for p in ctx.get("paths", []))
            prompt = f"{system}\n\nFiles you can read for this course:\n{paths}\n\n{ctx.get('note', '')}\n\n{user_msg}".strip()
        yield from self._stream(args, prompt, cwd, stop)

    def _stream(self, args, prompt, cwd, stop):
        env = dict(os.environ)
        try:
            proc = subprocess.Popen([self.path] + args, cwd=cwd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, creationflags=CREATE_NO_WINDOW, env=env)
        except OSError as e:
            yield ("error", f"Couldn't start Codex: {e}")
            return
        if stop is not None:
            stop.append(proc)
        err = []
        threading.Thread(target=lambda: err.append(proc.stderr.read().decode("utf-8", "replace")), daemon=True).start()
        try:
            proc.stdin.write(prompt.encode("utf-8"))
            proc.stdin.close()
        except OSError:
            pass
        info = {}
        yield from parse_codex_jsonl(proc.stdout, info)
        proc.wait()
        if proc.returncode not in (0, None) and not info.get("failed") and not info.get("text") and not getattr(proc, "_killed", False):
            tail = "".join(err).strip()
            yield ("error", codex_friendly(tail or f"Codex stopped (exit code {proc.returncode})."))


def parse_codex_jsonl(stream, info=None):
    """Turn `codex exec --json` lines into brain events. Shared with the tests (fed by a stub)."""
    info = {} if info is None else info
    seen_text = {}
    for raw in stream:
        line = raw.decode("utf-8", "replace").strip() if isinstance(raw, bytes) else raw.strip()
        if not line.startswith("{"):
            continue
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        t = ev.get("type", "")
        if t == "thread.started":
            yield ("session", ev.get("thread_id", ""))
        elif t == "turn.started":
            yield ("status", "Thinking…")
        elif t == "error":
            msg = ev.get("message", "")
            yield ("status", "Reconnecting to ChatGPT…" if msg.startswith("Reconnecting") else msg[:120])
        elif t in ("item.started", "item.updated", "item.completed"):
            it = ev.get("item") or {}
            ty = it.get("type")
            if ty == "agent_message":
                txt = it.get("text") or ""
                iid = it.get("id") or f"msg{len(seen_text)}"
                new_item = iid not in seen_text
                prev = seen_text.get(iid, "")
                delta = txt[len(prev):] if txt.startswith(prev) else "\n\n" + txt
                seen_text[iid] = txt
                if delta:
                    if new_item and info.get("text"):  # a second message in the same turn = new paragraph
                        delta = "\n\n" + delta
                    info["text"] = True
                    yield ("text", delta)
            elif ty == "reasoning" and t == "item.started":
                yield ("status", "Thinking…")
            elif ty == "command_execution" and t == "item.started":
                cmd = it.get("command") or ""
                yield ("tool", "Looking at files" if re.search(r"\b(cat|type|Get-Content|rg|ls|dir|Select-String|findstr)\b", cmd, re.I)
                       else f"Running: {cmd[:60]}")
            elif ty == "file_change" and t == "item.completed":
                names = ", ".join(Path(c.get("path", "")).name for c in it.get("changes") or [])
                yield ("tool", f"Updated {names or 'a file'}")
            elif ty == "web_search" and t == "item.started":
                yield ("tool", f"Searching the web: {it.get('query', '')}"[:80])
            elif ty == "mcp_tool_call" and t == "item.started":
                yield ("tool", f"Using {it.get('tool', 'a tool')}")
            elif "image" in str(ty) and ty != "view_image":  # built-in image generation (item name varies by version)
                if t == "item.started":
                    yield ("tool", "Drawing a picture")
                elif t == "item.completed":
                    for v in it.values():
                        if isinstance(v, str) and re.search(r"\.(png|jpe?g|webp|gif)$", v, re.I):
                            yield ("image", v)
                        elif isinstance(v, str) and len(v) > 1000 and re.fullmatch(r"[A-Za-z0-9+/=\s]+", v[:200]):
                            yield ("image_b64", v)
            elif ty == "error" and t == "item.completed":
                msg = it.get("message", "")
                if not msg.startswith("Falling back"):
                    yield ("status", msg[:120])
        elif t == "turn.failed":
            info["failed"] = True
            yield ("error", codex_friendly((ev.get("error") or {}).get("message", "")))
        elif t == "turn.completed":
            info["usage"] = ev.get("usage")
            yield ("status", "Done")


# ----------------------------------------------------------------------------- Google Gemini (free API key)
GEMINI = os.environ.get("DRC_GEMINI_BASE") or "https://generativelanguage.googleapis.com/v1beta"  # override = tests only


class GeminiBrain(Brain):
    key = "gemini"
    label = "Gemini (free Google AI Studio key)"
    stateful = False

    def __init__(self, api_key="", model=""):
        self.api_key = (api_key or "").strip()
        self.model = model

    def _req(self, url, body=None, timeout=60):
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = urllib.request.Request(url, data=data, headers={"x-goog-api-key": self.api_key, "Content-Type": "application/json"})
        return urllib.request.urlopen(req, timeout=timeout)

    def models(self):
        with self._req(f"{GEMINI}/models?pageSize=200", timeout=20) as r:
            ms = json.loads(r.read().decode("utf-8")).get("models", [])
        ok = [m["name"].split("/", 1)[-1] for m in ms if "generateContent" in (m.get("supportedGenerationMethods") or [])]
        return ok

    def pick_model(self):
        if self.model:
            return self.model
        ms = self.models()

        def rank(n):  # newest numbered "flash" model, not lite/preview/tts/image/embedding
            bad = any(x in n for x in ("lite", "tts", "image", "embedding", "live", "audio", "thinking", "exp"))
            ver = [int(x) for x in re.findall(r"(\d+)", n)[:2]] + [0, 0]
            return (("flash" in n) and not bad, "preview" not in n, ver[0], ver[1])
        ms.sort(key=rank, reverse=True)
        if not ms:
            raise RuntimeError("No Gemini models are available for this key.")
        self.model = ms[0]
        return self.model

    def status(self):
        if not self.api_key:
            return {"ready": False, "message": "No Gemini key saved yet. Get a free one at aistudio.google.com/apikey and paste it."}
        try:
            m = self.pick_model()
            return {"ready": True, "message": f"Key works. Model: {m}", "model": m}
        except urllib.error.HTTPError as e:
            return {"ready": False, "message": gemini_friendly(e.code, _read_err(e))}
        except (urllib.error.URLError, OSError, RuntimeError) as e:
            return {"ready": False, "message": f"Couldn't reach Gemini: {e}"}

    def send(self, system, history, user_msg, ctx, session=None, stop=None):
        if not self.api_key:
            yield ("error", self.status()["message"])
            return
        try:
            model = self.pick_model()
        except urllib.error.HTTPError as e:
            yield ("error", gemini_friendly(e.code, _read_err(e)))
            return
        except Exception as e:
            yield ("error", f"Couldn't reach Gemini: {e}")
            return
        contents = []
        for m in history[-24:]:
            role = "model" if m["role"] == "assistant" else "user"
            if contents and contents[-1]["role"] == role:
                contents[-1]["parts"][0]["text"] += "\n\n" + m["text"]
            else:
                contents.append({"role": role, "parts": [{"text": m["text"]}]})
        turn = (f"[Context from the student's files]\n{ctx['text']}\n[End of context]\n\n" if ctx.get("text") else "") + user_msg
        if contents and contents[-1]["role"] == "user":
            contents[-1]["parts"][0]["text"] += "\n\n" + turn
        else:
            contents.append({"role": "user", "parts": [{"text": turn}]})
        for p in ctx.get("images", [])[:4]:  # pictures attached to this chat
            try:
                data = Path(p).read_bytes()
            except OSError:
                continue
            if len(data) <= 15 * 1024 * 1024:
                contents[-1]["parts"].append({"inlineData": {"mimeType": IMAGE_MIME.get(Path(p).suffix.lower(), "image/png"),
                                                             "data": base64.b64encode(data).decode("ascii")}})
        body = {"systemInstruction": {"parts": [{"text": system}]}, "contents": contents,
                "generationConfig": {"maxOutputTokens": 4096}}
        yield ("status", f"Thinking… ({model})")
        try:
            r = self._req(f"{GEMINI}/models/{urllib.parse.quote(model)}:streamGenerateContent?alt=sse", body, timeout=180)
        except urllib.error.HTTPError as e:
            yield ("error", gemini_friendly(e.code, _read_err(e)))
            return
        except (urllib.error.URLError, OSError) as e:
            yield ("error", f"Couldn't reach Gemini: {e}")
            return
        if stop is not None:
            stop.append(r)
        with r:
            yield from parse_gemini_sse(r)


IMAGE_MIME = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif"}


def gemini_image(api_key, prompt, model=""):
    """Draw one picture with Gemini's image model. -> (png/jpeg bytes, ext) or raises RuntimeError(friendly message)."""
    models = [model] if model else ["gemini-2.5-flash-image", "gemini-2.0-flash-preview-image-generation"]
    last = ""
    for m in models:
        body = {"contents": [{"role": "user", "parts": [{"text": prompt}]}],
                "generationConfig": {"responseModalities": ["TEXT", "IMAGE"]}}
        req = urllib.request.Request(f"{GEMINI}/models/{urllib.parse.quote(m)}:generateContent", data=json.dumps(body).encode("utf-8"),
                                     headers={"x-goog-api-key": api_key, "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                j = json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            last = gemini_friendly(e.code, _read_err(e))
            if e.code in (400, 404):
                continue
            break
        except (urllib.error.URLError, OSError) as e:
            last = f"Couldn't reach Gemini: {e}"
            break
        for c in j.get("candidates") or []:
            for p in (c.get("content") or {}).get("parts") or []:
                d = p.get("inlineData") or p.get("inline_data")
                if d and d.get("data"):
                    ext = ".jpg" if "jpeg" in d.get("mimeType", "") else ".png"
                    return base64.b64decode(d["data"]), ext
        last = "Gemini didn't send a picture back."
    raise RuntimeError(last or "Couldn't draw that picture.")


def parse_gemini_sse(stream):
    got = False
    for raw in stream:
        line = raw.decode("utf-8", "replace").strip() if isinstance(raw, bytes) else raw.strip()
        if not line.startswith("data:"):
            continue
        try:
            ev = json.loads(line[5:].strip())
        except ValueError:
            continue
        if ev.get("error"):
            yield ("error", gemini_friendly(ev["error"].get("code", 0), ev["error"].get("message", "")))
            return
        for c in ev.get("candidates") or []:
            for p in (c.get("content") or {}).get("parts") or []:
                if p.get("text") and not p.get("thought"):
                    got = True
                    yield ("text", p["text"])
            if c.get("finishReason") in ("SAFETY", "BLOCKLIST", "PROHIBITED_CONTENT"):
                yield ("error", "Gemini refused to answer that one (safety filter). Try rewording it.")
        fb = ev.get("promptFeedback") or {}
        if fb.get("blockReason"):
            yield ("error", f"Gemini blocked the question ({fb['blockReason']}). Try rewording it.")
    if not got:
        yield ("status", "Gemini sent an empty answer.")


def _read_err(e):
    try:
        j = json.loads(e.read().decode("utf-8", "replace"))
        return (j.get("error") or {}).get("message", "")
    except Exception:
        return ""


def gemini_friendly(code, msg):
    if code in (400, 403) and ("api key" in (msg or "").lower() or "permission" in (msg or "").lower()):
        return "Gemini didn't accept the key. Make a new one at aistudio.google.com/apikey and paste it in Settings → Brain."
    if code == 429:
        return "You've hit Gemini's free limit for now (requests per minute or per day). Wait a bit and try again."
    if code == 404:
        return f"That Gemini model isn't available ({msg[:160]}). Clear the model box in Settings so the app picks one."
    return f"Gemini had a problem ({code}): {(msg or '')[:300]}"


# ----------------------------------------------------------------------------- registry
BRAINS = {"codex": CodexBrain, "gemini": GeminiBrain}
