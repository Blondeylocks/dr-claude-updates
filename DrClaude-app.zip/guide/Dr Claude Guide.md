# Dr. Claude 101: how to use Dr. Claude, Codex, and AI

*This guide comes with the app and updates itself. Read it here, or open the Classroom with **DRC 101** picked and ask anything, like "how do I sync Canvas?" or "what's a good prompt for studying for a midterm?"*

---

## 1. What Dr. Claude is

Dr. Claude is a **study professor that lives on your computer**. It knows your real classes, including your files, deadlines, and how far along each class is, and it teaches you at the same pace your real professor does.

Here's how the pieces fit together:

```
 Canvas (your classes)  --sync-->  Documents\Dr. Claude\   (your files, deadlines, Course Records)
                                          |
                                          v
                      Dr. Claude app  <-->  AI brain (ChatGPT through Codex, or Google Gemini)
                                          |
                                          v
                                you: lessons, quizzes, mock exams, help
```

- **Your stuff stays on your computer.** Your files, notes, chats, and settings live in `Documents\Dr. Claude\` and in the app's own folder. Only the question you're asking, plus the class material needed to answer it, goes to the AI.
- 🎤 **Talk to it, don't just type.** Hold the **Space bar** in the Classroom (or press 🎤 / Ctrl+M) and answer out loud, like you would to a real professor. It's faster, and explaining out loud is one of the best ways to learn. It also lets Dr. Claude tell which answers you're sure about and which ones you're guessing on.
- **It teaches, it doesn't do your homework.** Dr. Claude asks you questions, gives hints one step at a time, and checks your work. That's on purpose, because you learn far more by doing than by reading answers.

---

## 2. A tour of the app

| Screen | What it's for |
|---|---|
| **Home** | Today's plan, what's due soon, and a big "Study" button. |
| **Classroom** | Where you learn. Pick a class and a mode, then chat with your professor. |
| **Courses** | Each class's Course Record: what's been covered week by week, quizzes and exams, and what you've mastered. |
| **Library** | All your class files (from Canvas plus anything you upload) and the 📚 textbook finder. |
| **Gradebook** | Scores from your practice quizzes and mock exams. |
| **Command** | Tell Dr. Claude *how* you like to learn ("give me one question at a time," "use more pictures"). It turns that into teaching rules. |
| **Tools** (🧰) | Calculator, Quick Ask (a side chat for quick questions), and My Thoughts (your notes while studying). |
| **Guide** | This page. |
| **Ideas** (💡) | Send ideas, problems, and wishes to the person who set up your Dr. Claude. |
| **Settings** | Your profile, the AI brain, Canvas, theme, and updates. |

### Classroom modes
- **Lecture**: teaches the next topic in your class, in small chunks with pictures.
- **Homework**: practice problems like your professor's, one at a time. You try first, then it checks.
- **Quiz**: a practice quiz built like your real quizzes.
- **Mock Exam**: a full practice test, timed like the real one, graded at the end and saved to the Gradebook.
- **Office Hours**: "I'm stuck on X," and you get help in tiny steps.
- **Replay a Course**: re-take a whole class at your own pace.
- **Log a Class**: tell it what your real class covered today so it stays in step with your professor.

### Handy things in the chat
- **Hold Space to talk**: in the Classroom, hold the Space bar, say your question, and let go. Your words appear in the message box; check them, then press Enter. (A quick tap still types a normal space.)
- 🎤 **Mic** (or Ctrl+M) turns talking on and off without holding anything.
- 🎤 **Voice upgrade + confidence reader** (optional, in **Settings**):
  - **Voice upgrade (Whisper):** voice typing gets much more accurate with your class's words ("drag coefficient", "angle of attack"). Press **Turn on** once. It downloads about **750 MB** (a few minutes) and then runs on your laptop, even offline. If your laptop has an NVIDIA graphics card, you can pick a bigger, better model (about 2.9 GB). **Remove voice upgrade** frees the space; plain voice typing keeps working either way.
  - **Confidence reader** (needs the voice upgrade; you turn it on): when you answer out loud, Dr. Claude notices *how* you said it (how long before you started, pauses, "um"s, "I think…", a rising voice at the end) and compares it only to **your own** usual voice. Answers you sounded unsure about come back for review sooner, and answers you were sure about but got wrong get extra attention, because those are the mistakes worth fixing first. Every so often it asks "how sure were you, 1–5?" so it learns what *your* voice sounds like when you're sure. It needs about 8 spoken answers to learn your normal, and it never comments on how you talk.
  - **Privacy:** the sound of your voice is never saved. Only a few numbers per answer stay on this laptop. **Forget my voice profile** erases them.
- 📎 **Attach** a photo of your homework, a worksheet, or a screenshot. You can also paste or drop it in. Attachments stay in that chat only.
- **Pictures**: the tutor can draw diagrams right in the chat. Ask for one: "draw me a free-body diagram of this."
- **Videos, trimmed to the exact part**: when a short video would help, the tutor finds one and **plays only the part that answers your question**. It reads the video's captions to find the spot, so pressing ▶ starts right there. The card says which part it plays (like "plays 10:24–11:52").
  - After the clip, it asks **"How was this clip?"** Tap ✅ *Right part*, ⏩ *Right video, wrong part*, or ❌ *Wrong video*. If it missed, it finds a better one and asks what you were looking for, so the next search is sharper. Your answers teach it which clips to reuse.
  - If it isn't sure it found the exact spot, it tells you (🤔) so you can say.
- **Files made for you, right in the chat**: Dr. Claude can make you
  - 🌐 a **web page**: an interactive demo, or a practice quiz that checks your answers
  - 📄 a **PDF**: a 1-page cheat sheet, worked examples, or a practice set with an answer key
  - 🎞️ an **animated GIF** that shows a process step by step
  - 🎧 an **MP3** to listen to (good for review on a walk)
  - 🎬 a short **MP4 video** with a narrator

  When you start a new topic or you're stuck, it offers the one that fits best. You can also just ask: *"make me a PDF cheat sheet of this"* or *"make a GIF of how a stack pushes and pops."* The file shows up in the chat, ready to watch, play, or read. **↗ Open** opens it in its own window, and **💾 Save to class** keeps a copy in that class's Library (*My Files → Made by Dr. Claude*). You never have to dig through folders.
- **🔁 Retro** reads your session and suggests changes to how Dr. Claude teaches you.
- **⏹ End study session** saves your study time.

---

## 3. Getting your classes in

### Canvas sync (the main way)
1. Go to **Settings → 🎓 Canvas** and drag the **🎓 Sync Dr. Claude** button up to your bookmarks bar. You only do this once.
2. Open Canvas and log in like normal.
3. Click the **🎓 Sync Dr. Claude** bookmark. A small window shows the progress.

**Good to know:**
- **Auto-sync (optional):** after a sync, the little sync window stays open. If you leave it open (minimized is fine) and keep your Canvas tab open, it quietly checks Canvas again every 3 hours. Close the window any time to stop it. There are no pop-ups or reminders.
- **Otherwise, sync again when your professors post new things.** Click the bookmark on Canvas. Home shows **Last Canvas sync: N days ago** next to *Your classes*, and that line turns gold after a week.
- **Later syncs are fast.** Dr. Claude only downloads files that are new or changed and skips everything it already has.
- **Keep the Canvas Files folder as it is.** It mirrors Canvas. If you move or rename files in there, the next sync downloads them again. Put your own organizing in **My Files**.

### Adding a class by hand
If a class isn't on Canvas, go to **Courses → ➕ Add a class by hand**, then upload its files in the **Library**.

### Textbooks
Dr. Claude reads your syllabus and class files to see **which textbook each professor uses**. If a class doesn't have its book in its files yet, **Home shows a 📚 Missing textbooks card** that names the book.

1. Click **🔎 Find it**. The Library opens, looks up the book, and searches the web for a PDF of it.
2. For each result you can:
   - **🌐 Open link**: opens it in your web browser so you can look first. If it's the right book, save it with the PDF viewer's ⬇ download button (or Ctrl+S), then drag it into the Library.
   - **📋 Copy link**: copies the link so you can paste it anywhere.
   - **⬇ Let Dr. Claude download it**: downloads it, checks the title and ISBN, and **asks you before keeping it**.
3. If a class really has no textbook (or you have a paper copy), click **I don't need one** and the card hides it.

You can also search any time in the **Library** under *📕 Find a textbook by ISBN*. Only keep copies you're allowed to use: free/open textbooks (like OpenStax), your school library, or a book you own.

---

## 4. The AI brain: Codex and Gemini

Dr. Claude doesn't have its own AI. It uses one you sign into:

| Brain | What it is | Cost |
|---|---|---|
| **ChatGPT through Codex** (recommended) | Codex is OpenAI's AI helper that can read and work with files on your computer. Dr. Claude uses it behind the scenes, signed in with **your** ChatGPT account. Many schools give students a free ChatGPT Edu account. | Uses your ChatGPT plan |
| **Google Gemini** (backup) | Google's AI, using a free key you paste into Settings. | Free key |

**To set up or switch:** go to **Settings → 🧠 AI brain**.
1. **Install Codex** (one click; OpenAI's official installer opens in a black window, so wait for "Done").
2. **Sign in with your school ChatGPT.** A browser page opens. Choose **Sign in with ChatGPT** and use your school email. If the browser sign-in doesn't come back, use **Use a code instead**.
3. **Test a reply** to make sure it works.

**File access (Advanced):** Codex can only ever touch the `Documents\Dr. Claude` folder. With full access it can update your Course Records itself. If updates fail, pick **Read only**.

---

## 5. Using Codex on your own (outside Dr. Claude)

Codex isn't only inside Dr. Claude. You can use it directly for anything, not just studying.

### Where Codex is
- **ChatGPT desktop app** (Windows, from OpenAI or the Microsoft Store). Codex lives inside it: switch the toggle above the message box from **Chat** to **Work**, then open a folder to work in.
- **Terminal**: the Codex that Dr. Claude installed is also a command. Open **Terminal** (or PowerShell), type `codex`, and press Enter. Type what you want in plain English. Press Ctrl+C twice to quit.
- **On the web**: go to **chatgpt.com** and sign in. Normal ChatGPT is great for questions, and Codex there works on projects in the cloud.

### What Codex can do
- **Organize files**: "Sort everything in my Downloads folder into folders by class," or "rename these lecture PDFs to *Week N – Topic*."
- **Make things**: documents, study guides, spreadsheets, flashcards, slides, charts, and pictures.
- **Read lots of stuff fast**: "Read these 6 PDFs and make me a one-page summary of what they have in common."
- **Do computer tasks**: convert files, combine PDFs, clean up a spreadsheet, run code and fix errors.
- **Research**: look things up on the web and tell you where it found them.

### Staying safe with Codex
- **Give it one folder to work in.** It's safest when you open the folder you want it to touch, not your whole computer.
- **It asks before big actions.** Read what it wants to do before you click allow, especially before it deletes or moves things.
- **Check its work.** It's very good but not perfect, so look over files before you turn anything in.
- **Follow your class's AI rules.** Some classes don't allow AI on assignments. Use it to *learn* (explain, quiz, check), not to write work you turn in, unless your professor says it's OK.

---

## 6. Codex in Chrome

OpenAI makes a **Codex extension for Google Chrome** (Windows and Mac). With it, Codex can work in your browser: read the page you're on, use your open tabs, fill in forms, click through websites, and do tasks in background tabs while you keep working.

### Setting it up
1. Open the **ChatGPT desktop app** (where Codex lives).
2. Go to **Plugins** and find **Chrome**. Click **Install**. It sends you to the Chrome Web Store page for the Codex extension; click **Add to Chrome**.
3. Approve the permission prompts. The extension should show as **connected**.
4. Now ask Codex to do something in the browser, like "Open my Canvas and list everything due this week."

**Codex asks before** it opens new sites, reads your history, or moves files, so read those prompts.

### If it doesn't show up or won't connect
- Not every account has it yet; OpenAI is rolling it out bit by bit. Try signing out and back in.
- Fully quit both Chrome and the ChatGPT app (check the system tray too), then open them again.
- Try installing straight from the Chrome Web Store (search "Codex").
- Still stuck? Send it through **💡 Ideas** as a problem.

**Codex in Chrome vs. Dr. Claude's Canvas bookmark:** they're separate. The 🎓 Sync bookmark is Dr. Claude's own way to pull your Canvas files, and you don't need the Codex extension for it.

---

## 7. Using AI well: what good prompts look like

The AI is only as good as what you tell it. A good prompt has **four parts**:

1. **Who you are**: "I'm a 2nd-year aerospace student in ARO 1011L."
2. **What you want**: "Explain why a wing stalls."
3. **Your situation**: "I get Bernoulli, but I don't get why angle of attack matters."
4. **How you want it**: "Use a picture, keep it short, then ask me one question to check."

### Weak vs. strong
| ❌ Weak | ✅ Strong |
|---|---|
| "explain lift" | "Explain lift like I've seen Bernoulli's equation once but never used it. Start with a picture, then one question for me." |
| "help with my homework" | "Here's problem 3 (photo attached). Don't solve it. Give me the first hint only, and I'll try from there." |
| "make a study guide" | "Make a 1-page study guide for Midterm 2 from weeks 5–8 of my notes, as a table: concept, formula, one example." |
| "is this right?" | "Here's my answer and my steps. Find the first step where I went wrong, but don't fix it. Tell me which step." |
| "quiz me" | "Give me 5 questions like my professor's quizzes on drag, one at a time, harder each time. Tell me what I got wrong at the end." |

### Tricks that work
- **Ask it to quiz you, not tell you.** "Ask me questions until I can explain it myself."
- **Explain it back.** "I'll explain stall in my own words; tell me what I missed." Teaching it is the fastest way to learn it.
- **Ask for a hint ladder.** "Smallest hint first. I'll ask for more."
- **Give it the real material.** Attach the slide, the problem, or the rubric. It does much better with the actual thing than with a description.
- **Make it check itself.** "Double-check that with a different method." AI can be confidently wrong, especially with numbers, so use the calculator for exact math.
- **Say what's wrong with its answer.** "Too long" / "use simpler words" / "I need the units" works. You don't have to start over.

### Ready-to-use prompts for Dr. Claude
- "What's due this week, and what should I study first?"
- "Teach me the next topic in this class like it's lecture."
- "I have a quiz Thursday. Give me a practice quiz like the real one."
- "Make me a mock exam for the midterm, timed like the real one."
- "I'm stuck on this problem (photo attached). One hint at a time."
- "Draw a labeled picture of this."
- "Find me a short video on this and tell me what to watch for."
- "Make me a 1-page PDF cheat sheet for this chapter."
- "Make a short video that explains this, with a narrator."
- "Make me a practice quiz web page that checks my answers."
- "What have I gotten wrong the most in this class? Drill me on it."
- "Today in class we covered ___. Log it."

---

## 8. The calculator (🧰 Tools → 🧮)

Type math normally, tap the buttons (`+ − × ÷ ( ) ^ √`), or **just say it in words**:
- "3 times 4" · "what is 100 divided by 5?" · "20 percent of 85"
- "multiply 6 by 7" · "half of 50" · "2 to the 10th" · "square root of 81"
- "the average of 2, 4 and 6" · "subtract 3 from 10"

It shows **how it read your words** ("I read that as 100 / 5"), so you can catch mistakes. If the wording is unusual, the AI turns it into math first, but **the calculator always does the math itself**, so the answer is exact. 🎤 lets you say it out loud. Click a past answer in History to reuse it, and `ans` means "my last answer."

---

## 9. Ideas, problems, and wishes (💡 Ideas)

Want something changed, found a bug, or have an idea? Open **💡 Ideas**, pick a type, and write it like you'd text it. It goes straight to the person who set up your Dr. Claude (no email, nothing else to click), and the list at the bottom shows everything you've sent. If you're offline, it waits and sends by itself later. Updates install by themselves, so changes just show up.

---

## 10. Updates and privacy

- **Updates are automatic.** Dr. Claude checks for new versions, downloads them, double-checks them, and installs them. If something goes wrong, it goes back to the last version. Your chats, files, and settings are never touched.
- **What leaves your computer:** only what you send the AI (your message plus the class material it needs), your Canvas sync (between your browser and Canvas), and ideas you send through 💡 Ideas.
- **Your Canvas password is never stored.** The sync works through your own logged-in Canvas tab.

---

## 11. Quick fixes

| Problem | Try this |
|---|---|
| The tutor doesn't answer | **Settings → 🧠 AI brain → Test a reply.** If it says you're signed out, sign in again. |
| "Codex's sandbox didn't start" | **Settings → 🧠 AI brain → Advanced → File access → Read only.** |
| New Canvas files are missing | Open Canvas and click the **🎓 Sync Dr. Claude** bookmark again. |
| The sync window says it lost Dr. Claude | Make sure the Dr. Claude app is open, then click the bookmark again. |
| Something looks broken | Close Dr. Claude and open it again from the Desktop icon. Then send it through **💡 Ideas**. |
