"""
Remote updates for Dr. Claude.

    manifest.json   {"version": "1.2.0", "notes": "...", "zip_url": "<link>", "sha256": "<hex>", "min_version": "1.1.0"?}
    links           a direct URL, or a OneDrive / Google Drive / Dropbox share link (turned into a download here)

Flow: check() -> stage() downloads the zip, VERIFIES sha256, unpacks into <install>\\update_staged\\app\\
      -> apply() copies updater.py next to the install, starts it, and the app exits.
      updater.py waits for the app to close, backs up app\\ to app_prev\\, copies the new files over app\\ only,
      relaunches, and rolls back if the new version doesn't answer its health ping.
User data never lives in app\\ (it is in <install>\\data and Documents\\Dr. Claude), and the updater skips app\\data anyway.
"""
import base64
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

UA = {"User-Agent": "DrClaude-Updater/1.0"}
CHECK_EVERY = 6 * 3600


def vtuple(v):
    n = [int(x) for x in re.findall(r"\d+", str(v or "0"))[:3]]
    return tuple(n + [0] * (3 - len(n)))


# ----------------------------------------------------------------------------- share link -> direct download
def candidates(link):
    """Ways to download a share link, most reliable first. Each result is checked by the caller."""
    link = (link or "").strip()
    host = urllib.parse.urlparse(link).netloc.lower()
    out = []
    if "1drv.ms" in host or "onedrive.live.com" in host or "sharepoint.com" in host or "onedrive.com" in host:
        b64 = base64.urlsafe_b64encode(link.encode()).decode().rstrip("=")
        out.append(f"https://api.onedrive.com/v1.0/shares/u!{b64}/root/content")
        sep = "&" if "?" in link else "?"
        out.append(link + sep + "download=1")
        out.append(("resolve", link))  # follow the redirect, then try the forms the final page allows
    elif "drive.google.com" in host or "docs.google.com" in host:
        m = re.search(r"/d/([\w-]{10,})", link) or re.search(r"[?&]id=([\w-]{10,})", link)
        if m:
            out.append(f"https://drive.usercontent.google.com/download?id={m.group(1)}&export=download&confirm=t")
            out.append(f"https://drive.google.com/uc?export=download&id={m.group(1)}")
    elif "dropbox.com" in host:
        out.append(re.sub(r"([?&])dl=0", r"\1dl=1", link) if "dl=0" in link else link + ("&" if "?" in link else "?") + "dl=1")
    out.append(link)
    return out


def _get(url, timeout=30):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(), r.geturl(), r.headers.get("Content-Type", "")


def _resolve_page(link):
    """Follow a OneDrive share link to its landing page and pull out download-able forms."""
    out = []
    try:
        body, final, _ = _get(link)
    except Exception:
        return out
    q = urllib.parse.parse_qs(urllib.parse.urlparse(final).query)
    if "redir" in final:
        out.append(final.replace("/redir?", "/download?").replace("/redir.aspx?", "/download.aspx?"))
    if q.get("resid"):
        out.append(f"https://api.onedrive.com/v1.0/drives/{q['resid'][0].split('!')[0]}/items/{q['resid'][0]}/content"
                   + (f"?authkey={q['authkey'][0]}" if q.get("authkey") else ""))
    if q.get("redeem"):
        out.append(f"https://api.onedrive.com/v1.0/shares/u!{q['redeem'][0]}/root/content")
    txt = body[:400000].decode("utf-8", "replace")
    for m in re.finditer(r'"(?:@content\.downloadUrl|downloadUrl|FileGetUrl)"\s*:\s*"([^"]+)"', txt):
        out.append(m.group(1).encode().decode("unicode_escape"))
    return out


def fetch(link, want, timeout=60):
    """Download a link (direct or share link). want = "json" or "zip": the bytes must look right.
    Returns (bytes, url_that_worked). Raises RuntimeError with every attempt if none work."""
    tried, queue = [], candidates(link)
    while queue:
        c = queue.pop(0)
        if isinstance(c, tuple):
            queue[0:0] = _resolve_page(c[1])
            continue
        if c in tried:
            continue
        tried.append(c)
        try:
            body, _, _ = _get(c, timeout)
        except Exception:
            continue
        if want == "zip" and body[:2] == b"PK":
            return body, c
        if want == "json":
            try:
                json.loads(body.decode("utf-8-sig"))
                return body, c
            except ValueError:
                continue
    raise RuntimeError("Couldn't download " + link + " (tried " + str(len(tried)) + " ways)")


# ----------------------------------------------------------------------------- the app side
class Updater:
    def __init__(self, app_dir, install_dir, version, manifest_url, log=None):
        self.app_dir = Path(app_dir)
        self.install = Path(install_dir)
        self.version = version
        self.manifest_url = manifest_url
        self.log = log
        self.staged = self.install / "update_staged"
        self.state_file = self.install / "update_state.json"
        self.status = {"current": version, "available": None, "notes": "", "staged": False, "error": "",
                       "checked": None, "too_old": False, "configured": bool(manifest_url)}
        self.manifest = None
        self._lock = threading.Lock()

    def _say(self, msg):
        if self.log:
            self.log.info("update: %s", msg)

    def read_state(self):
        try:
            return json.loads(self.state_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def write_state(self, st):
        self.state_file.write_text(json.dumps(st, indent=1), encoding="utf-8")

    def check(self):
        if not self.manifest_url:
            self.status.update(error="", configured=False)
            return self.status
        try:
            body, _ = fetch(self.manifest_url, "json", timeout=20)
            m = json.loads(body.decode("utf-8-sig"))
            self.manifest = m
            newer = vtuple(m.get("version")) > vtuple(self.version)
            self.status.update(available=m.get("version") if newer else None, notes=m.get("notes", "") if newer else "",
                               error="", checked=time.strftime("%Y-%m-%dT%H:%M:%S"),
                               too_old=bool(newer and m.get("min_version") and vtuple(self.version) < vtuple(m["min_version"])))
            failed = self.read_state()
            self.status["failed_before"] = bool(newer and failed.get("status") == "rolled_back" and failed.get("to") == m.get("version"))
            self.status["staged"] = self.staged_version() == m.get("version")
            self._say(f"checked: latest {m.get('version')} (have {self.version})")
        except Exception as e:
            self.status.update(error=str(e), checked=time.strftime("%Y-%m-%dT%H:%M:%S"))
            self._say(f"check failed: {e}")
        return self.status

    def staged_version(self):
        try:
            return (self.staged / "app" / "VERSION").read_text(encoding="utf-8").strip()
        except OSError:
            return None

    def stage(self):
        """Download + verify + unpack the new version into update_staged\\app. Returns the staged version."""
        with self._lock:
            m = self.manifest or (self.check() and self.manifest)
            if not m or not self.status.get("available"):
                raise RuntimeError("No update available.")
            if self.status.get("too_old"):
                raise RuntimeError("This version is too old to update itself. Please reinstall Dr. Claude.")
            if self.staged_version() == m["version"]:
                return m["version"]
            data, _ = fetch(m["zip_url"], "zip", timeout=120)
            got = hashlib.sha256(data).hexdigest()
            if got.lower() != str(m.get("sha256", "")).lower():
                raise RuntimeError(f"The download didn't pass its safety check (sha256 {got[:12]}… ≠ {str(m.get('sha256'))[:12]}…). Nothing was changed.")
            tmp = self.install / "update_staged.tmp"
            shutil.rmtree(tmp, ignore_errors=True)
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                for n in z.namelist():
                    if n.startswith("/") or ".." in Path(n).parts or re.match(r"^[A-Za-z]:", n):
                        raise RuntimeError("Bad file name inside the update zip.")
                z.extractall(tmp / "app")
            if not (tmp / "app" / "dr_claude.py").exists() or (tmp / "app" / "VERSION").read_text(encoding="utf-8").strip() != m["version"]:
                shutil.rmtree(tmp, ignore_errors=True)
                raise RuntimeError("The update zip is missing files.")
            (tmp / "notes.txt").write_text(m.get("notes", ""), encoding="utf-8")
            shutil.rmtree(self.staged, ignore_errors=True)
            os.replace(tmp, self.staged)
            self.status["staged"] = True
            self._say(f"staged {m['version']}")
            return m["version"]

    def apply(self, pid, python_exe, launch):
        """Start the updater (a copy outside app\\) and return; the caller then exits."""
        runner = self.install / "updater_run.py"
        shutil.copy2(self.app_dir / "updater.py", runner)
        args = [python_exe, str(runner), "--pid", str(pid), "--install", str(self.install),
                "--from", self.version, "--launch", json.dumps(launch)]
        flags = 0x00000008 | 0x00000200 | 0x08000000 if os.name == "nt" else 0  # detached, new group, no window
        subprocess.Popen(args, creationflags=flags, close_fds=True, cwd=str(self.install),
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self._say("updater started")


if __name__ == "__main__":  # python updates.py resolve <link> [json|zip]  -> which download form works
    if len(sys.argv) >= 3 and sys.argv[1] == "resolve":
        try:
            b, url = fetch(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else "json")
            print(json.dumps({"ok": True, "url": url, "bytes": len(b)}))
        except Exception as e:
            print(json.dumps({"ok": False, "error": str(e)}))
            sys.exit(1)
