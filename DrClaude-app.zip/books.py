"""
Textbook finder: ISBN -> the book's details -> free copies -> a web search for a PDF -> download -> the student checks it.

The system:
    lookup(isbn)        Open Library (+ Google Books as a backup) -> title, authors, edition, cover, free/legal copies
    web_search(book)    DuckDuckGo's plain-HTML search with filetype:pdf (Google blocks apps; the page also offers
                        "open this search in Google" in the browser)
    download(url)       -> <data>\\book_pending\\<id>.pdf, only if it really is a PDF; then check() reads the first pages
                        for the title / authors / ISBN so the student can see whether it's the right book
    keep(id, dest) / discard(id)   nothing reaches the Library until the student says "yes, that's it"
Standard library only.
"""
import html
import json
import re
import shutil
import threading
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zlib
from pathlib import Path

import filetext

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"}
MAX_BYTES = 400 * 1024 * 1024
JOBS = {}  # download id -> {"state": "downloading"|"done"|"error", "got": bytes, "total": bytes, ...}
_lock = threading.Lock()


# ----------------------------------------------------------------------------- ISBN
def clean_isbn(s):
    """'978-0-262-04630-5' -> '9780262046305'. ISBN-10s become ISBN-13. Raises ValueError if the check digit is wrong."""
    s = re.sub(r"[^0-9Xx]", "", s or "").upper()
    if len(s) == 10:
        if not re.fullmatch(r"\d{9}[\dX]", s):
            raise ValueError("That ISBN has a letter in the wrong place.")
        total = sum((10 - i) * (10 if c == "X" else int(c)) for i, c in enumerate(s))
        if total % 11:
            raise ValueError("That ISBN-10 doesn't check out (a digit may be off). Look at the back cover or the copyright page again.")
        s = "978" + s[:9]
        return s + str((10 - sum((1 if i % 2 == 0 else 3) * int(c) for i, c in enumerate(s)) % 10) % 10)
    if len(s) == 13 and s.isdigit():
        if sum((1 if i % 2 == 0 else 3) * int(c) for i, c in enumerate(s)) % 10:
            raise ValueError("That ISBN-13 doesn't check out (a digit may be off). Look at the back cover or the copyright page again.")
        return s
    raise ValueError("An ISBN has 10 or 13 digits (it's on the back cover, above the barcode, or on the copyright page).")


def isbn10(isbn13):
    if not isbn13.startswith("978"):
        return ""
    core = isbn13[3:12]
    c = (11 - sum((10 - i) * int(d) for i, d in enumerate(core)) % 11) % 11
    return core + ("X" if c == 10 else str(c))


def _get_json(url, timeout=15):
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def lookup(raw):
    isbn = clean_isbn(raw)
    book = {"isbn": isbn, "isbn10": isbn10(isbn), "title": "", "subtitle": "", "authors": [], "publisher": "",
            "year": "", "pages": None, "cover": "", "edition": "", "free": [], "source": ""}
    try:
        d = _get_json(f"https://openlibrary.org/api/books?bibkeys=ISBN:{isbn}&format=json&jscmd=data").get(f"ISBN:{isbn}") or {}
        if d:
            book.update(title=d.get("title", ""), subtitle=d.get("subtitle", ""), source="Open Library",
                        authors=[a.get("name", "") for a in d.get("authors") or []],
                        publisher=", ".join(p.get("name", "") for p in d.get("publishers") or []),
                        year=d.get("publish_date", ""), pages=d.get("number_of_pages"),
                        cover=(d.get("cover") or {}).get("medium", ""))
        s = _get_json(f"https://openlibrary.org/search.json?isbn={isbn}&fields=ebook_access,ia,key,edition_count")
        doc = (s.get("docs") or [{}])[0] if s.get("docs") else {}
        acc, ia = doc.get("ebook_access"), (doc.get("ia") or [])
        if acc == "public" and ia:
            book["free"].append({"label": "Free, public domain (Internet Archive)", "kind": "pdf",
                                 "url": f"https://archive.org/download/{ia[0]}/{ia[0]}.pdf"})
        elif acc == "borrowable" and ia:
            book["free"].append({"label": "Borrow free for 1 hour/14 days (Open Library, free account)", "kind": "page",
                                 "url": f"https://openlibrary.org{doc.get('key', '')}"})
    except (urllib.error.URLError, OSError, ValueError):
        pass
    try:
        g = _get_json(f"https://www.googleapis.com/books/v1/volumes?q=isbn:{isbn}")
        it = (g.get("items") or [{}])[0] if g.get("items") else {}
        vi, ai = it.get("volumeInfo") or {}, it.get("accessInfo") or {}
        if vi and not book["title"]:
            book.update(title=vi.get("title", ""), subtitle=vi.get("subtitle", ""), authors=vi.get("authors") or [],
                        publisher=vi.get("publisher", ""), year=vi.get("publishedDate", ""), pages=vi.get("pageCount"),
                        cover=(vi.get("imageLinks") or {}).get("thumbnail", "").replace("http://", "https://"), source="Google Books")
        if ai.get("publicDomain") and (ai.get("pdf") or {}).get("downloadLink"):
            book["free"].append({"label": "Free, public domain (Google Books)", "kind": "pdf", "url": ai["pdf"]["downloadLink"]})
    except (urllib.error.URLError, OSError, ValueError):
        pass
    m = re.search(r"(\d+)(?:st|nd|rd|th)\s+ed", f"{book['title']} {book['subtitle']}", re.I) or \
        re.search(r"\b(first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth)\s+edition", f"{book['title']} {book['subtitle']}", re.I)
    book["edition"] = m.group(0) if m else ""
    if not book["title"]:
        raise LookupError("I couldn't find a book with that ISBN. Double-check the digits, or search by the title instead.")
    return book


# ----------------------------------------------------------------------------- web search (filetype:pdf)
def search_queries(book):
    t = re.sub(r"\s*[:(].*$", "", book.get("title") or "").strip() or book.get("title", "")
    last = (book.get("authors") or [""])[0].split()[-1:] or [""]
    qs = [f'"{t}" {last[0]} filetype:pdf'.replace("  ", " ").strip()]
    if book.get("edition"):
        qs.insert(0, f'"{t}" {book["edition"]} filetype:pdf')
    if book.get("isbn"):
        qs.append(f'{book["isbn"]} filetype:pdf')
    return qs


def google_url(q):
    return "https://www.google.com/search?q=" + urllib.parse.quote_plus(q)


def ddg(q, limit=12):
    data = urllib.parse.urlencode({"q": q}).encode()
    req = urllib.request.Request("https://html.duckduckgo.com/html/", data=data, headers=UA)
    with urllib.request.urlopen(req, timeout=20) as r:
        page = r.read().decode("utf-8", "replace")
    out = []
    for m in re.finditer(r'class="result__a" href="([^"]+)"[^>]*>(.*?)</a>(.*?)(?=class="result__a"|$)', page, re.S):
        url = html.unescape(m.group(1))
        if "duckduckgo.com/l/?" in url:  # redirect link: the real address is in uddg=
            url = urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get("uddg", [url])[0]
        if url.startswith("//"):
            url = "https:" + url
        if "duckduckgo.com/y.js" in url:  # ads
            continue
        snip = re.search(r'class="result__snippet"[^>]*>(.*?)</a>', m.group(3), re.S)
        clean = lambda s: html.unescape(re.sub(r"<[^>]+>", "", s or "")).strip()
        out.append({"title": clean(m.group(2)), "url": url, "site": urllib.parse.urlparse(url).netloc.replace("www.", ""),
                    "snippet": clean(snip.group(1)) if snip else "", "pdf": url.lower().split("?")[0].endswith(".pdf")})
        if len(out) >= limit:
            break
    return out


def web_search(book):
    seen, results, errors = set(), [], []
    for q in search_queries(book):
        try:
            for r in ddg(q):
                if r["url"] not in seen:
                    seen.add(r["url"])
                    r["query"] = q
                    results.append(r)
        except (urllib.error.URLError, OSError) as e:
            errors.append(str(e))
    words = set(re.findall(r"[a-z0-9]{3,}", (book.get("title") or "").lower()))

    def score(r):
        hay = (r["title"] + " " + r["url"]).lower()
        return (r["pdf"], sum(w in hay for w in words), bool(book.get("isbn")) and book["isbn"] in hay)
    results.sort(key=score, reverse=True)
    return {"results": results[:20], "queries": search_queries(book), "google": google_url(search_queries(book)[0]),
            "error": "; ".join(errors) if errors and not results else ""}


# ----------------------------------------------------------------------------- download + check
def start_download(url, pending_dir, book):
    if not re.match(r"https?://", url or ""):
        raise ValueError("That isn't a web link.")
    jid = uuid.uuid4().hex[:12]
    JOBS[jid] = {"id": jid, "state": "downloading", "got": 0, "total": 0, "url": url, "book": book}
    threading.Thread(target=_download, args=(jid, url, Path(pending_dir)), daemon=True).start()
    return JOBS[jid]


def _download(jid, url, pending_dir):
    job = JOBS[jid]
    dest = pending_dir / f"{jid}.pdf"
    try:
        pending_dir.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=40) as r:
            job["total"] = int(r.headers.get("Content-Length") or 0)
            if job["total"] > MAX_BYTES:
                raise ValueError("That file is over 400 MB, which is too big to be one textbook.")
            first = r.read(1024)
            if b"%PDF" not in first[:1024]:
                kind = r.headers.get("Content-Type", "").split(";")[0] or "something else"
                raise ValueError(f"That link opens a web page ({kind}), not the PDF itself. Try another result, "
                                 "or open it in the browser and download it from there.")
            with open(dest, "wb") as f:
                f.write(first)
                job["got"] = len(first)
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
                    job["got"] += len(chunk)
                    if job["got"] > MAX_BYTES:
                        raise ValueError("That file is over 400 MB, which is too big to be one textbook.")
                    if job.get("cancel"):
                        raise ValueError("Cancelled.")
        job.update(check(dest, job["book"]), path=str(dest), state="done")
    except Exception as e:
        try:
            dest.unlink()
        except OSError:
            pass
        msg = str(e)
        if isinstance(e, urllib.error.HTTPError):
            msg = f"The site refused the download ({e.code}). Try another result."
        elif isinstance(e, (urllib.error.URLError, OSError)) and not isinstance(e, ValueError):
            msg = f"Couldn't download it: {e}"
        job.update(state="error", error=msg)


def page_count(data):
    counts = [int(x) for x in re.findall(rb"/Type\s*/Pages\b[^>]*?/Count\s+(\d+)", data)]
    counts += [int(x) for x in re.findall(rb"/Count\s+(\d+)[^>]*?/Type\s*/Pages\b", data)]
    return max(counts) if counts else len(re.findall(rb"/Type\s*/Page\b(?!s)", data)) or None


def _pdf_str(b):
    """PDF string bytes -> text (UTF-16 with a BOM, or Latin-1)."""
    if b.startswith(b"\xfe\xff"):
        return b[2:].decode("utf-16-be", "replace")
    return b.decode("latin-1", "replace")


def _meta(path, size):
    """The head and tail of the file plus its small compressed objects (where modern PDFs keep the title and the
    page tree). Bounded so a 300 MB book still takes well under a second."""
    with open(path, "rb") as f:
        head = f.read(3_000_000)
        f.seek(max(len(head), size - 2_000_000))
        tail = f.read()
    extra, budget = [], 4_000_000
    for part in (head, tail):
        for m in re.finditer(rb"(?<!end)stream\r?\n(.*?)endstream", part, re.S):
            if len(m.group(1)) > 400_000:
                continue
            try:
                raw = zlib.decompressobj().decompress(m.group(1))
            except zlib.error:
                continue
            if b"/Pages" in raw or b"/Title" in raw or b"dc:title" in raw:
                extra.append(raw)
                budget -= len(raw)
                if budget <= 0:
                    break
    return head, head + tail + b"".join(extra)


def check(path, book):
    """Read the start of the PDF and compare it with the book's details. The student makes the final call."""
    size = Path(path).stat().st_size
    head, meta = _meta(path, size)
    text = filetext.pdf_text(path, limit=20000, max_bytes=3_000_000)[:20000]
    meta_title = ""
    m = re.search(rb"<dc:title>.*?<rdf:li[^>]*>(.*?)</rdf:li>", meta, re.S)
    if m:
        meta_title = m.group(1).decode("utf-8", "replace")
    else:
        for t in re.findall(rb"/Title\s*\(((?:\.|[^\)]){3,300})\)", meta):
            t = _pdf_str(t).strip()
            if t and not re.match(r"(?i)layer|untitled|microsoft|document\d*$", t):
                meta_title = t
                break
    meta_title = html.unescape(meta_title).strip()
    low = (text + " " + meta_title).lower()
    flat = re.sub(r"[^0-9x]", "", low)
    words = [w for w in re.findall(r"[a-z0-9]{3,}", (book.get("title") or "").lower()) if w not in ("the", "and", "for", "with")]
    found_words = [w for w in words if w in low]
    title_ok = bool(words) and len(found_words) >= max(1, len(words) * 2 // 3)
    authors = [a.split()[-1] for a in book.get("authors") or [] if a.split()]
    found_auth = [a for a in authors if a.lower() in low]
    isbn_hit = book.get("isbn", "") in flat or bool(book.get("isbn10") and book["isbn10"].lower() in flat)
    signs = []
    if meta_title:
        signs.append(f"{'✅' if title_ok else '⚠️'} The PDF calls itself “{meta_title[:120]}”")
    if isbn_hit:
        signs.append("✅ The ISBN is printed inside it, so it's this exact edition.")
    if words and not (meta_title and title_ok):
        signs.append(f"{'✅' if title_ok else '⚠️'} Title words found: {len(found_words)} of {len(words)}")
    if authors and text:
        signs.append(f"{'✅' if found_auth else '⚠️'} Author names found: {', '.join(found_auth) or 'none'}")
    if not text:
        signs.append("⚠️ I can't read the words on its pages (the PDF's font is coded, or the pages are scans). Open it and look at the cover yourself.")
    pages = page_count(meta)
    if pages and book.get("pages") and abs(pages - book["pages"]) > max(60, book["pages"] * 0.25):
        signs.append(f"⚠️ It has {pages} pages, but the book has about {book['pages']}. It may be one chapter, or a different edition.")
    elif pages and book.get("pages"):
        signs.append(f"✅ {pages} pages (the book has about {book['pages']})")
    short = bool(pages and book.get("pages") and pages < book["pages"] * 0.6)
    if isbn_hit or (title_ok and (found_auth or not authors or not text) and not short):
        verdict = "likely"
    elif found_words or not text:
        verdict = "unsure"
    else:
        verdict = "unlikely"
    return {"pages": pages, "size": size, "pdf_title": meta_title[:160], "signs": signs, "verdict": verdict,
            "preview": re.sub(r"\s+", " ", text[:900]).strip()}


def safe_title(book):
    t = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", f"{book.get('title', 'Textbook')}{' (' + book['edition'] + ')' if book.get('edition') and book['edition'].lower() not in book.get('title', '').lower() else ''}")
    return (t.strip(" .") or "Textbook")[:120]


def keep(jid, dest_dir):
    job = JOBS.get(jid)
    if not job or job.get("state") != "done":
        raise LookupError("That download isn't ready (or was already handled).")
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    name = safe_title(job["book"])
    dest = dest_dir / f"{name}.pdf"
    n = 2
    while dest.exists():
        dest = dest_dir / f"{name} ({n}).pdf"
        n += 1
    shutil.move(job["path"], dest)
    JOBS.pop(jid, None)
    return str(dest)


def discard(jid):
    job = JOBS.pop(jid, None)
    if not job:
        return
    job["cancel"] = True
    if job.get("path"):
        try:
            Path(job["path"]).unlink()
        except OSError:
            pass


def clear_pending(pending_dir):
    shutil.rmtree(pending_dir, ignore_errors=True)
