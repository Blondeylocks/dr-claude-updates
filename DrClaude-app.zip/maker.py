"""
Study files the tutor makes on request, posted right into the chat: a web page (.html), a printable sheet (.pdf),
an animation (.gif), something to listen to (.mp3) or a narrated video (.mp4).

The tutor writes a ```make block (see MAKE_FMT); make(spec, out_dir) builds the file with what Windows already has:
    html  saved as is (wrapped in a clean page if it's only a fragment)
    pdf   Edge prints the page (msedge --headless --print-to-pdf)
    gif   each frame -> a slide -> Edge screenshot -> this file's own GIF encoder
    mp3   Windows voices (System.Speech) -> Windows' MP3 encoder        (media_tools.ps1)
    mp4   slides + one narration clip per slide -> Windows' video editor (media_tools.ps1)
Standard library only.
"""
import html
import json
import re
import shutil
import struct
import subprocess
import tempfile
import threading
import wave
import zlib
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
PS1 = APP_DIR / "media_tools.ps1"
TYPES = {"html": ".html", "pdf": ".pdf", "gif": ".gif", "mp3": ".mp3", "mp4": ".mp4"}
NOWIN = 0x08000000  # CREATE_NO_WINDOW
_edge_lock = threading.Lock()

MAKE_FMT = """```make
type: html | pdf | gif | mp3 | mp4
title: <short title, e.g. "Stacks: push and pop">
<then the content, by type:>
html: a complete, self-contained web page (inline CSS/JS, no outside links): an interactive demo, a practice quiz that checks answers, a visual explainer
pdf:  the sheet as simple HTML (h1/h2, p, ul, table, pre): a cheat sheet, worked examples, a practice set with the answer key on the last page
gif / mp4: one frame per step, each starting with a line "--- <caption>", then a big text or ASCII picture for that step;
      for mp4 add a line "say: <what the narrator says>" in each frame (else the caption is read)
mp3:  the script to read aloud, written for the ear (short sentences, no symbols or tables)
```"""


def parse(block):
    """```make block text -> {"type", "title", "body", "frames": [{"caption", "say", "text"}]} or None."""
    lines = (block or "").replace("\r\n", "\n").split("\n")
    spec = {"type": "", "title": "", "body": "", "frames": []}
    i = 0
    while i < len(lines):
        m = re.match(r"^\s*(type|title)\s*:\s*(.*)$", lines[i], re.I)
        if not m:
            if lines[i].strip():
                break
            i += 1
            continue
        spec[m.group(1).lower()] = m.group(2).strip().strip('"')
        i += 1
    spec["type"] = spec["type"].lower().lstrip(".").split()[0] if spec["type"] else ""
    if spec["type"] not in TYPES:
        return None
    body = "\n".join(lines[i:]).strip()
    spec["body"] = body
    if spec["type"] in ("gif", "mp4"):
        cur = None
        for l in lines[i:]:
            m = re.match(r"^\s*---\s*(.*)$", l)
            if m:
                cur = {"caption": m.group(1).strip(), "say": "", "text": []}
                spec["frames"].append(cur)
            elif cur is not None:
                s = re.match(r"^\s*say\s*:\s*(.*)$", l, re.I)
                if s:
                    cur["say"] = (cur["say"] + " " + s.group(1)).strip()
                else:
                    cur["text"].append(l)
        for f in spec["frames"]:
            f["text"] = "\n".join(f["text"]).strip("\n")
        spec["frames"] = spec["frames"][:24]
        if not spec["frames"]:
            spec["frames"] = [{"caption": spec["title"], "say": "", "text": body}]
    spec["title"] = spec["title"][:90] or {"html": "Study page", "pdf": "Study sheet", "gif": "Animation",
                                           "mp3": "Listen", "mp4": "Video"}[spec["type"]]
    return spec


def safe_name(s):
    return (re.sub(r"\s+", " ", re.sub(r'[<>:"/\\|?*\x00-\x1f]+', " ", s)).strip(" .")[:70]) or "file"


# ----------------------------------------------------------------------------- pages
PAGE_CSS = """*{box-sizing:border-box}body{font:16px/1.55 "Segoe UI",system-ui,sans-serif;color:#1d2433;background:#fff;max-width:860px;margin:0 auto;padding:28px}
h1{font-size:28px;margin:0 0 12px;color:#14213d}h2{font-size:20px;margin:22px 0 8px;color:#1f3a68;border-bottom:2px solid #e3e8f2;padding-bottom:4px}
table{border-collapse:collapse;width:100%;margin:10px 0}th,td{border:1px solid #d5dbe7;padding:6px 9px;text-align:left}th{background:#eef2f9}
pre,code{font-family:Consolas,"Cascadia Mono",monospace}pre{background:#f4f6fb;border:1px solid #e1e6f0;border-radius:8px;padding:10px 12px;overflow:auto}
.answer,.key{page-break-before:always}@media print{body{padding:0}h2{page-break-after:avoid}pre,table{page-break-inside:avoid}}"""


def as_page(body, title):
    if re.search(r"<html[\s>]", body, re.I):
        return body
    if not re.search(r"<(p|h\d|div|ul|ol|table|pre|section|body)[\s>]", body, re.I):
        body = "".join(f"<p>{html.escape(p)}</p>" for p in re.split(r"\n\s*\n", body) if p.strip())
    head = "" if re.search(r"<h1[\s>]", body, re.I) else f"<h1>{html.escape(title)}</h1>"
    return (f'<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            f"<title>{html.escape(title)}</title><style>{PAGE_CSS}</style></head><body>{head}{body}</body></html>")


SLIDE = """<!doctype html><html><head><meta charset="utf-8"><style>
*{{box-sizing:border-box;margin:0}}html,body{{width:{w}px;height:{h}px;overflow:hidden}}
body{{background:#fbfcff;font-family:"Segoe UI",system-ui,sans-serif;color:#17203a;display:flex;flex-direction:column}}
.top{{background:#1f3a68;color:#fff;padding:{p1}px {p2}px;font-size:{fs1}px;font-weight:600;display:flex;justify-content:space-between}}
.cap{{padding:{p1}px {p2}px 0;font-size:{fs2}px;font-weight:600;line-height:1.3}}
.pic{{flex:1;display:flex;align-items:center;justify-content:center;padding:{p1}px {p2}px}}
pre{{font-family:Consolas,"Cascadia Mono",monospace;font-size:{fs3}px;line-height:1.25;background:#fff;border:2px solid #dfe5f1;border-radius:12px;padding:14px 20px;white-space:pre}}
.txt{{font-size:{fs2}px;line-height:1.45;max-width:90%}}
</style></head><body><div class="top"><span>{title}</span><span>{n}</span></div><div class="cap">{cap}</div>
<div class="pic">{pic}</div><script>
var p=document.querySelector('pre');if(p){{var box=document.querySelector('.pic'),s=parseFloat(getComputedStyle(p).fontSize);
while(s>9&&(p.scrollWidth>box.clientWidth-20||p.scrollHeight>box.clientHeight-10)){{s-=1;p.style.fontSize=s+'px';}}}}
</script></body></html>"""


def slide_html(title, frame, k, n, w, h):
    sc = w / 960
    text = frame["text"]
    looks_pic = bool(re.search(r"[\[\]|_/\\<>=\-+*#]{2}|\n.*\n", text)) or len(text) < 60
    pic = (f"<pre>{html.escape(text)}</pre>" if looks_pic else f'<div class="txt">{html.escape(text)}</div>') if text.strip() else ""
    return SLIDE.format(w=w, h=h, p1=int(14 * sc), p2=int(26 * sc), fs1=int(20 * sc), fs2=int(28 * sc), fs3=int(44 * sc),
                        title=html.escape(title), n=f"{k + 1} / {n}", cap=html.escape(frame["caption"]), pic=pic)


# ----------------------------------------------------------------------------- Edge
def _edge(edge, args, timeout=60):
    prof = Path(tempfile.mkdtemp(prefix="drc-edge-"))
    try:
        cmd = [edge, "--headless", "--disable-gpu", "--hide-scrollbars", "--no-first-run", "--no-default-browser-check",
               "--disable-extensions", f"--user-data-dir={prof}", "--run-all-compositor-stages-before-draw",
               "--virtual-time-budget=1500"] + args
        subprocess.run(cmd, capture_output=True, timeout=timeout, creationflags=NOWIN)
    finally:
        shutil.rmtree(prof, ignore_errors=True)


def edge_pdf(edge, page, out):
    _edge(edge, ["--no-pdf-header-footer", f"--print-to-pdf={out}", Path(page).as_uri()], timeout=90)
    if not Path(out).is_file() or Path(out).stat().st_size < 500:
        raise RuntimeError("Edge couldn't print the PDF.")


def edge_shots(edge, pages, size):
    w, h = size
    outs = [Path(p).with_suffix(".png") for p in pages]

    def one(pair):
        page, out = pair
        _edge(edge, [f"--window-size={w},{h}", f"--screenshot={out}", Path(page).as_uri()])
        if not out.is_file():
            raise RuntimeError("Edge couldn't draw a frame.")
    with ThreadPoolExecutor(max_workers=4) as ex:
        list(ex.map(one, zip(pages, outs)))
    return outs


# ----------------------------------------------------------------------------- PNG in, GIF out (no libraries)
def read_png(path):
    """-> (width, height, bytes RGB). Handles the 8-bit RGB/RGBA PNGs Edge writes."""
    data = Path(path).read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("not a PNG")
    pos, idat, w = 8, [], 0
    while pos < len(data):
        n, typ = struct.unpack(">I4s", data[pos:pos + 8])
        chunk = data[pos + 8:pos + 8 + n]
        if typ == b"IHDR":
            w, h, depth, ctype, _, _, inter = struct.unpack(">IIBBBBB", chunk)
            if depth != 8 or ctype not in (2, 6) or inter:
                raise ValueError("unsupported PNG")
            bpp = 3 if ctype == 2 else 4
        elif typ == b"IDAT":
            idat.append(chunk)
        elif typ == b"IEND":
            break
        pos += 12 + n
    raw = zlib.decompress(b"".join(idat))
    stride = w * bpp
    prev = bytearray(stride)
    rows = []
    for y in range(h):
        f = raw[y * (stride + 1)]
        line = bytearray(raw[y * (stride + 1) + 1:(y + 1) * (stride + 1)])
        if f == 1:
            for i in range(bpp, stride):
                line[i] = (line[i] + line[i - bpp]) & 255
        elif f == 2:
            line = bytearray((a + b) & 255 for a, b in zip(line, prev))
        elif f == 3:
            for i in range(stride):
                line[i] = (line[i] + ((line[i - bpp] if i >= bpp else 0) + prev[i]) // 2) & 255
        elif f == 4:
            for i in range(stride):
                a = line[i - bpp] if i >= bpp else 0
                b = prev[i]
                c = prev[i - bpp] if i >= bpp else 0
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                line[i] = (line[i] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 255
        rows.append(bytes(line))
        prev = line
    px = b"".join(rows)
    if bpp == 4:
        px = bytes(b for i, b in enumerate(px) if i % 4 != 3)
    return w, h, px


def _lzw(indices, min_size=8):
    clear, eoi = 1 << min_size, (1 << min_size) + 1
    size, nxt = min_size + 1, eoi + 1
    table = {}
    out = bytearray()
    buf = nb = 0

    def emit(c):
        nonlocal buf, nb
        buf |= c << nb
        nb += size
        while nb >= 8:
            out.append(buf & 255)
            buf >>= 8
            nb -= 8
    emit(clear)
    prefix = indices[0]
    for k in indices[1:]:
        key = (prefix << 8) | k
        c = table.get(key)
        if c is not None:
            prefix = c
            continue
        emit(prefix)
        if nxt == 4096:
            emit(clear)
            table.clear()
            size, nxt = min_size + 1, eoi + 1
        else:
            if nxt >= (1 << size):
                size += 1
            table[key] = nxt
            nxt += 1
        prefix = k
    emit(prefix)
    emit(eoi)
    if nb:
        out.append(buf & 255)
    return bytes(out)


def write_gif(frames, delays, out):
    """frames: [(w, h, rgb bytes)] all the same size; delays in seconds."""
    w, h = frames[0][0], frames[0][1]
    # one shared palette: the 255 most common colors (slides are mostly a few flat colors + text edges)
    count = {}
    for _, _, px in frames:
        for i in range(0, len(px), 3 * 7):  # sample
            key = ((px[i] >> 3) << 10) | ((px[i + 1] >> 3) << 5) | (px[i + 2] >> 3)
            count[key] = count.get(key, 0) + 1
    pal = sorted(count, key=count.get, reverse=True)[:256]
    cols = [((k >> 10) << 3 | 4, ((k >> 5) & 31) << 3 | 4, (k & 31) << 3 | 4) for k in pal]
    cols += [(0, 0, 0)] * (256 - len(cols))
    exact = {k: i for i, k in enumerate(pal)}
    near = {}

    def idx(key):
        i = exact.get(key)
        if i is not None:
            return i
        i = near.get(key)
        if i is None:
            r, g, b = (key >> 10) << 3, ((key >> 5) & 31) << 3, (key & 31) << 3
            i = min(range(len(pal)), key=lambda j: (cols[j][0] - r) ** 2 * 3 + (cols[j][1] - g) ** 2 * 4 + (cols[j][2] - b) ** 2 * 2)
            near[key] = i
        return i
    o = bytearray(b"GIF89a" + struct.pack("<HHBBB", w, h, 0xF7, 0, 0))
    for c in cols:
        o += bytes(c)
    o += b"\x21\xFF\x0BNETSCAPE2.0\x03\x01\x00\x00\x00"  # loop forever
    for (fw, fh, px), d in zip(frames, delays):
        ind = bytes(idx(((px[i] >> 3) << 10) | ((px[i + 1] >> 3) << 5) | (px[i + 2] >> 3)) for i in range(0, len(px), 3))
        o += b"\x21\xF9\x04\x04" + struct.pack("<H", max(2, int(d * 100))) + b"\x00\x00"
        o += b"\x2C" + struct.pack("<HHHHB", 0, 0, fw, fh, 0) + b"\x08"
        data = _lzw(ind)
        for i in range(0, len(data), 255):
            part = data[i:i + 255]
            o += bytes([len(part)]) + part
        o += b"\x00"
    o += b"\x3B"
    Path(out).write_bytes(bytes(o))


# ----------------------------------------------------------------------------- speech + video (media_tools.ps1)
def _ps(*args, timeout=300):
    r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(PS1), *map(str, args)],
                       capture_output=True, text=True, timeout=timeout, creationflags=NOWIN)
    if r.returncode != 0 or "ok" not in (r.stdout or ""):
        raise RuntimeError(((r.stderr or r.stdout or "").strip().splitlines() or ["Windows media tools failed"])[0][:200])


def speak_many(items, work):
    """items: [(text, wav_path)] -> writes the wavs (one PowerShell start for all)."""
    plan = work / "speak.json"
    plan.write_text(json.dumps([{"text": t, "out": str(o)} for t, o in items]), encoding="utf-8")
    _ps("speakmany", plan)


def wav_seconds(p):
    try:
        with wave.open(str(p)) as w:
            return w.getnframes() / float(w.getframerate())
    except (OSError, wave.Error, EOFError):
        return 0.0


def for_ear(s):
    s = re.sub(r"[`*_#>|]", " ", s)
    s = s.replace("×", " times ").replace("÷", " divided by ").replace("=", " equals ").replace("²", " squared ").replace("√", " square root of ")
    return re.sub(r"\s+", " ", s).strip()


# ----------------------------------------------------------------------------- main
def make(spec, out_dir, edge=""):
    """-> Path of the finished file (raises RuntimeError with a plain reason)."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    t = spec["type"]
    name = safe_name(spec["title"])
    out = out_dir / f"{name}{TYPES[t]}"
    n = 2
    while out.exists():
        out, n = out_dir / f"{name} ({n}){TYPES[t]}", n + 1
    work = Path(tempfile.mkdtemp(prefix="drc-make-"))
    try:
        if t == "html":
            out.write_text(as_page(spec["body"], spec["title"]), encoding="utf-8")
        elif t == "pdf":
            if not edge:
                raise RuntimeError("Microsoft Edge is needed to make PDFs.")
            page = work / "page.html"
            page.write_text(as_page(spec["body"], spec["title"]), encoding="utf-8")
            with _edge_lock:
                edge_pdf(edge, page, out)
        elif t == "mp3":
            text = for_ear(spec["body"])[:20000]
            if not text:
                raise RuntimeError("There was nothing to read aloud.")
            speak_many([(text, work / "a.wav")], work)
            _ps("mp3", work / "a.wav", out)
        elif t in ("gif", "mp4"):
            if not edge:
                raise RuntimeError("Microsoft Edge is needed to draw the frames.")
            size = (960, 540) if t == "gif" else (1280, 720)
            fr = spec["frames"]
            pages = []
            for k, f in enumerate(fr):
                p = work / f"frame{k:02d}.html"
                p.write_text(slide_html(spec["title"], f, k, len(fr), *size), encoding="utf-8")
                pages.append(p)
            with _edge_lock:
                shots = edge_shots(edge, pages, size)
            if t == "gif":
                imgs = [read_png(s) for s in shots]
                delays = [min(8.0, max(2.2, 0.32 * len((f["caption"] + " " + f["text"][:120]).split()))) for f in fr]
                write_gif(imgs, delays, out)
            else:
                voice = [(for_ear(f["say"] or f["caption"]), work / f"say{k:02d}.wav") for k, f in enumerate(fr)]
                speak_many([v for v in voice if v[0]], work)
                plan = [{"image": str(s), "seconds": round(max(2.5, wav_seconds(w) + 0.9), 2), "audio": str(w) if txt else ""}
                        for s, (txt, w) in zip(shots, voice)]
                (work / "plan.json").write_text(json.dumps(plan), encoding="utf-8")
                _ps("video", work / "plan.json", out, timeout=600)
        if not out.is_file() or out.stat().st_size == 0:
            raise RuntimeError("the file came out empty")
        return out
    except subprocess.TimeoutExpired:
        raise RuntimeError("it took too long")
    finally:
        shutil.rmtree(work, ignore_errors=True)
