# Dr. Claude media helper (Windows' own speech + video tools, nothing to install).
#   media_tools.ps1 speak  <text-file> <out.wav>              text -> spoken audio (Windows voices)
#   media_tools.ps1 speakmany <plan.json>                    [{"text": "...", "out": "C:\...\a.wav"}, ...] in one go
#   media_tools.ps1 mp3    <in.wav> <out.mp3>                 wav -> mp3 (Windows' MP3 encoder)
#   media_tools.ps1 video  <plan.json> <out.mp4>              pictures (+ narration per picture) -> mp4
#        plan.json: [{"image": "C:\\...\\frame1.png", "seconds": 4.5, "audio": "C:\\...\\frame1.wav" or ""}, ...]
param([string]$cmd, [string]$a, [string]$b)
$ErrorActionPreference = 'Stop'

function Await($op, [Type]$type) {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $m = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
    $t = $m.MakeGenericMethod($type).Invoke($null, @($op))
    $t.Wait() | Out-Null
    $t.Result
}
function AwaitAction($op) {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $m = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' } | Select-Object -First 1
    $m.Invoke($null, @($op)).Wait() | Out-Null
}
function AwaitProgress($op, [Type]$type, [Type]$prog) {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $m = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperationWithProgress`2' } | Select-Object -First 1
    $t = $m.MakeGenericMethod($type, $prog).Invoke($null, @($op))
    $t.Wait() | Out-Null
    $t.Result
}
function GetFile([string]$path) {
    $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
    Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
}
function NewFile([string]$path) {
    $null = [Windows.Storage.StorageFolder, Windows.Storage, ContentType = WindowsRuntime]
    if (Test-Path $path) { Remove-Item $path -Force }
    $dir = Await ([Windows.Storage.StorageFolder]::GetFolderFromPathAsync((Split-Path $path))) ([Windows.Storage.StorageFolder])
    Await ($dir.CreateFileAsync((Split-Path $path -Leaf), [Windows.Storage.CreationCollisionOption]::ReplaceExisting)) ([Windows.Storage.StorageFile])
}

switch ($cmd) {
    'speak' {
        Add-Type -AssemblyName System.Speech
        $s = New-Object System.Speech.Synthesis.SpeechSynthesizer
        $s.Rate = 0
        $s.SetOutputToWaveFile($b)
        $s.Speak([IO.File]::ReadAllText($a, [Text.Encoding]::UTF8))
        $s.Dispose()
    }
    'speakmany' {
        Add-Type -AssemblyName System.Speech
        $s = New-Object System.Speech.Synthesis.SpeechSynthesizer
        $s.Rate = 0
        foreach ($it in (Get-Content $a -Raw -Encoding UTF8 | ConvertFrom-Json)) {
            $s.SetOutputToWaveFile($it.out)
            $s.Speak([string]$it.text)
        }
        $s.SetOutputToNull()
        $s.Dispose()
    }
    'mp3' {
        $null = [Windows.Media.Transcoding.MediaTranscoder, Windows.Media.Transcoding, ContentType = WindowsRuntime]
        $null = [Windows.Media.MediaProperties.MediaEncodingProfile, Windows.Media.MediaProperties, ContentType = WindowsRuntime]
        $src = GetFile $a
        $dst = NewFile $b
        $prof = [Windows.Media.MediaProperties.MediaEncodingProfile]::CreateMp3([Windows.Media.MediaProperties.AudioEncodingQuality]::Medium)
        $tr = New-Object Windows.Media.Transcoding.MediaTranscoder
        $prep = Await ($tr.PrepareFileTranscodeAsync($src, $dst, $prof)) ([Windows.Media.Transcoding.PrepareTranscodeResult])
        if (-not $prep.CanTranscode) { throw "can't make mp3: $($prep.FailureReason)" }
        Add-Type -AssemblyName System.Runtime.WindowsRuntime
        $m = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
            $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncActionWithProgress`1' } | Select-Object -First 1
        $m.MakeGenericMethod([double]).Invoke($null, @($prep.TranscodeAsync())).Wait() | Out-Null
    }
    'video' {
        $null = [Windows.Media.Editing.MediaComposition, Windows.Media.Editing, ContentType = WindowsRuntime]
        $null = [Windows.Media.Editing.MediaClip, Windows.Media.Editing, ContentType = WindowsRuntime]
        $null = [Windows.Media.Editing.BackgroundAudioTrack, Windows.Media.Editing, ContentType = WindowsRuntime]
        $null = [Windows.Media.Transcoding.TranscodeFailureReason, Windows.Media.Transcoding, ContentType = WindowsRuntime]
        $plan = Get-Content $a -Raw -Encoding UTF8 | ConvertFrom-Json
        $comp = New-Object Windows.Media.Editing.MediaComposition
        $at = [TimeSpan]::Zero
        foreach ($f in $plan) {
            $dur = [TimeSpan]::FromSeconds([double]$f.seconds)
            $clip = Await ([Windows.Media.Editing.MediaClip]::CreateFromImageFileAsync((GetFile $f.image), $dur)) ([Windows.Media.Editing.MediaClip])
            [System.Collections.Generic.ICollection[Windows.Media.Editing.MediaClip]].GetMethod('Add').Invoke($comp.Clips, @($clip))
            if ($f.audio) {
                $tr = Await ([Windows.Media.Editing.BackgroundAudioTrack]::CreateFromFileAsync((GetFile $f.audio))) ([Windows.Media.Editing.BackgroundAudioTrack])
                $tr.Delay = $at + [TimeSpan]::FromMilliseconds(300)
                [System.Collections.Generic.ICollection[Windows.Media.Editing.BackgroundAudioTrack]].GetMethod('Add').Invoke($comp.BackgroundAudioTracks, @($tr))
            }
            $at = $at + $dur
        }
        $dst = NewFile $b
        $null = [Windows.Media.MediaProperties.MediaEncodingProfile, Windows.Media.MediaProperties, ContentType = WindowsRuntime]
        $prof = [Windows.Media.MediaProperties.MediaEncodingProfile]::CreateMp4([Windows.Media.MediaProperties.VideoEncodingQuality]::HD720p)
        $prof.Video.Width = 1280; $prof.Video.Height = 720; $prof.Video.Bitrate = 900000; $prof.Video.FrameRate.Numerator = 15; $prof.Video.FrameRate.Denominator = 1
        $r = AwaitProgress ($comp.RenderToFileAsync($dst, [Windows.Media.Editing.MediaTrimmingPreference]::Fast, $prof)) ([Windows.Media.Transcoding.TranscodeFailureReason]) ([double])
        if ("$r" -ne 'None') { throw "video failed: $r" }
    }
    default { throw "unknown command $cmd" }
}
'ok'
