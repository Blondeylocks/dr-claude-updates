"""
Plain-text extraction from course files with the standard library only (for brains that can't open files).
    .docx  word/document.xml <w:t>     .pptx  ppt/slides/slideN.xml <a:t>     .txt/.md/.csv  as is
    .html  tags stripped                .pdf   FlateDecode streams -> Tj/TJ text operators (works for most
                                               text PDFs; scanned PDFs have no text and return "")
Results are cached by path + modified time.
"""
import html
import json
import re
import zipfile
import zlib
from pathlib import Path

TEXT_EXT = {".txt", ".md", ".csv", ".py", ".c", ".cpp", ".h", ".java", ".m", ".tex"}


def _xml_text(xml, tag):
    parts = re.findall(rf"<{tag}(?:\s[^>]*)?>([^<]*)</{tag}>", xml)
    return html.unescape(" ".join(parts))


def docx_text(p):
    with zipfile.ZipFile(p) as z:
        xml = z.read("word/document.xml").decode("utf-8", "replace")
    xml = re.sub(r"</w:p>", "\n", xml)
    return "\n".join(_xml_text(line, "w:t") for line in xml.split("\n")).strip()


def pptx_text(p):
    out = []
    with zipfile.ZipFile(p) as z:
        slides = sorted((n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)),
                        key=lambda n: int(re.search(r"(\d+)", n).group(1)))
        for i, n in enumerate(slides, 1):
            xml = z.read(n).decode("utf-8", "replace").replace("</a:p>", "\n")
            txt = "\n".join(_xml_text(l, "a:t") for l in xml.split("\n") if "<a:t" in l)
            out.append(f"--- Slide {i} ---\n{txt.strip()}")
    return "\n".join(out)


def _pdf_string(s):
    s = re.sub(r"\\([nrtbf()\\])", lambda m: {"n": "\n", "r": "", "t": " ", "b": "", "f": "", "(": "(", ")": ")", "\\": "\\"}[m.group(1)], s)
    s = re.sub(r"\\(\d{1,3})", lambda m: chr(int(m.group(1), 8) % 256), s)
    return s


def pdf_text(p, limit=400000, max_bytes=6_000_000):
    """Only the first max_bytes are scanned: the regexes below hold Python's lock, so a whole 100 MB textbook
    would freeze the app, and the text that's used (the start of the file) is near the front anyway."""
    with open(p, "rb") as f:
        data = f.read(max_bytes)
    chunks = []
    # each match stops at the very next "endstream" (requiring a newline before it let some PDFs rescan to the end
    # of the file for every stream: minutes of frozen app on a big textbook)
    for m in re.finditer(rb"(?<!end)stream\r?\n(.*?)endstream", data, re.S):
        raw = m.group(1)
        try:
            raw = zlib.decompressobj().decompress(raw)  # tolerates the newline before endstream
        except zlib.error:
            pass
        if b"Tj" not in raw and b"TJ" not in raw:
            continue
        txt = raw.decode("latin-1", "replace")
        for bt in re.findall(r"BT(.*?)ET", txt, re.S):
            line = []
            for op in re.finditer(r"\((?:\\.|[^\\)])*\)\s*Tj|\[(?:.*?)\]\s*TJ|T\*|Td|TD|'", bt, re.S):
                tok = op.group(0)
                if tok.endswith("TJ"):
                    line.append("".join(_pdf_string(x) for x in re.findall(r"\(((?:\\.|[^\\)])*)\)", tok)))
                elif tok.endswith("Tj"):
                    line.append(_pdf_string(tok[1:tok.rfind(")")]))
                else:
                    line.append("\n")
            chunks.append("".join(line))
        if sum(len(c) for c in chunks) > limit:
            break
    text = "\n".join(chunks)
    # PDFs with custom font encodings come out as junk; keep only if mostly readable
    readable = sum(ch.isalnum() or ch.isspace() or ch in ".,;:()-+=/%" for ch in text)
    return re.sub(r"\n\s*\n+", "\n", text).strip() if text and readable / max(1, len(text)) > 0.8 else ""


def html_text(s):
    s = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", "", s)
    s = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</h\d>|</li>|</tr>", "\n", s)
    s = html.unescape(re.sub(r"<[^>]+>", "", s))
    return re.sub(r"\n\s*\n+", "\n\n", s).strip()


def extract(p):
    p = Path(p)
    ext = p.suffix.lower()
    try:
        if ext == ".docx":
            return docx_text(p)
        if ext == ".pptx":
            return pptx_text(p)
        if ext == ".pdf":
            return pdf_text(p)
        if ext in (".html", ".htm"):
            return html_text(p.read_text(encoding="utf-8", errors="replace"))
        if ext in TEXT_EXT:
            return p.read_text(encoding="utf-8", errors="replace")
    except (OSError, zipfile.BadZipFile, KeyError, ValueError):
        return ""
    return ""


class TextCache:
    def __init__(self, path):
        self.path = Path(path)
        try:
            self.d = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.d = {}

    def get(self, p, max_chars=8000):
        p = Path(p)
        try:
            key = f"{p}|{p.stat().st_mtime_ns}"
        except OSError:
            return ""
        if key not in self.d:
            self.d = {k: v for k, v in self.d.items() if not k.startswith(f"{p}|")}
            self.d[key] = extract(p)[:60000]
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                self.path.write_text(json.dumps(self.d), encoding="utf-8")
            except OSError:
                pass
        return self.d[key][:max_chars]
