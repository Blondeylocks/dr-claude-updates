"""
Dr. Claude updater. The app copies this file to <install>\\updater_run.py and starts it right before it exits.

    1. wait for the app (--pid) to close
    2. back up app\\ -> app_prev\\, then replace app\\ with update_staged\\app\\   (app\\data is never touched)
    3. start the new version and wait for its health ping (it reports its port in update_state.json)
    4. no ping in time -> stop it, put app_prev\\ back, start the old version again ("rolled_back")
Everything is logged to <install>\\updater.log.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

KEEP = {"data", "__pycache__"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pid", type=int, required=True)
    ap.add_argument("--install", required=True)
    ap.add_argument("--from", dest="from_v", default="")
    ap.add_argument("--launch", required=True)  # JSON list: the command that starts the app
    a = ap.parse_args()
    inst = Path(a.install)
    app, prev, staged = inst / "app", inst / "app_prev", inst / "update_staged"
    state_f = inst / "update_state.json"
    launch = json.loads(a.launch)
    timeout = float(os.environ.get("DRC_UPDATE_HEALTH_TIMEOUT") or 45)
    logf = open(inst / "updater.log", "a", encoding="utf-8")

    def log(msg):
        logf.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
        logf.flush()

    def state(**kw):
        state_f.write_text(json.dumps(kw, indent=1), encoding="utf-8")

    def replace_app(src):
        for p in app.iterdir():
            if p.name in KEEP:
                continue
            shutil.rmtree(p) if p.is_dir() else p.unlink()
        shutil.copytree(src, app, dirs_exist_ok=True, ignore=shutil.ignore_patterns("data", "__pycache__"))

    def start():
        flags = 0x00000008 | 0x00000200 if os.name == "nt" else 0
        return subprocess.Popen(launch, cwd=str(app), creationflags=flags, close_fds=True,
                                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def healthy(proc, want):
        end = time.time() + timeout
        while time.time() < end:
            if proc.poll() is not None:
                log(f"new version exited with code {proc.returncode}")
                return False
            try:
                st = json.loads(state_f.read_text(encoding="utf-8"))
                if st.get("status") == "started" and st.get("port"):
                    with urllib.request.urlopen(f"http://127.0.0.1:{st['port']}/api/ping", timeout=3) as r:
                        if json.loads(r.read()).get("version") == want:
                            return True
            except Exception:
                pass
            time.sleep(0.5)
        log("no health ping in time")
        return False

    try:
        log(f"updater started: waiting for pid {a.pid}")
        wait_for_exit(a.pid, 60)
        time.sleep(0.5)
        to_v = (staged / "app" / "VERSION").read_text(encoding="utf-8").strip()
        notes = (staged / "notes.txt").read_text(encoding="utf-8") if (staged / "notes.txt").exists() else ""
        log(f"updating {a.from_v} -> {to_v}")
        shutil.rmtree(prev, ignore_errors=True)
        shutil.copytree(app, prev, ignore=shutil.ignore_patterns("data", "__pycache__"))
        replace_app(staged / "app")
        state(status="testing", **{"from": a.from_v}, to=to_v, notes=notes, ts=time.time())
        proc = start()
        if healthy(proc, to_v):
            st = json.loads(state_f.read_text(encoding="utf-8"))
            st.update(status="ok", shown=False)
            state(**st)
            shutil.rmtree(staged, ignore_errors=True)
            log(f"updated to {to_v}")
            return
        # roll back
        subprocess.run(["taskkill", "/T", "/F", "/PID", str(proc.pid)], capture_output=True)
        time.sleep(1)
        replace_app(prev)
        shutil.rmtree(staged, ignore_errors=True)
        state(status="rolled_back", **{"from": a.from_v}, to=to_v, shown=False, ts=time.time())
        log(f"rolled back to {a.from_v}")
        start()
    except Exception as e:
        log(f"ERROR {e!r}")
        if prev.exists() and not (app / "dr_claude.py").exists():
            replace_app(prev)
            log("restored app_prev after error")
        try:
            start()
        except Exception:
            pass


def wait_for_exit(pid, timeout):
    if os.name == "nt":
        import ctypes
        h = ctypes.windll.kernel32.OpenProcess(0x00100000, False, pid)  # SYNCHRONIZE
        if h:
            ctypes.windll.kernel32.WaitForSingleObject(h, int(timeout * 1000))
            ctypes.windll.kernel32.CloseHandle(h)
        return
    end = time.time() + timeout
    while time.time() < end:
        try:
            os.kill(pid, 0)
        except OSError:
            return
        time.sleep(0.3)


if __name__ == "__main__":
    sys.exit(main())
