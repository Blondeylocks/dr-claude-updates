"""
Clip trimming: find the exact part of a YouTube video that answers the student's question.

    transcript(vid)        the video's captions with timestamps (YouTube's Android player API, the one that still hands
                           out caption links without a browser token). Cached in <data>\\transcripts\\<id>.json.
    best_window(segs, q)   slides over the transcript and scores each stretch by the question's words (rare words
                           count more than words the whole video repeats), then trims it to the part that talks
                           about them: start a few seconds early, stop a few seconds after the last mention.
    -> (start, end, confidence 0..1, excerpt). The app plays ONLY start..end (YouTube's embed start/end), so pressing
       ▶ lands right on the moment, and the excerpt lets the AI double-check it's really about the question.
Standard library only.
"""
import html
import json
import math
import re
import urllib.request
from pathlib import Path

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
      "Accept-Language": "en-US,en;q=0.9", "Cookie": "CONSENT=YES+1; SOCS=CAI"}
WEB_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"  # YouTube's public web key (the watch page's own key wins when found)
STOP = set("a an the of to in on for and or with how what why is are do does my i me it this that from by vs so we you "
           "they he she be was were will can just like okay ok now then here there these those let lets gonna going get got "
           "um uh yeah right really very also into about out up down over our your its at as if not no but all one two "
           "many much which who when where number called mean means meaning work works use used using make makes "
           "step steps explained explanation example examples tutorial video clip watch".split())
MIN_LEN, MAX_LEN, WINDOW = 25, 180, 90


def _get(url, data=None, headers=None, timeout=15):
    req = urllib.request.Request(url, data=data, headers={**UA, **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def stem(w):
    for suf in ("ations", "ation", "ings", "ing", "ies", "ied", "es", "ed", "ly", "s"):
        if len(w) > len(suf) + 3 and w.endswith(suf):
            return w[: -len(suf)] + ("y" if suf in ("ies", "ied") else "")
    return w


def terms(s):
    """Words that carry meaning, cut to a shared root: "inactive"/"inactivity" -> "inacti", "multiply"/"multiplication" -> "multip"."""
    return [stem(w)[:6] for w in re.findall(r"[a-z0-9]+", (s or "").lower()) if w not in STOP and len(w) > 1]


def transcript(vid, cache_dir):
    """-> [(start_sec, dur_sec, text), ...] or [] when the video has no captions."""
    cache = Path(cache_dir) / f"{vid}.json"
    try:
        return [tuple(x) for x in json.loads(cache.read_text(encoding="utf-8"))]
    except (OSError, ValueError):
        pass
    segs = []
    try:
        page = _get(f"https://www.youtube.com/watch?v={vid}&hl=en")
        m = re.search(r'"INNERTUBE_API_KEY":"([^"]+)"', page)
        key = m.group(1) if m else WEB_KEY
        body = json.dumps({"context": {"client": {"clientName": "ANDROID", "clientVersion": "20.10.38", "androidSdkVersion": 30, "hl": "en"}},
                           "videoId": vid}).encode()
        pj = json.loads(_get(f"https://www.youtube.com/youtubei/v1/player?key={key}", body, {"Content-Type": "application/json"}))
        tracks = ((pj.get("captions") or {}).get("playerCaptionsTracklistRenderer") or {}).get("captionTracks") or []
        en = [t for t in tracks if (t.get("languageCode") or "").startswith("en")]
        en.sort(key=lambda t: t.get("kind") == "asr")  # people-written captions first, auto-captions second
        if en:
            xml = _get(re.sub(r"&fmt=[^&]*", "", en[0]["baseUrl"]))
            for m in re.finditer(r'<text start="([\d.]+)"(?: dur="([\d.]+)")?[^>]*>(.*?)</text>', xml, re.S):
                t = html.unescape(html.unescape(re.sub(r"<[^>]+>", "", m.group(3)))).replace("\n", " ").strip()
                if t:
                    segs.append((float(m.group(1)), float(m.group(2) or 2), t))
    except Exception:
        return []
    try:
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps(segs), encoding="utf-8")
    except OSError:
        pass
    return segs


def best_window(segs, q, video_len=0):
    """-> (start, end, confidence, excerpt) for the stretch of the video that best matches q, or None."""
    qt = list(dict.fromkeys(terms(q)))
    if not segs or not qt:
        return None
    seg_terms = [set(terms(s[2])) for s in segs]
    n = len(segs)
    # rare words decide: a word in every other sentence (the video's overall topic) says little about WHERE
    weight = {w: 1.0 / math.sqrt(1 + sum(1 for st in seg_terms if w in st)) for w in qt}
    found_any = {w for w in qt if any(w in st for st in seg_terms)}
    if not found_any:
        return None
    total = sum(weight.values())
    top = max(weight.values())
    best = None
    j = 0
    for i in range(n):
        while j < n and segs[j][0] - segs[i][0] <= WINDOW:
            j += 1
        covered = set().union(*seg_terms[i:j]) & set(qt)
        if not covered:
            continue
        hits = sum(weight[w] for k in range(i, j) for w in seg_terms[k] & set(qt)) / top  # rare words count, filler doesn't
        # + a little for more mentions, + a little for coming earlier (the first real explanation beats a later recap)
        # sentences that use several of the words together are where it's actually being explained
        together = sum(len(seg_terms[k] & set(qt)) - 1 for k in range(i, j) if len(seg_terms[k] & set(qt)) > 1)
        score = (sum(weight[w] for w in covered) / total + 0.02 * min(hits, 10) + 0.04 * min(together, 5)
                 + 0.08 * (1 - segs[i][0] / (segs[-1][0] or 1)))
        if not best or score > best[0]:
            best = (score, i, j, covered)
    score, i, j, covered = best
    idx = [k for k in range(i, j) if seg_terms[k] & set(qt)]
    start = max(0.0, segs[idx[0]][0] - 4)
    end = segs[idx[-1]][0] + segs[idx[-1]][1] + 10
    if end - start < MIN_LEN:
        end = start + MIN_LEN
    if end - start > MAX_LEN:
        end = start + MAX_LEN
    if video_len:
        end = min(end, video_len)
    excerpt = " ".join(s[2] for s in segs if start <= s[0] <= end)[:2500]
    conf = min(1.0, sum(weight[w] for w in covered) / total)
    return int(start), int(math.ceil(end)), round(conf, 2), excerpt


CHECK_PROMPT = """You check whether a short part of a YouTube video teaches what a student needs right now.
You get what the student needs and the transcript of just that part.
Reply with exactly one word, YES or NO, on the first line: YES only if this part actually explains or works through it
(not just mentions it in passing). Then one short line saying why."""
