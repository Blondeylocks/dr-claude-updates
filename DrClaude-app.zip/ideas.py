"""
Ideas box: students send ideas, problems and wishes to whoever set up their Dr. Claude.

    data\\ideas.json     every idea is saved here FIRST (so nothing is ever lost), then sent:
      1. silently to a Google Form, when the remote config names one, or
      2. by email: the app opens an Outlook-on-the-web / mail-app draft the student only has to send.

    remote config       config.json next to the update manifest (same GitHub repo), re-read every hour, so the
                        Form can be switched on or changed without shipping a new version:
                        {"ideas": {"form_action": ".../formResponse", "fields": {"name": "entry.1", "kind": "entry.2",
                                   "text": "entry.3", "version": "entry.4", "id": "entry.5"}, "email": "..."}}
"""
import datetime as dt
import json
import threading
import time
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

KINDS = ["Idea", "Problem", "Wish", "Question"]
DEFAULT = {"email": "esdraper@cpp.edu", "form_action": "", "fields": {}}
UA = {"User-Agent": "DrClaude-Ideas/1.0"}
_lock = threading.Lock()
_cfg = {"t": 0, "v": None}


def config(manifest_url):
    """The ideas settings: built-in defaults, overridden by config.json beside the manifest (cached 1 hour)."""
    if _cfg["v"] is not None and time.time() - _cfg["t"] < 3600:
        return _cfg["v"]
    cfg = dict(DEFAULT)
    if manifest_url and manifest_url.startswith("http"):
        url = manifest_url.rsplit("/", 1)[0] + "/config.json"
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=8) as r:
                remote = json.loads(r.read().decode("utf-8")).get("ideas") or {}
            cfg.update({k: v for k, v in remote.items() if v})
        except Exception:
            pass  # offline or no config yet: the email way still works
    _cfg.update(t=time.time(), v=cfg)
    return cfg


class Box:
    def __init__(self, data_dir, version, who, manifest_url):
        self.file = Path(data_dir) / "ideas.json"
        self.version = version
        self.who = who                    # () -> the student's name
        self.manifest_url = manifest_url  # () -> update manifest link

    def load(self):
        try:
            return json.loads(self.file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []

    def _save(self, items):
        self.file.write_text(json.dumps(items, indent=1, ensure_ascii=False), encoding="utf-8")

    def _update(self, iid, **kw):
        with _lock:
            items = self.load()
            for it in items:
                if it["id"] == iid:
                    it.update(kw)
            self._save(items)

    def add(self, kind, text):
        text = (text or "").strip()
        if not text:
            raise ValueError("Write your idea first.")
        it = {"id": uuid.uuid4().hex[:10], "when": dt.datetime.now().isoformat(timespec="seconds"),
              "kind": kind if kind in KINDS else "Idea", "text": text[:4000], "sent": False, "via": ""}
        with _lock:
            items = self.load()
            items.append(it)
            self._save(items)
        return self.send(it["id"])

    def delete(self, iid):
        with _lock:
            self._save([it for it in self.load() if it["id"] != iid])

    def send(self, iid):
        """Try the Google Form; either way return the idea plus email links as the fallback."""
        it = next((x for x in self.load() if x["id"] == iid), None)
        if not it:
            raise ValueError("That idea is gone.")
        cfg = config(self.manifest_url())
        if not it["sent"] and cfg.get("form_action") and cfg.get("fields"):
            f = cfg["fields"]
            vals = {"name": self.who() or "Someone", "kind": it["kind"], "text": it["text"], "version": self.version, "id": it["id"]}
            body = urllib.parse.urlencode({f[k]: v for k, v in vals.items() if f.get(k)}).encode()
            try:
                req = urllib.request.Request(cfg["form_action"], data=body, headers={**UA, "Content-Type": "application/x-www-form-urlencoded"})
                with urllib.request.urlopen(req, timeout=15) as r:
                    if r.status == 200:
                        self._update(iid, sent=True, via="form")
                        it.update(sent=True, via="form")
            except Exception:
                pass
        return {"idea": it, "email": self.email_links(it, cfg)}

    def mark_emailed(self, iid):
        self._update(iid, sent=True, via="email")

    def email_links(self, it, cfg=None):
        cfg = cfg or config(self.manifest_url())
        to = cfg.get("email") or DEFAULT["email"]
        subject = f"[Dr. Claude idea] {it['kind']}: {it['text'][:60]}"
        body = f"{it['text']}\n\n(from {self.who() or 'a Dr. Claude user'} · Dr. Claude v{self.version} · id {it['id']})"
        q = urllib.parse.urlencode({"to": to, "subject": subject, "body": body}, quote_via=urllib.parse.quote)
        mq = urllib.parse.urlencode({"subject": subject, "body": body}, quote_via=urllib.parse.quote)
        return {"to": to, "outlook": "https://outlook.office.com/mail/deeplink/compose?" + q, "mailto": f"mailto:{to}?{mq}"}
