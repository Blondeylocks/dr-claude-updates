"""
Ideas box: students send ideas, problems and wishes to whoever set up their Dr. Claude.

    data\\ideas.json     every idea is saved here FIRST (so nothing is ever lost), then sent quietly to a Google Form
                        (its answers land in the developer's Google Sheet). If the computer is offline, the idea waits
                        and goes out by itself on the next try (app start, or opening the Ideas page). No email, ever.

    remote config       config.json next to the update manifest (same GitHub repo), re-read every hour, so the
                        Form can be swapped without shipping a new version:
                        {"ideas": {"form_action": ".../formResponse", "fields": {"name": "entry.1", "kind": "entry.2", "text": "entry.3"}}}
"""
import datetime as dt
import json
import threading
import time
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

KINDS = ["Idea", "Problem", "Wish", "Question"]
DEFAULT = {  # "Dr. Claude Ideas" form -> "Dr. Claude Ideas (from users)" sheet (built 10/25/2026)
    "form_action": "https://docs.google.com/forms/d/e/1FAIpQLSfr6rDimbyUaSJe8DspauyL6fNnu6eCyX1l5ufTPamKntDpeg/formResponse",
    "fields": {"name": "entry.576429017", "kind": "entry.1833546081", "text": "entry.1381198816"},
}
UA = {"User-Agent": "DrClaude-Ideas/1.0"}
_lock = threading.Lock()
_cfg = {"t": 0, "v": None}


def config(manifest_url):
    """The ideas settings: built-in defaults, overridden by config.json beside the manifest (cached 1 hour)."""
    if _cfg["v"] is not None and time.time() - _cfg["t"] < 3600:
        return _cfg["v"]
    cfg = dict(DEFAULT)
    if manifest_url and manifest_url.startswith("http"):
        url = manifest_url.rsplit("/", 1)[0] + "/config.json"
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=8) as r:
                remote = json.loads(r.read().decode("utf-8")).get("ideas") or {}
            if remote.get("form_action") and remote.get("fields"):
                cfg.update(form_action=remote["form_action"], fields=remote["fields"])
        except Exception:
            pass  # offline or no config: the built-in form still works
    _cfg.update(t=time.time(), v=cfg)
    return cfg


class Box:
    def __init__(self, data_dir, version, who, manifest_url):
        self.file = Path(data_dir) / "ideas.json"
        self.version = version
        self.who = who                    # () -> the student's name
        self.manifest_url = manifest_url  # () -> update manifest link

    def load(self):
        try:
            return json.loads(self.file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []

    def _save(self, items):
        self.file.write_text(json.dumps(items, indent=1, ensure_ascii=False), encoding="utf-8")

    def _update(self, iid, **kw):
        with _lock:
            items = self.load()
            for it in items:
                if it["id"] == iid:
                    it.update(kw)
            self._save(items)

    def add(self, kind, text):
        text = (text or "").strip()
        if not text:
            raise ValueError("Write your idea first.")
        it = {"id": uuid.uuid4().hex[:10], "when": dt.datetime.now().isoformat(timespec="seconds"),
              "kind": kind if kind in KINDS else "Idea", "text": text[:4000], "sent": False}
        with _lock:
            items = self.load()
            items.append(it)
            self._save(items)
        return self.send(it["id"])

    def delete(self, iid):
        with _lock:
            self._save([it for it in self.load() if it["id"] != iid])

    def send(self, iid):
        """Post one idea to the Google Form. -> the idea (with sent=True when it went through)."""
        it = next((x for x in self.load() if x["id"] == iid), None)
        if not it:
            raise ValueError("That idea is gone.")
        if it["sent"]:
            return {"idea": it}
        cfg = config(self.manifest_url())
        f = cfg.get("fields") or {}
        vals = {"name": self.who() or "Someone", "kind": it["kind"],
                "text": f"{it['text']}\n\n(Dr. Claude v{self.version} · id {it['id']})"}
        body = urllib.parse.urlencode({f[k]: v for k, v in vals.items() if f.get(k)}).encode()
        try:
            req = urllib.request.Request(cfg["form_action"], data=body, headers={**UA, "Content-Type": "application/x-www-form-urlencoded"})
            with urllib.request.urlopen(req, timeout=15) as r:
                if r.status == 200:
                    self._update(iid, sent=True, sent_at=dt.datetime.now().isoformat(timespec="seconds"))
                    it.update(sent=True)
        except Exception as e:
            it["error"] = "Couldn't reach the internet. It will send by itself later." if "urlopen" in repr(e) or "timed out" in str(e) else str(e)[:200]
        return {"idea": it}

    def send_waiting(self):
        """Retry every idea that hasn't gone out yet (called at app start and when the Ideas page opens)."""
        for it in self.load():
            if not it.get("sent"):
                self.send(it["id"])
