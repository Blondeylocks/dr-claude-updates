"""
Course textbooks: does each class have its book, and which book does the professor use?

    scan(course, text_of)   reads the syllabus, Canvas pages, modules and any syllabus-like files
                            -> ISBNs (check digits verified) + the lines that name a textbook ("Required text: ...")
    has_book(folder)        a PDF in My Files\\Textbooks, or a big / "textbook"-named PDF anywhere in the class folder
    Results are cached per class until its files change (data\\coursebooks.json). The app turns this into a
    "📚 No textbook yet" notice with a one-click search, and tells the tutor so it can mention it.
Standard library only (+ books.clean_isbn).
"""
import json
import os
import re
import threading
from pathlib import Path

import books

SOURCE_NAMES = ("Syllabus.html", "Modules.md", "Assignments.md")
SYLLABUS_LIKE = re.compile(r"syllab|outline|course[ _-]?info|green ?sheet|course[ _-]?policies|course[ _-]?schedule|orientation", re.I)
TEXT_EXTS = {".pdf", ".docx", ".pptx", ".txt", ".md", ".html", ".htm"}
BOOKISH = re.compile(r"text ?book|\bedition\b|\b\d+(st|nd|rd|th) ed\b|full[ _-]?book|\bopenstax\b", re.I)
ISBN_RE = re.compile(r"(?:ISBN(?:-1[03])?[:\s#]*)((?:97[89][-\s]?)?(?:\d[-\s]?){9}[\dXx])|\b(97[89](?:[-\s]?\d){10})\b")
MENTION_RE = re.compile(r"(required|recommended|optional|course|assigned)?\s*(text ?books?|texts?|books?|readings?|materials)\s*(\((required|recommended|optional)\))?\s*[:\-–]\s*(.{8,240})", re.I)
_lock = threading.Lock()

EXTRACT_PROMPT = """You read lines from a college course's syllabus and pick out the textbooks the course uses.
Reply with ONLY a JSON list (no other text), at most 4 items, each {"title": "...", "authors": ["..."], "edition": "...", "isbn": "...", "required": true/false}.
Leave a field "" when the lines don't say it. If no real book is named (only "slides", "handouts", "none"), reply []."""


def files_signature(folder):
    folder = Path(folder)
    sig = []
    for sub in ("", "Canvas Pages", "Canvas Files", "My Files", "My Files/Textbooks"):
        d = folder / sub
        try:
            sig.append(f"{sub}:{int(d.stat().st_mtime)}:{len(os.listdir(d))}")
        except OSError:
            sig.append(f"{sub}:-")
    return "|".join(sig)


def book_files(folder):
    """PDFs that look like a whole textbook."""
    folder = Path(folder)
    out = []
    tb = folder / "My Files" / "Textbooks"
    if tb.is_dir():
        out += [p.name for p in tb.iterdir() if p.suffix.lower() == ".pdf"]
    for sub in ("Canvas Files", "My Files"):
        for dp, dirs, fs in os.walk(folder / sub):
            dirs[:] = [d for d in dirs if d != "Made by Dr. Claude"]  # the tutor's own cheat sheets aren't the textbook
            for f in fs:
                if not f.lower().endswith(".pdf") or f in out:
                    continue
                p = Path(dp) / f
                try:
                    big = p.stat().st_size >= 25 * 1024 * 1024
                except OSError:
                    big = False
                if big or BOOKISH.search(f):
                    out.append(f)
    return out[:10]


def sources(folder):
    folder = Path(folder)
    out = [folder / n for n in SOURCE_NAMES if (folder / n).exists()]
    pages = folder / "Canvas Pages"
    if pages.is_dir():
        out += sorted(p for p in pages.iterdir() if p.is_file())[:60]
    for sub in ("Canvas Files", "My Files"):
        for dp, _, fs in os.walk(folder / sub):
            for f in fs:
                if SYLLABUS_LIKE.search(f) and Path(f).suffix.lower() in TEXT_EXTS:
                    out.append(Path(dp) / f)
    return out[:80]


def find_isbns(text):
    found = []
    for m in ISBN_RE.finditer(text):
        raw = m.group(1) or m.group(2)
        try:
            isbn = books.clean_isbn(raw)
        except ValueError:
            continue
        if isbn not in found:
            found.append(isbn)
    return found


def find_mentions(text):
    out = []
    for m in MENTION_RE.finditer(text):
        # the line itself plus what follows (book lists often start on the next lines)
        line = re.sub(r"\s+", " ", text[m.start():m.start() + 420]).strip()
        if re.search(r"\b(none|no textbook|not required|no required)\b", line, re.I):
            out.append(line[:420])
            continue
        if len(line) > 20 and line not in out:
            out.append(line[:420])
    return out[:8]


class Shelf:
    def __init__(self, data_dir, text_of, ask_ai=None):
        self.file = Path(data_dir) / "coursebooks.json"
        self.text_of = text_of    # (path) -> plain text of a file (pdf/docx/html...), "" if unreadable
        self.ask_ai = ask_ai      # (system, msg) -> (text, err), or None when no AI is set up

    def _load(self):
        try:
            return json.loads(self.file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def _save(self, d):
        self.file.write_text(json.dumps(d, indent=1, ensure_ascii=False), encoding="utf-8")

    def dismiss(self, cid, why="no textbook"):
        with _lock:
            d = self._load()
            d.setdefault(cid, {})["dismissed"] = why
            self._save(d)

    def undismiss(self, cid):
        with _lock:
            d = self._load()
            d.get(cid, {}).pop("dismissed", None)
            self._save(d)

    def status(self, c, use_ai=True):
        """-> {"has_book", "book_files", "books": [{isbn,title,authors,edition,required,line}], "mentions", "dismissed"}"""
        folder = c.get("folder") or ""
        if not folder or not Path(folder).is_dir():
            return {"has_book": False, "book_files": [], "books": [], "mentions": [], "dismissed": ""}
        d = self._load()
        cached = d.get(c["id"], {})
        sig = files_signature(folder)
        if cached.get("sig") == sig and (cached.get("ai_done") or not use_ai or not self.ask_ai):
            res = cached["res"]
        else:
            isbns, mentions = [], []
            for p in sources(folder):
                t = self.text_of(p) or ""
                for i in find_isbns(t):
                    if i not in isbns:
                        isbns.append(i)
                for m in find_mentions(t):
                    if m not in mentions:
                        mentions.append(m)
            found = [{"isbn": i, "title": "", "authors": [], "edition": "", "required": True, "line": ""} for i in isbns[:4]]
            ai_done = False
            if use_ai and self.ask_ai and mentions and len(found) < 2:
                try:
                    out, _ = self.ask_ai(EXTRACT_PROMPT, f"Course: {c.get('code', '')} {c.get('title', '')}\n\nLines:\n" + "\n".join(mentions))
                    m = re.search(r"\[.*\]", out or "", re.S)
                    for b in json.loads(m.group(0)) if m else []:
                        isbn = ""
                        try:
                            isbn = books.clean_isbn(b.get("isbn", "")) if b.get("isbn") else ""
                        except ValueError:
                            pass
                        if isbn and any(f["isbn"] == isbn for f in found):
                            continue
                        if b.get("title") or isbn:
                            found.append({"isbn": isbn, "title": str(b.get("title", ""))[:200], "authors": [str(a) for a in b.get("authors") or []][:4],
                                          "edition": str(b.get("edition", ""))[:40], "required": bool(b.get("required", True)), "line": ""})
                    ai_done = True
                except Exception:
                    pass
            res = {"has_book": bool(book_files(folder)), "book_files": book_files(folder), "books": found[:4], "mentions": mentions[:5]}
            with _lock:
                d = self._load()
                d[c["id"]] = {**d.get(c["id"], {}), "sig": sig, "res": res, "ai_done": ai_done or not mentions}
                self._save(d)
        return {**res, "dismissed": d.get(c["id"], {}).get("dismissed", "")}
