"""
Canvas sync for Dr. Claude (Python standard library only).

The system:
    access token (DPAPI-encrypted on disk)  -->  Canvas REST API (paginated via the Link header)
        courses (active)  -->  per course:  files + folders, syllabus, assignments, modules, pages
                                            -->  Documents\\Dr. Claude\\<CODE Title>\\
                                                   Canvas Files\\   (same folders as Canvas; unchanged files skipped)
                                                   Canvas Pages\\   Syllabus.html  Assignments.md  Modules.md
                                                   Canvas Calendar.md (rewritten every sync)
                                                   <CODE> Course Record.md (created once, never overwritten)
        + courses.json and deadlines.json in Documents\\Dr. Claude\\ (the app reads these)

If a course hides its Files tab (401/403), files are still collected from modules, the syllabus,
assignment descriptions and pages, one by one.
"""
import ctypes
import datetime as dt
import html
import json
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from ctypes import wintypes
from pathlib import Path

# ----------------------------------------------------------------------------- token storage (Windows DPAPI)


class _Blob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _blob(b):
    buf = ctypes.create_string_buffer(b, len(b))
    return _Blob(len(b), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf


def _dpapi(data, protect):
    crypt32, kernel32 = ctypes.windll.crypt32, ctypes.windll.kernel32
    inp, _keep = _blob(data)
    out = _Blob()
    entropy, _keep2 = _blob(b"Dr. Claude Canvas token")
    fn = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
    ok = (fn(ctypes.byref(inp), "Dr. Claude" if protect else None, ctypes.byref(entropy), None, None, 0x1, ctypes.byref(out))
          if protect else
          fn(ctypes.byref(inp), None, ctypes.byref(entropy), None, None, 0x1, ctypes.byref(out)))
    if not ok:
        raise OSError("Windows couldn't " + ("encrypt" if protect else "decrypt") + " the Canvas token")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)


def save_token(path, token):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_bytes(_dpapi(token.strip().encode("utf-8"), True))


def load_token(path):
    try:
        return _dpapi(Path(path).read_bytes(), False).decode("utf-8")
    except (OSError, FileNotFoundError):
        return ""


# ----------------------------------------------------------------------------- HTTP


class CanvasError(Exception):
    def __init__(self, status, msg):
        super().__init__(msg)
        self.status = status


class _StripAuthOnRedirect(urllib.request.HTTPRedirectHandler):
    """Canvas file URLs redirect to a storage host (S3 / inst-fs). Those reject a second auth header,
    so drop Authorization whenever the redirect leaves the Canvas host."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        new = super().redirect_request(req, fp, code, msg, headers, newurl)
        if new is not None and urllib.parse.urlparse(newurl).netloc != urllib.parse.urlparse(req.full_url).netloc:
            for k in list(new.headers):
                if k.lower() == "authorization":
                    del new.headers[k]
            new.unredirected_hdrs.pop("Authorization", None)
        return new


_opener = urllib.request.build_opener(_StripAuthOnRedirect)


class Canvas:
    def __init__(self, base, token, timeout=30):
        base = (base or "").strip().rstrip("/")
        if base and not base.startswith("http"):
            base = "https://" + base
        self.base, self.token, self.timeout = base, token.strip(), timeout

    def _req(self, url):
        if url.startswith("/"):
            url = self.base + url
        return urllib.request.Request(url, headers={"Authorization": f"Bearer {self.token}", "Accept": "application/json",
                                                    "User-Agent": "DrClaude/1.0"})

    def get(self, path, params=None):
        """GET one page. Returns (json, next_url)."""
        url = path if path.startswith("http") else self.base + path
        if params:
            url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params, doseq=True)
        for attempt in range(3):
            try:
                with _opener.open(self._req(url), timeout=self.timeout) as r:
                    body = r.read().decode("utf-8", "replace")
                    link = r.headers.get("Link", "") or ""
                break
            except urllib.error.HTTPError as e:
                if e.code in (429, 500, 502, 503, 504) and attempt < 2:
                    time.sleep(1.5 * (attempt + 1))
                    continue
                detail = ""
                try:
                    detail = e.read().decode("utf-8", "replace")[:300]
                except Exception:
                    pass
                raise CanvasError(e.code, f"Canvas said {e.code} for {urllib.parse.urlparse(url).path}: {detail}")
            except urllib.error.URLError as e:
                if attempt < 2:
                    time.sleep(1.5)
                    continue
                raise CanvasError(0, f"Couldn't reach Canvas ({e.reason})")
        if body.startswith("while(1);"):
            body = body[9:]
        nxt = None
        for part in link.split(","):
            m = re.search(r'<([^>]+)>;\s*rel="next"', part)
            if m:
                nxt = m.group(1)
        return (json.loads(body) if body.strip() else None), nxt

    def get_all(self, path, params=None, limit_pages=50):
        out, url, p = [], path, dict(params or {})
        p.setdefault("per_page", 100)
        first = True
        while url and limit_pages:
            data, url = self.get(url, p if first else None)
            first = False
            limit_pages -= 1
            if isinstance(data, list):
                out.extend(data)
            elif data is not None:
                out.append(data)
        return out

    def download(self, url, dest):
        tmp = Path(long_path(str(dest) + ".part"))
        tmp.parent.mkdir(parents=True, exist_ok=True)
        req = self._req(url)
        with _opener.open(req, timeout=120) as r, open(tmp, "wb") as f:
            while True:
                chunk = r.read(1 << 16)
                if not chunk:
                    break
                f.write(chunk)
        os.replace(tmp, long_path(dest))

    def whoami(self):
        me, _ = self.get("/api/v1/users/self")
        return me


# ----------------------------------------------------------------------------- helpers
BAD = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def long_path(p):
    """Windows refuses paths over 260 characters unless they use the extended-length prefix."""
    p = str(Path(p).absolute())
    pre = "\\\\?\\"
    if os.name == "nt" and len(p) > 240 and not p.startswith(pre):
        return pre + p
    return p


def safe_name(s, n=120):
    s = BAD.sub("_", (s or "").strip()).strip(" .")
    return (s[:n].rstrip(" .") or "untitled")


def html_text(h):
    h = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", "", h or "")
    h = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</h\d>|</tr>", "\n", h)
    h = re.sub(r"(?i)<li[^>]*>", "\n- ", h)
    h = re.sub(r"<[^>]+>", "", h)
    h = html.unescape(h).replace("\xa0", " ")
    h = re.sub(r"[ \t]+", " ", h)
    return re.sub(r"\n\s*\n+", "\n\n", h).strip()


FILE_ID = re.compile(r"/files/(\d+)")


def code_of(course):
    for s in (course.get("course_code") or "", course.get("name") or ""):
        m = re.search(r"\b([A-Z]{2,4})\s?-?(\d{3,4}[A-Z]{0,2})\b", s)
        if m:
            return f"{m.group(1)} {m.group(2)}"
    return (course.get("course_code") or f"Course {course['id']}").split(".")[0].strip()


def title_of(course, code):
    name = course.get("name") or ""
    t = re.sub(r"^\s*[A-Z]{2,4}\s?-?\d{3,4}[A-Z]{0,2}(\.\d+)?\s*[-:–]?\s*", "", name).strip()
    t = re.sub(r"\s*\((?:Fall|Spring|Summer|Winter)[^)]*\)\s*$", "", t, flags=re.I)
    return t or name or code


def parse_iso(s):
    if not s:
        return None
    try:
        return dt.datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone()
    except ValueError:
        return None


def is_assessment(a):
    return bool(re.search(r"\b(quiz|exam|midterm|final|test)\b", a.get("name") or "", re.I)
                or "online_quiz" in (a.get("submission_types") or []) or a.get("is_quiz_assignment"))


# ----------------------------------------------------------------------------- sync state (read by the UI)
STATE = {"running": False, "phase": "", "course": "", "done": 0, "total": 0, "files_new": 0, "files_same": 0,
         "errors": [], "log": [], "started": None, "finished": None, "courses": 0}
_lock = threading.Lock()


def _say(msg, **kw):
    with _lock:
        STATE.update(kw)
        if msg:
            STATE["log"] = (STATE["log"] + [f"{dt.datetime.now().strftime('%H:%M:%S')} {msg}"])[-200:]


def _err(msg):
    with _lock:
        STATE["errors"] = (STATE["errors"] + [msg])[-50:]
        STATE["log"] = (STATE["log"] + [f"{dt.datetime.now().strftime('%H:%M:%S')} ⚠️ {msg}"])[-200:]


# ----------------------------------------------------------------------------- per-course sync
def _try(fn, what, default=None, quiet_codes=(401, 403, 404)):
    try:
        return fn()
    except CanvasError as e:
        if e.status not in quiet_codes:
            _err(f"{what}: {e}")
        return default


def sync_course(cv, c, root):
    cid = c["id"]
    code = code_of(c)
    title = title_of(c, code)
    folder = Path(long_path(root / safe_name(f"{code.replace(' ', '')} {title}")))
    files_dir = folder / "Canvas Files"
    files_dir.mkdir(parents=True, exist_ok=True)
    manifest_p = files_dir / ".drc-sync.json"
    try:
        manifest = json.loads(manifest_p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        manifest = {}
    _say(f"{code}: reading course info", course=f"{code} {title}")

    # syllabus
    syl = c.get("syllabus_body")
    if syl is None:
        full = _try(lambda: cv.get(f"/api/v1/courses/{cid}", {"include[]": ["syllabus_body"]})[0], f"{code} syllabus", {})
        syl = (full or {}).get("syllabus_body")
    if syl:
        (folder / "Syllabus.html").write_text(f"<!doctype html><meta charset=utf-8><title>{html.escape(code)} Syllabus</title>\n{syl}",
                                              encoding="utf-8")

    # assignments
    assigns = _try(lambda: cv.get_all(f"/api/v1/courses/{cid}/assignments", {"order_by": "due_at"}), f"{code} assignments", []) or []
    quizzes = {q.get("assignment_id"): q for q in (_try(lambda: cv.get_all(f"/api/v1/courses/{cid}/quizzes"), f"{code} quizzes", []) or [])}
    lines = [f"# {code} {title}: Assignments", f"*From Canvas, synced {dt.datetime.now():%Y-%m-%d %H:%M}. Due times are local.*", ""]
    linked = {}  # file_id -> where it was seen
    for a in assigns:
        due = parse_iso(a.get("due_at"))
        q = quizzes.get(a.get("id")) or {}
        lines.append(f"## {a.get('name', '?')}")
        lines.append(f"- Due: {due:%a %b %d %Y, %I:%M %p}" if due else "- Due: (no due date)")
        lines.append(f"- Points: {a.get('points_possible', '?')} · Submit: {', '.join(a.get('submission_types') or []) or '?'}"
                     + (f" · Time limit: {q['time_limit']} min" if q.get("time_limit") else ""))
        desc = html_text(a.get("description") or "")
        if desc:
            lines.append("")
            lines.append(desc)
        lines.append("")
        for fid in FILE_ID.findall(a.get("description") or ""):
            linked.setdefault(fid, "Assignments")
    (folder / "Assignments.md").write_text("\n".join(lines), encoding="utf-8")
    for fid in FILE_ID.findall(syl or ""):
        linked.setdefault(fid, "Syllabus")

    # modules
    mods = _try(lambda: cv.get_all(f"/api/v1/courses/{cid}/modules", {"include[]": ["items"]}), f"{code} modules", []) or []
    mlines = [f"# {code} {title}: Modules (Canvas order)", ""]
    for m in mods:
        items = m.get("items")
        if items is None and m.get("items_url"):
            items = _try(lambda: cv.get_all(m["items_url"]), f"{code} module items", []) or []
        unlock = parse_iso(m.get("unlock_at"))
        mlines.append(f"## {m.get('name', '?')}" + (f" (opens {unlock:%b %d})" if unlock else ""))
        for it in items or []:
            mlines.append(f"- [{it.get('type', '')}] {it.get('title', '')}")
            if it.get("type") == "File" and it.get("content_id"):
                linked.setdefault(str(it["content_id"]), "Modules/" + safe_name(m.get("name", "Module"), 60))
        mlines.append("")
    (folder / "Modules.md").write_text("\n".join(mlines), encoding="utf-8")

    # pages
    pages = _try(lambda: cv.get_all(f"/api/v1/courses/{cid}/pages"), f"{code} pages", []) or []
    if pages:
        pdir = folder / "Canvas Pages"
        pdir.mkdir(exist_ok=True)
        for pg in pages[:200]:
            full = _try(lambda: cv.get(f"/api/v1/courses/{cid}/pages/{urllib.parse.quote(pg.get('url', ''))}")[0], f"{code} page", None)
            if not full:
                continue
            body = full.get("body") or ""
            (pdir / (safe_name(full.get("title") or pg.get("url")) + ".html")).write_text(
                f"<!doctype html><meta charset=utf-8><title>{html.escape(full.get('title') or '')}</title>\n{body}", encoding="utf-8")
            for fid in FILE_ID.findall(body):
                linked.setdefault(fid, "Pages")

    # files (+ folders) — the Files tab may be hidden for students
    folders = {}
    flist = None
    try:
        for f in cv.get_all(f"/api/v1/courses/{cid}/folders"):
            folders[f["id"]] = f.get("full_name") or ""
        flist = cv.get_all(f"/api/v1/courses/{cid}/files")
    except CanvasError as e:
        if e.status in (401, 403, 404):
            _say(f"{code}: Files tab is hidden, collecting files from modules/assignments/pages instead")
        else:
            _err(f"{code} files: {e}")
    seen = set()
    todo = []
    for f in flist or []:
        rel = folders.get(f.get("folder_id"), "")
        rel = re.sub(r"^course files/?", "", rel, flags=re.I)
        todo.append((f, rel))
        seen.add(str(f["id"]))
    for fid, where in linked.items():
        if fid in seen:
            continue
        meta = _try(lambda: cv.get(f"/api/v1/courses/{cid}/files/{fid}")[0], f"{code} file {fid}", None) \
            or _try(lambda: cv.get(f"/api/v1/files/{fid}")[0], f"{code} file {fid}", None)
        if meta and meta.get("id"):
            rel = folders.get(meta.get("folder_id"))
            rel = re.sub(r"^course files/?", "", rel, flags=re.I) if rel is not None else f"From {where}"
            todo.append((meta, rel))
            seen.add(fid)
    _say(f"{code}: {len(todo)} file(s) to check", total=STATE["total"] + len(todo))
    for f, rel in todo:
        name = safe_name(f.get("display_name") or f.get("filename") or f"file-{f['id']}")
        dest = files_dir.joinpath(*[safe_name(p) for p in rel.split("/") if p], name)
        key = str(f["id"])
        prev = manifest.get(key)
        try:
            if not f.get("url") or f.get("locked_for_user"):
                _say(f"{code}: skipped locked file {name}")
            elif prev and prev.get("updated_at") == f.get("updated_at") and prev.get("size") == f.get("size") and Path(long_path(prev.get("path", "") or ".")).exists():
                _say("", files_same=STATE["files_same"] + 1)
            else:
                cv.download(f["url"], dest)
                manifest[key] = {"updated_at": f.get("updated_at"), "size": f.get("size"), "path": str(dest)}
                _say(f"{code}: downloaded {rel + '/' if rel else ''}{name}", files_new=STATE["files_new"] + 1)
        except (CanvasError, urllib.error.URLError, OSError) as e:
            _err(f"{code}: couldn't download {name} ({e})")
        _say("", done=STATE["done"] + 1)
    manifest_p.write_text(json.dumps(manifest, indent=1), encoding="utf-8")

    # calendar + course record
    teachers = ", ".join(t.get("display_name", "") for t in c.get("teachers") or []) or "?"
    term = (c.get("term") or {}).get("name") or "?"
    start = parse_iso(c.get("start_at")) or parse_iso((c.get("term") or {}).get("start_at"))
    write_calendar(folder, code, title, assigns, mods, start)
    record = folder / f"{code.replace(' ', '')} Course Record.md"
    if not record.exists():
        record.write_text(course_record(code, title, cid, cv.base, term, teachers, assigns, quizzes, mods, start, folder, bool(syl)),
                          encoding="utf-8")
    deadlines = []
    now = dt.datetime.now().astimezone()
    for a in assigns:
        due = parse_iso(a.get("due_at"))
        if due and due > now - dt.timedelta(days=1):
            deadlines.append({"date": due.date().isoformat(), "time": due.strftime("%I:%M %p").lstrip("0"),
                              "title": a.get("name", ""), "class": code, "kind": "exam" if is_assessment(a) else "assignment"})
    return {"id": code.replace(" ", ""), "code": code, "title": title, "name": f"{code} {title}", "canvas_id": cid,
            "term": term, "professor": teachers, "folder": str(folder), "record": str(record)}, deadlines


def week_of(d, start):
    return (d.date() - (start.date() - dt.timedelta(days=start.weekday()))).days // 7 + 1


def write_calendar(folder, code, title, assigns, mods, start):
    rows = []
    for a in assigns:
        due = parse_iso(a.get("due_at"))
        if due:
            rows.append((due, a.get("name", ""), "📝 exam/quiz" if is_assessment(a) else "assignment", a.get("points_possible")))
    for m in mods:
        u = parse_iso(m.get("unlock_at"))
        if u:
            rows.append((u, m.get("name", ""), "📦 module opens", None))
    rows.sort(key=lambda r: r[0])
    out = [f"# {code} {title}: Canvas Calendar", f"*Rewritten on every sync ({dt.datetime.now():%Y-%m-%d %H:%M}). Due dates from Canvas.*", "",
           "| Wk | Date | Item | Kind | Points |", "|---|---|---|---|---|"]
    for d, name, kind, pts in rows:
        wk = week_of(d, start) if start else "?"
        out.append(f"| {wk} | {d:%a %b %d, %I:%M %p} | {name.replace('|', '/')} | {kind} | {'' if pts is None else pts} |")
    (folder / "Canvas Calendar.md").write_text("\n".join(out) + "\n", encoding="utf-8")


def course_record(code, title, cid, base, term, teachers, assigns, quizzes, mods, start, folder, has_syl):
    first_due = min((parse_iso(a.get("due_at")) for a in assigns if parse_iso(a.get("due_at"))), default=None)
    start = start or first_due
    weeks = {}
    for a in assigns:
        d = parse_iso(a.get("due_at"))
        if d and start:
            weeks.setdefault(week_of(d, start), []).append(a.get("name", ""))
    for m in mods:
        d = parse_iso(m.get("unlock_at"))
        if d and start:
            weeks.setdefault(week_of(d, start), []).append("module: " + m.get("name", ""))
    pace = []
    if start:
        w0 = start.date() - dt.timedelta(days=start.weekday())
        for wk in range(1, (max(weeks) if weeks else 1) + 1):
            a, b = w0 + dt.timedelta(days=7 * (wk - 1)), w0 + dt.timedelta(days=7 * (wk - 1) + 4)
            due = "; ".join(x for x in weeks.get(wk, []) if not x.startswith("module: ")).replace("|", "/")
            mod = "; ".join(x[8:] for x in weeks.get(wk, []) if x.startswith("module: ")).replace("|", "/")
            pace.append(f"| {wk} | {a.month}/{a.day}–{b.month}/{b.day} | {mod or '?'} | | | {due} |")
    else:
        pace.append("| 1 | ? | ? | | | |")
    alog = []
    for a in assigns:
        if not is_assessment(a):
            continue
        d = parse_iso(a.get("due_at"))
        q = quizzes.get(a.get("id")) or {}
        fmt = "Canvas quiz" if "online_quiz" in (a.get("submission_types") or []) else \
            ", ".join(a.get("submission_types") or []).replace("_", " ") or "?"
        alog.append(f"| {a.get('name', '?').replace('|', '/')} | {d:%m/%d/%Y} | {fmt} | "
                    f"{str(q['time_limit']) + ' min' if q.get('time_limit') else '?'} | ? | ? | {a.get('points_possible', '?')} | ? |"
                    if d else
                    f"| {a.get('name', '?').replace('|', '/')} | ? | {fmt} | ? | ? | ? | {a.get('points_possible', '?')} | ? |")
    mod_names = ", ".join(m.get("name", "") for m in mods[:40]) or "(no modules on Canvas)"
    return f"""# {code} {title}: Course Record
*Dr. Claude's registrar file. Logs what the REAL class covers and how fast, so it can be taught back at the same pace. Never invent anything: unknown = `?` + where to check.*
*Started automatically from Canvas on {dt.date.today():%Y-%m-%d}. Canvas Calendar.md is refreshed on every sync; this file is yours (and Dr. Claude's) to edit.*

## Course facts
| | |
|---|---|
| Term | {term}{f" (week 1 = week of {start:%b %d})" if start else ""} |
| Professor | {teachers} |
| Meets | ? (days, time, room: check {"Syllabus.html" if has_syl else "the syllabus"}) |
| Textbook / main source | ? (check {"Syllabus.html" if has_syl else "the syllabus"}) |
| Grading weights | ? (from syllabus) |
| Exam rules | ? (open/closed book, calculator, cheat sheet, time) |
| Canvas course ID | {f"{cid} ({base}/courses/{cid})" if base else cid} |

## Pacing Calendar (what was taught, week by week)
*Rows come from Canvas due dates and module dates. "Topics covered" fills in as you log real classes (Log a Class mode).*
| Wk | Dates | Topics covered | Book section / source | Notes file | Due / assessed |
|---|---|---|---|---|---|
{chr(10).join(pace)}

Modules on Canvas (in order): {mod_names}

## Assessment Log (every quiz, exam, lab, assignment)
| Item | Date | Format | Time | Topics | Question styles | Points | Score |
|---|---|---|---|---|---|---|---|
{chr(10).join(alog) if alog else "| (no quizzes or exams found on Canvas yet) | | | | | | | |"}

## Professor patterns
- (reused past quizzes, favorite problems, extra credit habits, grading strictness)

## Source files
- Syllabus: {"Syllabus.html" if has_syl else "? (not posted on Canvas)"}
- Canvas Files\\: {folder / "Canvas Files"}
- Assignments: Assignments.md · Modules: Modules.md · Dates: Canvas Calendar.md
- Notes:
- Past quizzes/exams:

## Mastery
*✅ solid · 🟡 shaky · ❌ not yet · ⬜ not practiced*
| Topic | Mastery | Notes |
|---|---|---|

## Course Summary (fill at end of term)
- Weeks: · Topics/week avg: · Final grade: · Hardest units:
- Replay pace suggestion:

## Session log
-
"""


# ----------------------------------------------------------------------------- whole sync
def list_courses(cv):
    cs = cv.get_all("/api/v1/courses", {"enrollment_state": "active", "include[]": ["term", "teachers", "syllabus_body"]})
    now = dt.datetime.now().astimezone()
    out = []
    for c in cs:
        if not c.get("name") or c.get("access_restricted_by_date"):
            continue
        end = parse_iso(c.get("end_at")) or parse_iso((c.get("term") or {}).get("end_at"))
        if end and end < now - dt.timedelta(days=21):
            continue
        out.append(c)
    return out


def sync_all(base, token, root, cv=None):
    """cv: a ready Canvas client (canvas_bridge.BridgeCanvas when syncing through the browser, no token)."""
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    with _lock:
        if STATE["running"]:
            return False
        STATE.update(running=True, phase="Connecting to Canvas", course="", done=0, total=0, files_new=0, files_same=0,
                     errors=[], log=[], started=dt.datetime.now().isoformat(timespec="seconds"), finished=None, courses=0)
    cv = cv or Canvas(base, token)
    via = getattr(cv, "via", "token")
    try:
        me = cv.whoami()
        _say(f"Signed in to Canvas as {me.get('name', '?')}", phase="Finding your courses")
        cs = list_courses(cv)
        _say(f"Found {len(cs)} active course(s)", courses=len(cs), phase="Syncing")
        index, deadlines = [], []
        for c in cs:
            try:
                info, dl = sync_course(cv, c, root)
                index.append(info)
                deadlines += dl
            except CanvasError as e:
                _err(f"{c.get('name')}: {e}")
            except OSError as e:  # one bad folder or file name must not stop the other classes
                _err(f"{c.get('name')}: {e}")
        # keep courses added by hand (no Canvas) and their deadlines
        try:
            old = json.loads((root / "courses.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            old = {}
        ids = {c["id"] for c in index}
        index += [c for c in old.get("courses", []) if c.get("manual") and c["id"] not in ids]
        try:
            old_dl = json.loads((root / "deadlines.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            old_dl = []
        manual_codes = {c["code"] for c in index if c.get("manual")}
        deadlines += [d for d in old_dl if d.get("class") in manual_codes]
        (root / "courses.json").write_text(json.dumps({"synced": dt.datetime.now().isoformat(timespec="seconds"),
                                                       "canvas": cv.base, "via": via, "courses": index}, indent=1, ensure_ascii=False), encoding="utf-8")
        deadlines.sort(key=lambda d: (d["date"], d["time"]))
        (root / "deadlines.json").write_text(json.dumps(deadlines, indent=1, ensure_ascii=False), encoding="utf-8")
        _say(f"Done: {STATE['files_new']} new file(s), {STATE['files_same']} already up to date", phase="Done")
    except CanvasError as e:
        _err(str(e) if e.status not in (401,) or via != "token" else "Canvas didn't accept the token. Make a new one and paste it again.")
        _say("", phase="Stopped")
    except Exception as e:  # keep the UI informed instead of dying silently
        _err(str(e) if type(e).__name__ == "BridgeLost" else f"Unexpected problem: {e!r}")
        _say("", phase="Stopped")
    finally:
        with _lock:
            STATE["running"] = False
            STATE["finished"] = dt.datetime.now().isoformat(timespec="seconds")
    return True


def start_sync(base, token, root):
    if STATE["running"]:
        return False
    threading.Thread(target=sync_all, args=(base, token, root), daemon=True).start()
    return True
