// Tools drawer for Dr. Claude: Calculator, Quick Ask (side chat), My Thoughts (log + insight).
// Opens from the nav "Tools" button or the Classroom's 🧰 button. Needs window.DRC from app.js.
(function () {
  const $ = (s, el = document) => el.querySelector(s);
  const esc = s => MD.esc(String(s == null ? '' : s));
  const D = () => window.DRC;

  // ------------------------------------------------------------------ calculator
  // Safe parser (no eval). Integers are exact (BigInt) when the whole expression allows it,
  // so 3310^5 or 2^63 come out exact, and every integer result shows how int8/16/32/64 would store it.
  const FUNCS = {
    sqrt: Math.sqrt, abs: Math.abs, floor: Math.floor, ceil: Math.ceil, round: Math.round,
    ln: Math.log, log: Math.log10, log10: Math.log10, log2: Math.log2, exp: Math.exp,
    sin: Math.sin, cos: Math.cos, tan: Math.tan,
  };
  const CONSTS = { pi: Math.PI, e: Math.E };

  function tokenize(s) {
    s = s.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/\*\*/g, '^').replace(/(\d),(?=\d{3}\b)/g, '$1');
    const out = [];
    let i = 0;
    while (i < s.length) {
      const ch = s[i];
      if (/\s/.test(ch)) { i++; continue; }
      let m = s.slice(i).match(/^(\d+\.?\d*(?:e[+-]?\d+)?|\.\d+(?:e[+-]?\d+)?)/i);
      if (m) { out.push({ t: 'num', v: m[1] }); i += m[1].length; continue; }
      m = s.slice(i).match(/^[a-z_]\w*/i);
      if (m) { out.push({ t: 'id', v: m[0].toLowerCase() }); i += m[0].length; continue; }
      if ('+-*/%^()!'.includes(ch)) { out.push({ t: 'op', v: ch }); i++; continue; }
      throw new Error(`I don't understand "${ch}"`);
    }
    return out;
  }

  // grammar: expr = term (('+'|'-') term)* ; term = unary (('*'|'/'|'%') unary)* ;
  // unary = '-' unary | pow ; pow = post ('^' unary)? ; post = atom '!'* ; atom = num | id | id '(' expr ')' | '(' expr ')'
  function parse(tokens) {
    let p = 0;
    const peek = () => tokens[p], take = () => tokens[p++];
    const isOp = v => peek() && peek().t === 'op' && peek().v === v;
    function expr() {
      let n = term();
      while (isOp('+') || isOp('-')) n = { op: take().v, a: n, b: term() };
      return n;
    }
    function term() {
      let n = unary();
      while (isOp('*') || isOp('/') || isOp('%')) n = { op: take().v, a: n, b: unary() };
      return n;
    }
    function unary() {
      if (isOp('-')) { take(); return { op: 'neg', a: unary() }; }
      if (isOp('+')) { take(); return unary(); }
      return pow();
    }
    function pow() {
      const base = post();
      if (isOp('^')) { take(); return { op: '^', a: base, b: unary() }; }
      return base;
    }
    function post() {
      let n = atom();
      while (isOp('!')) { take(); n = { op: '!', a: n }; }
      return n;
    }
    function atom() {
      const t = take();
      if (!t) throw new Error('The expression ends too early');
      if (t.t === 'num') return { num: t.v };
      if (t.t === 'op' && t.v === '(') {
        const n = expr();
        if (!isOp(')')) throw new Error('Missing )');
        take(); return n;
      }
      if (t.t === 'id') {
        if (isOp('(')) {
          take();
          const a = expr();
          if (!isOp(')')) throw new Error('Missing )');
          take();
          if (!FUNCS[t.v]) throw new Error(`Unknown function ${t.v}()`);
          return { fn: t.v, a };
        }
        if (t.v === 'ans') return { ans: true };
        if (t.v in CONSTS) return { c: t.v };
        throw new Error(`Unknown name "${t.v}"`);
      }
      throw new Error(`Unexpected "${t.v}"`);
    }
    const n = expr();
    if (p < tokens.length) throw new Error(`Unexpected "${tokens[p].v}"`);
    return n;
  }

  let ANS = null; // last result: {big?: BigInt, num: Number}

  function evalBig(n) {
    if (n.num !== undefined) { if (!/^\d+$/.test(n.num)) throw 'float'; return BigInt(n.num); }
    if (n.ans) { if (!ANS || ANS.big === undefined) throw 'float'; return ANS.big; }
    if (n.c || n.fn) throw 'float';
    if (n.op === 'neg') return -evalBig(n.a);
    if (n.op === '!') {
      const k = evalBig(n.a);
      if (k < 0n || k > 3000n) throw 'float';
      let r = 1n; for (let i = 2n; i <= k; i++) r *= i; return r;
    }
    const a = evalBig(n.a), b = evalBig(n.b);
    switch (n.op) {
      case '+': return a + b;
      case '-': return a - b;
      case '*': return a * b;
      case '%': if (b === 0n) throw new Error('Mod by zero'); return a % b;
      case '^': if (b < 0n || b > 20000n) throw 'float'; return a ** b;
      case '/': if (b !== 0n && a % b === 0n) return a / b; throw 'float';
    }
    throw 'float';
  }
  function evalNum(n) {
    if (n.num !== undefined) return parseFloat(n.num);
    if (n.ans) return ANS ? ANS.num : 0;
    if (n.c) return CONSTS[n.c];
    if (n.fn) return FUNCS[n.fn](evalNum(n.a));
    if (n.op === 'neg') return -evalNum(n.a);
    if (n.op === '!') { const k = evalNum(n.a); let r = 1; for (let i = 2; i <= k; i++) r *= i; return r; }
    const a = evalNum(n.a), b = evalNum(n.b);
    switch (n.op) {
      case '+': return a + b; case '-': return a - b; case '*': return a * b;
      case '/': return a / b; case '%': return a % b; case '^': return Math.pow(a, b);
    }
    return NaN;
  }
  function calc(src) {
    const tree = parse(tokenize(src));
    try { const big = evalBig(tree); return { big, num: Number(big) }; }
    catch (e) { if (e !== 'float') throw e; return { num: evalNum(tree) }; }
  }

  const commas = s => s.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  function fmtBig(b) { const neg = b < 0n; const s = commas((neg ? -b : b).toString()); return (neg ? '−' : '') + s; }
  function fmtNum(x) {
    if (!isFinite(x)) return x > 0 ? 'Infinity' : x < 0 ? '−Infinity' : 'NaN';
    if (Math.abs(x) >= 1e15 || (x !== 0 && Math.abs(x) < 1e-6)) return x.toExponential(8).replace(/\.?0+e/, 'e');
    return String(+x.toPrecision(12)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }
  function sci(b) { // BigInt -> "3.97 × 10^17"
    const s = (b < 0n ? -b : b).toString();
    if (s.length < 7) return '';
    return `≈ ${b < 0n ? '−' : ''}${s[0]}.${s.slice(1, 4)} × 10^${s.length - 1}`;
  }
  const TYPES = [['char / int8', 8], ['short / int16', 16], ['int / int32', 32], ['long / int64', 64]];
  function storeTable(b) {
    const rows = TYPES.map(([name, bits]) => {
      const w = BigInt.asIntN(bits, b);
      const ok = w === b;
      return `<tr class="${ok ? 'fits' : 'wraps'}"><td>${name}</td><td>${ok ? '✅ fits' : '💥 overflows'}</td><td class="mono">${fmtBig(w)}</td></tr>`;
    }).join('');
    const f32 = Math.fround(Number(b)), f64 = Number(b);
    return `<table class="store"><tr><th>Stored as</th><th></th><th>The computer shows</th></tr>${rows}
      <tr><td>float (4 B)</td><td>${isFinite(f32) ? '≈' : '💥'}</td><td class="mono">${isFinite(f32) ? f32.toExponential(6) : 'Infinity'}</td></tr>
      <tr><td>double (8 B)</td><td>${isFinite(f64) ? '≈' : '💥'}</td><td class="mono">${isFinite(f64) ? f64.toExponential(10) : 'Infinity'}</td></tr></table>`;
  }

  const calcHist = [];
  function calcPane() {
    return `<div class="calc">
      <input id="calcIn" class="calc-in" placeholder="Type math, Enter = solve. e.g. 3310^3,  2^31-1,  (1+100)*100/2" autocomplete="off" spellcheck="false">
      <div class="calc-keys">${['^', '!', '%', 'sqrt(', 'log(', 'ln(', 'pi', 'ans', '2^15', '2^31', '2^63', 'C']
        .map(k => `<button data-k="${esc(k)}">${esc(k)}</button>`).join('')}</div>
      <div id="calcOut" class="calc-out"></div>
      <div class="tools-sub">History <span class="faint">(click one to reuse it)</span></div>
      <div id="calcHist" class="calc-hist"></div>
      <p class="tools-tip">Whole numbers are exact (no rounding), and every whole-number answer shows how <b>char / short / int / long / float / double</b> would store it. Handy for the overflow questions.</p></div>`;
  }
  function runCalc() {
    const inp = $('#calcIn'), out = $('#calcOut');
    const src = inp.value.trim();
    if (!src) return;
    try {
      const r = calc(src);
      ANS = r;
      let html;
      if (r.big !== undefined) {
        html = `<div class="calc-res">= ${fmtBig(r.big)}</div><div class="faint small">${sci(r.big)}${r.big >= 0n ? ` · hex 0x${r.big.toString(16).toUpperCase()}` : ''}</div>${storeTable(r.big)}`;
      } else {
        html = `<div class="calc-res">= ${fmtNum(r.num)}</div>`;
      }
      out.innerHTML = html;
      calcHist.unshift({ src, res: r.big !== undefined ? fmtBig(r.big) : fmtNum(r.num) });
      calcHist.length = Math.min(calcHist.length, 30);
      $('#calcHist').innerHTML = calcHist.map(x => `<button class="hist-row" data-src="${esc(x.src)}"><span class="mono">${esc(x.src)}</span><b>= ${esc(x.res)}</b></button>`).join('');
      inp.select();
    } catch (e) {
      out.innerHTML = `<div class="calc-err">⚠️ ${esc(e.message || e)}</div>`;
    }
  }

  // ------------------------------------------------------------------ quick ask
  const ASK = { sid: null, msgs: [], busy: false };
  function askPane() {
    return `<div class="ask">
      <div id="askLog" class="ask-log">${askLogHtml()}</div>
      <label class="ask-ctx"><input type="checkbox" id="askCtx" checked> Tell it which question I'm on (it gives hints, not answers)</label>
      <div class="ask-box"><textarea id="askIn" rows="2" placeholder="Quick question… (Enter = ask)"></textarea>
        <button class="btn sm primary" id="askGo">Ask</button></div>
      <div class="row-between"><span class="faint small">Separate from the main lesson.</span><button class="btn sm ghost" id="askNew">New chat</button></div></div>`;
  }
  function askLogHtml() {
    if (!ASK.msgs.length) return '<p class="faint small">Ask anything quick: a word you don\'t know, a formula, "is 2^31 the int max?". The main lesson keeps going.</p>';
    return ASK.msgs.map(m => m.role === 'me' ? `<div class="ask-me">${esc(m.text)}</div>` : `<div class="ask-ai md">${D().md(m.text)}</div>`).join('')
      + (ASK.busy ? '<div class="ask-ai faint">Thinking…</div>' : '');
  }
  async function runAsk() {
    const inp = $('#askIn');
    const q = inp.value.trim();
    if (!q || ASK.busy) return;
    inp.value = '';
    ASK.msgs.push({ role: 'me', text: q });
    ASK.busy = true; drawAsk();
    try {
      const r = await D().api('/api/side/ask', { q, sid: ASK.sid, course: D().course(), current: $('#askCtx').checked ? D().current() : '' });
      ASK.sid = r.sid;
      ASK.msgs.push({ role: 'ai', text: r.text });
    } catch (e) { ASK.msgs.push({ role: 'ai', text: '⚠️ ' + e.message }); }
    ASK.busy = false; drawAsk();
  }
  function drawAsk() { const l = $('#askLog'); if (l) { l.innerHTML = askLogHtml(); l.scrollTop = l.scrollHeight; } }

  // ------------------------------------------------------------------ thoughts
  const TH = { items: [], path: '', insight: '', busy: false };
  function thoughtsPane() {
    return `<div class="thoughts">
      <textarea id="thIn" rows="3" placeholder="What did you just notice, get stuck on, or realize? (Ctrl+Enter = save)"></textarea>
      <div class="row-between"><span class="faint small" id="thTag"></span><button class="btn sm primary" id="thSave">Save thought</button></div>
      <div class="row-between th-actions"><button class="btn sm" id="thInsight">💡 Get insight</button><button class="btn sm ghost" id="thOpen">Open file</button></div>
      <div id="thInsightOut"></div>
      <div id="thList" class="th-list"></div>
      <p class="tools-tip">Saved per class in Professor Claude\\Thoughts. Dr. Claude reads them when a new session starts, so it knows what confuses you.</p></div>`;
  }
  function drawThoughts() {
    const list = $('#thList');
    if (!list) return;
    const cur = D().current();
    $('#thTag').textContent = cur ? `Tagged: ${cur.slice(0, 48)}` : '';
    list.innerHTML = TH.items.length ? TH.items.slice().reverse().map(t =>
      `<div class="th-item"><div class="th-meta">${esc(t.when)}${t.q ? ' · ' + esc(t.q) : ''}</div><div>${esc(t.text).replace(/\n/g, '<br>')}</div></div>`).join('')
      : '<p class="faint small">No thoughts yet for this class.</p>';
    $('#thInsightOut').innerHTML = TH.busy ? '<div class="insight faint">Reading your thoughts…</div>'
      : TH.insight ? `<div class="insight md">${D().md(TH.insight)}</div>` : '';
  }
  async function loadThoughts() {
    try { const r = await D().api('/api/thoughts?course=' + encodeURIComponent(D().course())); TH.items = r.items; TH.path = r.path; }
    catch (e) { TH.items = []; }
    drawThoughts();
  }
  async function saveThought() {
    const inp = $('#thIn');
    const text = inp.value.trim();
    if (!text) return;
    try {
      const r = await D().api('/api/thoughts/add', { text, course: D().course(), current: D().current() });
      TH.items = r.items; TH.path = r.path; inp.value = '';
      D().toast('Thought saved');
    } catch (e) { D().toast(e.message, 4000); }
    drawThoughts();
  }
  async function getInsight() {
    if (TH.busy) return;
    TH.busy = true; drawThoughts();
    try { TH.insight = (await D().api('/api/thoughts/insight', { course: D().course() })).text; }
    catch (e) { TH.insight = '⚠️ ' + e.message; }
    TH.busy = false; drawThoughts();
  }

  // ------------------------------------------------------------------ drawer
  let tab = 'calc';
  try { tab = localStorage.getItem('drc-tools-tab') || 'calc'; } catch (e) { /* storage off */ }
  function drawPane() {
    const body = $('#toolsBody');
    body.innerHTML = tab === 'calc' ? calcPane() : tab === 'ask' ? askPane() : thoughtsPane();
    document.querySelectorAll('#toolsTabs [data-tab]').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
    const c = (D().courses() || []).find(x => x.id === D().course());
    $('#toolsCourse').textContent = c ? c.code : '';
    if (tab === 'calc') {
      $('#calcHist').innerHTML = calcHist.map(x => `<button class="hist-row" data-src="${esc(x.src)}"><span class="mono">${esc(x.src)}</span><b>= ${esc(x.res)}</b></button>`).join('');
      $('#calcIn').focus();
    }
    if (tab === 'ask') { drawAsk(); $('#askIn').focus(); }
    if (tab === 'thoughts') { loadThoughts(); $('#thIn').focus(); }
  }
  // ------------------------------------------------------------------ window: dock / float / drag / resize / minimize
  // Docked = a side panel on the right (drag its left edge to make it wider or narrower).
  // Floating = a mini window: drag the title bar anywhere, resize from any edge or corner.
  // Dragging the title bar of the docked panel pops it out. Double-click the title bar = dock <-> float.
  const MIN_W = 280, MIN_H = 200;
  let G = { mode: 'dock', w: 380, x: 0, y: 0, fw: 420, fh: 560, min: false };
  try { Object.assign(G, JSON.parse(localStorage.getItem('drc-tools-geo') || '{}')); } catch (e) { /* defaults */ }
  const saveGeo = () => { try { localStorage.setItem('drc-tools-geo', JSON.stringify(G)); } catch (e) { /* ignore */ } };
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

  function fitFloat() {
    const W = innerWidth, H = innerHeight;
    G.fw = clamp(G.fw, MIN_W, W); G.fh = clamp(G.fh, MIN_H, H);
    G.x = clamp(G.x, 0, W - Math.min(G.fw, 120)); G.y = clamp(G.y, 0, H - 44);
  }
  function applyGeo() {
    const el = $('#tools');
    if (!el) return;
    const float = G.mode === 'float';
    el.classList.toggle('floating', float);
    el.classList.toggle('minimized', !!G.min);
    document.body.classList.toggle('tools-docked', !float);
    if (float) {
      fitFloat();
      Object.assign(el.style, { left: G.x + 'px', top: G.y + 'px', width: G.fw + 'px', height: G.fh + 'px', right: 'auto', bottom: 'auto' });
    } else {
      G.w = clamp(G.w, MIN_W, Math.max(MIN_W, innerWidth - 200));
      Object.assign(el.style, { left: 'auto', top: '0', right: '0', bottom: '0', width: G.w + 'px', height: 'auto' });
      document.body.style.setProperty('--tools-w', G.w + 'px');
    }
    const dock = $('#toolsDock'); if (dock) dock.textContent = float ? '⇥' : '⧉';
    const mn = $('#toolsMin'); if (mn) mn.textContent = G.min ? '▢' : '—';
  }
  function setMode(mode, at) {
    if (mode === 'float' && G.mode !== 'float') {
      const el = $('#tools').getBoundingClientRect();
      G.fw = Math.min(G.fw || 420, el.width || 420);
      G.fh = G.fh || 560;
      G.x = at ? at.x - G.fw / 2 : innerWidth - G.fw - 24;
      G.y = at ? at.y - 18 : 70;
    }
    G.mode = mode; G.min = mode === 'dock' ? false : G.min;
    applyGeo(); saveGeo();
  }

  function startDrag(e, dir) {
    const el = $('#tools');
    const r = el.getBoundingClientRect();
    const s = { x: e.clientX, y: e.clientY, l: r.left, t: r.top, w: r.width, h: r.height, moved: false };
    document.body.classList.add('tools-resizing');
    const move = ev => {
      const dx = ev.clientX - s.x, dy = ev.clientY - s.y;
      if (!dir) { // move the window
        if (!s.moved && Math.abs(dx) + Math.abs(dy) < 5) return;
        s.moved = true;
        if (G.mode === 'dock') { setMode('float', { x: ev.clientX, y: ev.clientY }); s.l = G.x - dx; s.t = G.y - dy; }
        G.x = s.l + dx; G.y = s.t + dy;
      } else if (G.mode === 'dock') { // docked: only the left edge, it sets the width
        G.w = s.w - dx;
      } else {
        if (dir.includes('e')) G.fw = Math.max(MIN_W, s.w + dx);
        if (dir.includes('s')) G.fh = Math.max(MIN_H, s.h + dy);
        if (dir.includes('w')) { G.fw = Math.max(MIN_W, s.w - dx); G.x = s.l + s.w - G.fw; }
        if (dir.includes('n')) { G.fh = Math.max(MIN_H, s.h - dy); G.y = s.t + s.h - G.fh; }
      }
      applyGeo();
    };
    const up = () => {
      removeEventListener('pointermove', move); removeEventListener('pointerup', up);
      document.body.classList.remove('tools-resizing');
      saveGeo();
    };
    addEventListener('pointermove', move); addEventListener('pointerup', up);
    e.preventDefault();
  }
  document.addEventListener('pointerdown', e => {
    if (e.button !== 0) return;
    const rh = e.target.closest('#tools .rh');
    if (rh) return startDrag(e, rh.dataset.dir);
    if (e.target.closest('#tools .tools-head') && !e.target.closest('button')) startDrag(e, '');
  });
  document.addEventListener('dblclick', e => {
    if (e.target.closest('#tools .tools-head') && !e.target.closest('button')) setMode(G.mode === 'float' ? 'dock' : 'float');
  });
  addEventListener('resize', () => { if (document.body.classList.contains('tools-open')) applyGeo(); });

  function toggle(open) {
    const on = open === undefined ? !document.body.classList.contains('tools-open') : open;
    document.body.classList.toggle('tools-open', on);
    if (on) { applyGeo(); drawPane(); }
  }
  window.DRC_TOOLS = { toggle };

  document.addEventListener('click', e => {
    if (e.target.closest('[data-tools-toggle]')) { e.preventDefault(); return toggle(); }
    const panel = e.target.closest('#tools');
    if (!panel) return;
    const t = e.target.closest('[data-tab]');
    if (t) { tab = t.dataset.tab; try { localStorage.setItem('drc-tools-tab', tab); } catch (x) { /* ignore */ } return drawPane(); }
    if (e.target.closest('#toolsClose')) return toggle(false);
    if (e.target.closest('#toolsDock')) return setMode(G.mode === 'float' ? 'dock' : 'float');
    if (e.target.closest('#toolsMin')) {
      if (G.mode === 'dock') setMode('float');
      G.min = !G.min; applyGeo(); saveGeo(); return;
    }
    const k = e.target.closest('[data-k]');
    if (k) {
      const inp = $('#calcIn');
      if (k.dataset.k === 'C') { inp.value = ''; $('#calcOut').innerHTML = ''; }
      else inp.value += k.dataset.k;
      return inp.focus();
    }
    const hr = e.target.closest('.hist-row');
    if (hr) { $('#calcIn').value = hr.dataset.src; return runCalc(); }
    if (e.target.closest('#askGo')) return runAsk();
    if (e.target.closest('#askNew')) { ASK.sid = null; ASK.msgs = []; return drawAsk(); }
    if (e.target.closest('#thSave')) return saveThought();
    if (e.target.closest('#thInsight')) return getInsight();
    if (e.target.closest('#thOpen') && TH.path) return D().api('/api/open', { path: TH.path }).catch(x => D().toast(x.message));
  });
  document.addEventListener('keydown', e => {
    if (e.target.id === 'calcIn' && e.key === 'Enter') { e.preventDefault(); runCalc(); }
    if (e.target.id === 'askIn' && e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); runAsk(); }
    if (e.target.id === 'thIn' && e.key === 'Enter' && e.ctrlKey) { e.preventDefault(); saveThought(); }
    if (e.key === 'Escape' && document.body.classList.contains('tools-open') && e.target.closest && e.target.closest('#tools')) toggle(false);
  });
  window.DRC_CALC = calc; // for testing
})();
