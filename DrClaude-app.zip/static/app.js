// Dr. Claude front end (plain JS, no build step, no libraries).
// The system:  hash router  ->  screen renderers  ->  /api/* on the local Python server (127.0.0.1 only).
// Classroom chat streams over POST /api/chat/send (Server-Sent Events read with fetch).
(function () {
  'use strict';

  // ------------------------------------------------------------------ helpers
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
  const h = s => MD.esc(String(s == null ? '' : s));
  const md = s => MD.render(s || '');
  const view = $('#view');
  const STATUS = ['✅', '🟡', '❌', '⬜'];
  const MCLASS = { '✅': 'm-ok', '🟡': 'm-shaky', '❌': 'm-no', '⬜': 'm-none' };
  const MODE_INFO = {
    'Lecture': 'Teaches the next topic on the Pacing Calendar.',
    'Homework': "A problem set like your professor's. You try first.",
    'Quiz': 'A quiz in the real quiz format, one question at a time.',
    'Mock Exam': 'A practice exam built like the real one, graded at the end.',
    'Office Hours': "Ask about anything you're stuck on.",
    'Replay a Course': 'Re-take a course week by week.',
    'Log a Class': "Tell Dr. Claude what today's real class covered.",
  };
  const STUDY_MODES = new Set(Object.keys(MODE_INFO).filter(m => m !== 'Log a Class'));

  const APP = { state: null, tok: 0 };

  async function api(path, body) {
    const opt = body === undefined ? {} : {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Dr-Claude': '1' },
      body: JSON.stringify(body),
    };
    const r = await fetch(path, opt);
    let j = {};
    try { j = await r.json(); } catch (e) { /* not json */ }
    if (!r.ok) throw new Error(j.error || `${r.status} ${r.statusText}`);
    return j;
  }

  let toastTimer = 0;
  function toast(msg, ms = 2600) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), ms);
  }

  const lsGet = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* private mode */ } };

  const dateOf = iso => new Date(iso.length <= 10 ? iso + 'T12:00:00' : iso);
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const DAY = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const fmtDay = iso => { const d = dateOf(iso); return `${DAY[d.getDay()]} ${MON[d.getMonth()]} ${d.getDate()}`; };
  const fmtTime = iso => dateOf(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const fmtStamp = iso => iso ? `${fmtDay(iso)}, ${fmtTime(iso)}` : '';
  const fmtMin = m => m >= 60 ? `${Math.floor(m / 60)}h ${Math.round(m % 60)}m` : `${Math.round(m)}m`;
  const fmtSize = b => b < 1024 ? `${b} B` : b < 1048576 ? `${(b / 1024).toFixed(0)} KB` : `${(b / 1048576).toFixed(1)} MB`;
  const baseName = p => String(p || '').split(/[\\/]/).filter(Boolean).pop() || p;
  const courses = (past = false) => (APP.state ? APP.state.courses : []).filter(c => !!c.past === past);
  const courseById = id => (APP.state ? APP.state.courses : []).find(c => c.id === id);
  const stripMarkers = s => String(s || '').replace(/```record-update[\s\S]*?(```|$)/g, '')
    .replace(/[ \t]*\[\[\s*(?:logpose|timer)[^\]]*\]\][ \t]*\n?/gi, '').replace(/\[\[\s*[lt]?[a-z]*[^\]]*$/i, '').trimEnd();

  function mbar(counts) {
    const total = STATUS.reduce((a, s) => a + (counts[s] || 0), 0);
    if (!total) return '<div class="mbar"></div>';
    return '<div class="mbar">' + STATUS.map(s => counts[s] ?
      `<span class="${MCLASS[s]}" style="width:${(100 * counts[s] / total).toFixed(2)}%" title="${counts[s]} ${s}"></span>` : '').join('') + '</div>';
  }
  const mcounts = counts => `<div class="mcounts">${STATUS.map(s => `<span>${s} ${counts[s] || 0}</span>`).join('')}</div>`;

  function emptyBox(icon, title, text, extra = '') {
    return `<div class="empty"><div class="big">${icon}</div><h2>${h(title)}</h2><p>${text}</p>${extra}</div>`;
  }

  async function openPath(path, how = 'default') {
    try {
      await api('/api/open', { path, how });
      toast(how === 'reveal' ? 'Showing it in File Explorer…' : `Opening ${baseName(path)}…`);
    } catch (e) { toast(e.message, 4000); }
  }

  // ------------------------------------------------------------------ theme
  const THEMES = ['system', 'light', 'dark'];
  const THEME_ICON = { system: '◐', light: '☀', dark: '☾' };
  function applyTheme(t) {
    if (!THEMES.includes(t)) t = 'system';
    const root = document.documentElement;
    if (t === 'system') root.removeAttribute('data-theme'); else root.setAttribute('data-theme', t);
    lsSet('drc-theme', t);
    $('#themeIcon').textContent = THEME_ICON[t];
    $('#themeBtn').title = `Theme: ${t} (click to switch)`;
    return t;
  }
  $('#themeBtn').addEventListener('click', async () => {
    const cur = (APP.state && APP.state.settings.theme) || lsGet('drc-theme') || 'system';
    const t = applyTheme(THEMES[(THEMES.indexOf(cur) + 1) % THEMES.length]);
    toast(`Theme: ${t}`);
    try { const r = await api('/api/settings', { theme: t }); APP.state.settings = r.settings; } catch (e) { /* keep local */ }
  });

  // ------------------------------------------------------------------ router
  function parseHash() {
    const raw = location.hash.replace(/^#\/?/, '');
    const [p, qs] = raw.split('?');
    const parts = (p || '').split('/');
    return { route: parts[0] || 'home', arg: decodeURIComponent(parts.slice(1).join('/') || ''), q: new URLSearchParams(qs || '') };
  }

  const ROUTES = {
    home: renderHome, classroom: renderClassroom, courses: renderCourses, library: renderLibrary,
    gradebook: renderGradebook, command: renderCommand, settings: renderSettings, welcome: renderWelcome,
  };

  async function route() {
    let { route: r, arg, q } = parseHash();
    if (APP.state && !APP.state.profile.onboarded && r !== 'welcome') { history.replaceState(null, '', '#/welcome'); r = 'welcome'; }
    const fn = ROUTES[r] || renderHome;
    const tok = ++APP.tok;
    $$('.nav a').forEach(a => a.classList.toggle('active', a.dataset.route === (ROUTES[r] ? r : 'home')));
    view.classList.toggle('flush', r === 'classroom');
    document.body.classList.toggle('setup', r === 'welcome');
    if (r !== 'classroom') view.scrollTop = 0;
    try {
      await fn(tok, arg, q);
    } catch (e) {
      console.error(e);
      if (tok === APP.tok) view.innerHTML = emptyBox('⚠️', 'Something went wrong', h(e.message),
        '<button class="btn" onclick="location.reload()">Reload</button>');
    }
  }
  const stale = tok => tok !== APP.tok;
  window.addEventListener('hashchange', route);

  // ------------------------------------------------------------------ HOME / office
  const firstName = () => ((APP.state && APP.state.profile && APP.state.profile.name) || '').trim().split(/\s+/)[0];
  function greeting() {
    const hr = new Date().getHours();
    const n = firstName() ? ', ' + h(firstName()) : '';
    return (hr < 5 ? 'Up late' : hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening') + n;
  }

  function weeklyChart(rows) {
    if (!rows.length) return '<p class="muted small">No study sessions yet. Study modes time themselves.</p>';
    const max = Math.max(30, ...rows.map(r => Math.max(r.this, r.last)));
    const W = 300, L = 74, R = 48, rowH = 34;
    const bw = v => Math.max(2, (W - L - R) * v / max);
    let s = `<svg viewBox="0 0 ${W} ${rows.length * rowH + 2}" role="img" aria-label="Study minutes per class, this week and last week">`;
    rows.forEach((r, i) => {
      const y = i * rowH + 2;
      s += `<text x="0" y="${y + 16}">${h(r.class)}</text>`;
      s += `<rect x="${L}" y="${y + 2}" width="${bw(r.this)}" height="13" rx="3" style="fill:var(--gold)"><title>This week: ${fmtMin(r.this)}</title></rect>`;
      s += `<text class="val" x="${L + bw(r.this) + 6}" y="${y + 13}">${r.this ? fmtMin(r.this) : '0'}</text>`;
      s += `<rect x="${L}" y="${y + 19}" width="${bw(r.last)}" height="8" rx="3" style="fill:var(--surface-3)"><title>Last week: ${fmtMin(r.last)}</title></rect>`;
      if (r.last) s += `<text x="${L + bw(r.last) + 6}" y="${y + 27}" style="font-size:10.5px">${fmtMin(r.last)}</text>`;
    });
    return s + '</svg>';
  }

  function deadlineRow(d) {
    const dt = dateOf(d.date);
    const heat = d.days <= 1 ? ' hot' : d.days <= 3 ? ' warm' : '';
    const exam = d.kind === 'exam' || /\b(quiz|midterm|final|exam|test)\b/i.test(d.title);
    return `<div class="deadline"><div class="dday${heat}"><b>${dt.getDate()}</b><span>${MON[dt.getMonth()]}</span></div>
      <div><div class="dl-title">${h(d.title)}</div>
      <div class="small muted">${h(d.when)}${d.time ? ' · ' + h(d.time) : ''} ${d.class ? `<span class="chip${exam ? ' exam' : ''}">${h(d.class)}</span>` : ''}</div></div></div>`;
  }

  function courseCard(c) {
    const next = c.next ? `${h(c.next.title)} <span class="faint">(${h(c.next.when)})</span>` : '<span class="faint">nothing coming up</span>';
    const last = c.last_studied_days == null ? 'not yet' : c.last_studied_days === 0 ? 'today' :
      c.last_studied_days === 1 ? 'yesterday' : `${c.last_studied_days} days ago`;
    const total = STATUS.reduce((a, s) => a + (c.counts[s] || 0), 0);
    return `<div class="card course-card">
      <div><div class="code">${h(c.code)}</div><div class="title">${h(c.title)}</div></div>
      <dl class="kv"><dt>Professor</dt><dd>${h(c.professor || '?')}</dd>
        ${c.meets && c.meets !== '?' ? `<dt>Meets</dt><dd>${h(c.meets.split('(')[0].trim())}</dd>` : ''}
        <dt>Next up</dt><dd>${next}</dd><dt>Last studied</dt><dd>${last}</dd></dl>
      ${total ? mbar(c.counts) + mcounts(c.counts) : '<div class="small faint">Mastery fills in as you study.</div>'}
      <div class="row"><a class="btn sm" href="#/courses/${encodeURIComponent(c.id)}">Course record</a>
        <a class="btn sm ghost" href="#/library?course=${encodeURIComponent(c.id)}">Files</a></div>
      <a class="btn primary big" href="#/classroom?course=${encodeURIComponent(c.id)}">Study ${h(c.code)}</a>
    </div>`;
  }

  async function renderHome(tok) {
    view.innerHTML = '<div class="loading">Opening the office…</div>';
    const [d, cv] = await Promise.all([api('/api/dashboard'), api('/api/canvas/status').catch(() => ({}))]);
    if (stale(tok)) return;
    const b = d.bounty || {};
    const today = dateOf(d.today);
    const plan = d.plan.length ? d.plan.map((p, i) => `<div class="plan-item"><div class="plan-num">${i + 1}</div>
        <div><b>${h(p.title)}</b><div class="why">${h(p.why)}</div></div>
        <a class="btn sm primary" href="#/classroom?course=${encodeURIComponent(p.course)}&mode=${encodeURIComponent(p.mode)}" title="Open the Classroom in ${h(p.mode)} mode">${h(p.mode)}</a></div>`).join('')
      : '<p class="muted">Nothing urgent. Pick any class below, or open Office Hours.</p>';
    const syncLine = cv.connected ? `Canvas synced ${cv.synced ? h(fmtStamp(cv.synced)) : 'not yet'}` : 'Canvas not connected';
    view.innerHTML = `
      <div class="hero"><div><div class="eyebrow">Dr. Claude's office</div><h1>${greeting()}</h1>
        <div class="date">${today.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</div></div>
        <div class="bounty"><div class="label">Studied today</div><div class="amount">${fmtMin(b.todayMin || 0)}</div>
        <div class="meta">${fmtMin(b.weekMin || 0)} this week · ${b.streakDays || 0}-day streak${b.running ? ' · ⏱ timer running' : ''}</div></div></div>
      <div class="grid g-home">
        <div class="card"><h2>⏰ Coming up <span class="count">from Canvas</span></h2>
          ${d.deadlines.length ? d.deadlines.map(deadlineRow).join('') : '<p class="muted">Nothing due. Nice.</p>'}</div>
        <div class="card chart"><h2>📊 Study minutes <span class="count">week of ${fmtDay(d.week_start)}</span></h2>
          ${weeklyChart(d.weekly)}
          <div class="legend"><span><i style="background:var(--gold)"></i>This week</span><span><i style="background:var(--surface-3)"></i>Last week</span></div></div>
        <div class="card plan"><h2>🧭 Today's plan</h2>${plan}</div>
      </div>
      <div class="row" style="margin:26px 0 12px;justify-content:space-between"><h2 style="font-size:19px;margin:0">Your classes</h2>
        <div class="row"><span class="small faint" id="syncLine">${syncLine}</span>
        ${cv.has_token ? '<button class="btn sm" id="resync" title="Download anything new from Canvas">⟳ Re-sync Canvas</button>'
          : cv.connected ? `<a class="btn sm" href="${h(cv.url || 'https://canvas.cpp.edu')}" target="_blank" rel="noopener" title="Open Canvas, then click 🎓 Sync Dr. Claude on your bookmarks bar">⟳ Re-sync (opens Canvas)</a>`
          : '<a class="btn sm" href="#/settings">Connect Canvas</a>'}</div></div>
      <div id="syncBox"></div>
      ${d.courses.length ? `<div class="grid g-courses">${d.courses.map(courseCard).join('')}</div>`
        : emptyBox('📚', 'No classes yet', cv.connected ? 'Re-sync Canvas to pull in your classes.' : 'Connect Canvas in Settings, or add a class by hand in Courses and upload your own files.',
          '<div class="row" style="justify-content:center"><a class="btn primary" href="#/settings">Connect Canvas</a><a class="btn" href="#/courses?add=1">Add a class by hand</a></div>')}`;
    const rs = $('#resync');
    if (rs) rs.addEventListener('click', async () => {
      try { await api('/api/canvas/sync', {}); watchSync($('#syncBox'), tok, () => { refreshState().then(() => { if (!stale(tok)) route(); }); }); }
      catch (e) { toast(e.message, 4000); }
    });
    if (cv.running) watchSync($('#syncBox'), tok, () => { refreshState().then(() => { if (!stale(tok)) route(); }); });
  }

  async function refreshState() { try { APP.state = await api('/api/state'); } catch (e) { /* keep old */ } }

  // Canvas sync progress box (Home, Settings, setup). Polls until the sync stops, then calls done().
  function watchSync(box, tok, done) {
    if (!box) return;
    const draw = st => {
      const pct = st.total ? Math.round(100 * st.done / st.total) : 0;
      box.innerHTML = `<div class="card sync-card"><div class="row" style="justify-content:space-between"><b>${st.running ? '⟳ ' : ''}${h(st.phase || 'Canvas')}</b>
          <span class="small muted">${st.files_new || 0} new file${st.files_new === 1 ? '' : 's'} · ${st.files_same || 0} already here</span></div>
        ${st.running ? `<div class="progress"><span style="width:${st.total ? pct : 8}%"></span></div>` : ''}
        ${st.course ? `<div class="small muted">${h(st.course)}</div>` : ''}
        <div class="sync-log small faint">${(st.log || []).slice(-5).map(x => `<div>${h(x)}</div>`).join('')}</div>
        ${(st.errors || []).length ? `<details class="small"><summary>${st.errors.length} thing${st.errors.length === 1 ? '' : 's'} couldn't be downloaded</summary>${st.errors.map(x => `<div>${h(x)}</div>`).join('')}</details>` : ''}</div>`;
    };
    const tick = async () => {
      if (stale(tok) && tok !== -1) return;
      let st;
      try { st = await api('/api/canvas/status'); } catch (e) { return; }
      draw(st);
      if (st.running) setTimeout(tick, 1200);
      else if (done) done(st);
    };
    tick();
  }

  // ------------------------------------------------------------------ CLASSROOM
  const CHAT = { sid: null, meta: null, messages: [], course: '', mode: 'Office Hours', sessions: [], running: false, poll: 0 };
  let LIVE = null;           // the one turn this window is streaming: {sid, text, tools, status, timer, error, ctrl}
  let REC = null;            // speech recognition
  let recOn = false;

  function courseOptions(sel) {
    const opt = c => `<option value="${h(c.id)}"${c.id === sel ? ' selected' : ''}>${h(c.code)} ${h(c.title)}</option>`;
    return `<option value="">Pick a class…</option>${courses().map(opt).join('')}`;
  }

  async function loadSessions() {
    try { const r = await api('/api/sessions'); CHAT.sessions = r.sessions || []; } catch (e) { CHAT.sessions = []; }
  }

  function historyHtml() {
    if (!CHAT.sessions.length) return '<p class="small faint" style="padding:6px 10px">No saved sessions yet. Your chats show up here so you can pick up where you left off.</p>';
    const now = new Date(); const day0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const group = s => {
      const d = dateOf(s.updated || s.created);
      const diff = Math.floor((day0 - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 864e5);
      return diff <= 0 ? 'Today' : diff === 1 ? 'Yesterday' : diff < 7 ? 'This week' : 'Earlier';
    };
    let out = '', last = '';
    for (const s of CHAT.sessions) {
      const g = group(s);
      if (g !== last) { out += `<div class="hist-group">${g}</div>`; last = g; }
      out += `<button class="hist-item${s.id === CHAT.sid ? ' active' : ''}" data-sid="${h(s.id)}" title="Double-click to rename">
        <div class="t">${h(s.title)}</div><div class="m">${h(s.mode)} · ${s.turns || 0} turn${s.turns === 1 ? '' : 's'} · ${fmtTime(s.updated || s.created)}</div></button>`;
    }
    return out;
  }

  function msgHtml(m) {
    if (m.role === 'user') return `<div class="msg user"><div class="bubble">${h(m.text)}</div></div>`;
    if (m.role === 'note') return `<div class="msg note"><div class="bubble md">${MD.inline(m.text)}</div></div>`;
    if (m.role === 'error') return `<div class="msg error"><div class="who">Problem</div><div class="bubble md">${md(m.text)}</div></div>`;
    const tools = (m.tools || []).length ? `<div class="tools">${m.tools.map(t => `<div class="tool">${h(t.icon)} ${h(t.text)}</div>`).join('')}</div>` : '';
    return `<div class="msg assistant"><div class="who">Dr. Claude</div>${tools}
      ${m.text ? `<div class="bubble md">${md(m.text)}</div>` : ''}${m.timer ? `<div class="timer-note">⏱ ${h(m.timer)}</div>` : ''}</div>`;
  }

  function emptyChatHtml() {
    const c = courseById(CHAT.course);
    return `<div class="empty-chat"><div class="big-cap">🎓</div>
      <h2>${c ? `${h(c.code)}: what are we doing?` : 'Pick a class, then a mode'}</h2>
      <p>${c ? 'Choose a mode below to start, or just type your first message.' : 'Choose the class at the top left. Then pick a mode or type a message.'}
      Study modes start the study timer by themselves.</p>
      <div class="mode-help">${APP.state.modes.map(m => `<button data-start="${h(m)}"><b>${h(m)}</b><span>${h(MODE_INFO[m] || '')}</span></button>`).join('')}</div></div>`;
  }

  function liveHtml() {
    const L = LIVE;
    const tools = L.tools.length ? `<div class="tools">${L.tools.map(t => `<div class="tool">${h(t.icon)} ${h(t.text)}</div>`).join('')}</div>` : '';
    const text = stripMarkers(L.text);
    return `<div class="who">Dr. Claude</div>${tools}${text ? `<div class="bubble md">${md(text)}</div>` : ''}
      <div class="thinking"><span class="dots"><i></i><i></i><i></i></span><span>${h(L.status || 'Thinking…')}</span></div>`;
  }

  const liveHere = () => LIVE && LIVE.sid === CHAT.sid;
  const busy = () => liveHere() || CHAT.running;

  function nearBottom(el) { return el.scrollHeight - el.scrollTop - el.clientHeight < 120; }
  function toBottom(force) {
    const box = $('#messages');
    if (box && (force || nearBottom(box))) box.scrollTop = box.scrollHeight;
  }

  function drawMessages(force = true) {
    const box = $('#messages');
    if (!box) return;
    const wasNear = nearBottom(box);
    if (!CHAT.sid && !CHAT.messages.length && !liveHere()) {
      box.innerHTML = emptyChatHtml();
      return;
    }
    let html = CHAT.messages.map(msgHtml).join('');
    if (liveHere()) html += `<div class="msg assistant" id="liveMsg">${liveHtml()}</div>`;
    else if (CHAT.running) html += `<div class="msg assistant"><div class="thinking"><span class="dots"><i></i><i></i><i></i></span><span>Still answering in the background… (this updates by itself)</span></div></div>`;
    box.innerHTML = html;
    if (force || wasNear) box.scrollTop = box.scrollHeight;
    drawQbar(); MD.hydrate($('#messages'));
  }

  // Sticky "current question" bar: the newest "## ▶ NOW: ..." heading the professor wrote.
  function currentQuestion() {
    const texts = CHAT.messages.filter(m => m.role === 'assistant').map(m => m.text || '');
    if (liveHere()) texts.push(LIVE.text || '');
    for (let k = texts.length - 1; k >= 0; k--) {
      const hits = [...texts[k].matchAll(/^\s{0,3}#{1,6}\s*▶\s*(.+?)\s*#*\s*$/gm)];
      if (hits.length) return hits[hits.length - 1][1];
    }
    return '';
  }
  // hooks for tools.js (side drawer)
  window.DRC = {
    api, toast, md,
    course: () => CHAT.course || (APP.state && APP.state.courses[0] ? APP.state.courses[0].id : ''),
    courses: () => (APP.state ? APP.state.courses : []),
    current: () => currentQuestion(),
  };

  function drawQbar() {
    const bar = $('#qbar');
    if (!bar) return;
    const q = currentQuestion();
    bar.style.display = q ? '' : 'none';
    if (q) $('#qbarText').innerHTML = MD.inline('▶ ' + q);
  }

  let liveRaf = 0;
  function drawLive() {
    if (liveRaf) return;
    liveRaf = requestAnimationFrame(() => {
      liveRaf = 0;
      const el = $('#liveMsg');
      if (!el || !liveHere()) return;
      const box = $('#messages');
      const near = nearBottom(box);
      el.innerHTML = liveHtml();
      if (near) box.scrollTop = box.scrollHeight;
      drawQbar(); MD.hydrate($('#messages'));
    });
  }

  function drawTop() {
    const top = $('#chatTop');
    if (!top) return;
    const started = !!CHAT.sid;
    const mode = started && CHAT.meta ? CHAT.meta.mode : CHAT.mode;
    const timerOn = started && APP.timerActive && APP.timerActive[CHAT.sid];
    $('#courseSel', top).innerHTML = courseOptions(started && CHAT.meta ? CHAT.meta.course : CHAT.course);
    $('#courseSel', top).disabled = started;
    $('#sessTitle', top).textContent = started && CHAT.meta ? CHAT.meta.title : 'New session';
    $('#timerPill', top).style.display = timerOn || (liveHere() && LIVE.timer) ? '' : 'none';
    $('#endStudy', top).style.display = started && STUDY_MODES.has(mode) && APP.state.settings.logpose ? '' : 'none';
    $('#retroBtn', top).style.display = started && CHAT.messages.length > 2 ? '' : 'none';
    $('#modes', top).innerHTML = APP.state.modes.map(m =>
      `<button class="mode${m === mode ? ' on' : ''}" data-mode="${h(m)}"${started ? ' disabled' : ''} title="${h(MODE_INFO[m] || '')}">${h(m)}</button>`).join('');
  }

  function drawComposer() {
    const btn = $('#sendBtn');
    if (!btn) return;
    const b = busy();
    btn.className = 'icon-btn ' + (b ? 'stop' : 'send');
    btn.textContent = b ? '■' : '➤';
    btn.title = b ? 'Stop Dr. Claude' : 'Send (Enter)';
    const ta = $('#input');
    ta.placeholder = CHAT.sid ? 'Answer or ask anything… (Enter to send, Shift+Enter for a new line)'
      : 'Type your first message, or pick a mode above to start…';
  }

  function drawHistory() {
    const el = $('#historyList');
    if (el) el.innerHTML = historyHtml();
  }

  function drawChat() { drawTop(); drawMessages(); drawComposer(); drawHistory(); }

  async function openSession(sid) {
    clearTimeout(CHAT.poll);
    const r = await api('/api/chat/history?sid=' + encodeURIComponent(sid));
    if (!r.session) { toast("That session wasn't found."); return newChat(); }
    CHAT.sid = sid; CHAT.meta = r.session; CHAT.messages = r.messages || [];
    CHAT.course = r.session.course; CHAT.mode = r.session.mode;
    CHAT.running = !!r.running && !(LIVE && LIVE.sid === sid);
    if (CHAT.running) CHAT.poll = setTimeout(() => { if (CHAT.sid === sid && parseHash().route === 'classroom') openSession(sid); }, 4000);
    else if (CHAT.wasRunning === sid) loadSessions().then(drawHistory);
    CHAT.wasRunning = CHAT.running ? sid : null;
    drawChat();
  }

  function newChat(course, mode) {
    clearTimeout(CHAT.poll);
    CHAT.sid = null; CHAT.meta = null; CHAT.messages = []; CHAT.running = false;
    if (course !== undefined) CHAT.course = course;
    if (mode && APP.state.modes.includes(mode)) CHAT.mode = mode;
    if (location.hash.startsWith('#/classroom/')) history.replaceState(null, '', '#/classroom');
    drawChat();
  }

  async function renderClassroom(tok, arg, q) {
    view.innerHTML = `<div class="classroom" id="classroom">
      <aside class="history"><div class="history-head"><h2>Sessions</h2><button class="btn sm" id="newBtn" title="Start a new session">＋ New</button></div>
        <div class="history-list" id="historyList"></div></aside>
      <section class="chat">
        <div class="chat-top" id="chatTop">
          <div class="row1">
            <button class="btn sm ghost only-narrow" id="histToggle" title="Show saved sessions">☰</button>
            <select class="course-select" id="courseSel" aria-label="Class"></select>
            <span class="session-title" id="sessTitle"></span>
            <span class="pill" id="timerPill" title="The study timer is running for this session"><span class="dot"></span>Timer on</span>
            <span class="spacer"></span>
            <button class="btn sm" data-tools-toggle title="Calculator, quick questions, and your thoughts">🧰 Tools</button>
            <button class="btn sm" id="retroBtn" title="Command reads this session and suggests up to 3 changes to how Dr. Claude teaches you">🔁 Retro</button>
            <button class="btn sm" id="endStudy" title="Save the study time and stop the timer">⏹ End study session</button>
          </div>
          <div class="modes" id="modes"></div>
        </div>
        <div class="qbar" id="qbar" style="display:none" title="The question you're working on right now">
          <span class="qbar-label">Working on</span><span class="qbar-text" id="qbarText"></span>
          <button class="btn sm ghost" id="qbarJump" title="Scroll to this question">Show ↓</button></div>
        <div class="messages" id="messages"></div>
        <div class="composer"><div class="composer-box">
          <textarea id="input" rows="1" aria-label="Message"></textarea>
          <button class="icon-btn" id="micBtn" title="Talk instead of typing (Ctrl+M)">🎤</button>
          <button class="icon-btn send" id="sendBtn" title="Send (Enter)">➤</button>
        </div>
        <div class="hint"><span>Enter = send · Shift+Enter = new line · Ctrl+M = mic</span><span class="interim" id="interim"></span></div></div>
      </section></div>`;
    wireClassroom();
    if (stale(tok)) return;
    try { const st = await api('/api/logpose/status'); APP.timerActive = st.active || {}; } catch (e) { APP.timerActive = {}; }
    await loadSessions();
    if (stale(tok)) return;
    if (arg) {
      if (arg !== CHAT.sid || !CHAT.meta) await openSession(arg);
      else drawChat();
    } else if (q.get('course') || q.get('mode')) {
      newChat(q.get('course') || CHAT.course, q.get('mode') || CHAT.mode);
      history.replaceState(null, '', '#/classroom');
    } else if (CHAT.sid) {
      history.replaceState(null, '', '#/classroom/' + CHAT.sid);
      await openSession(CHAT.sid);
    } else drawChat();
    if (!stale(tok)) $('#input').focus();
  }

  function autosize() {
    const ta = $('#input');
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 220) + 'px';
  }

  function wireClassroom() {
    const root = $('#classroom');
    const ta = $('#input');
    ta.addEventListener('input', autosize);
    ta.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); if (!busy()) submit(); }
    });
    $('#sendBtn').addEventListener('click', () => busy() ? stopTurn() : submit());
    $('#micBtn').addEventListener('click', toggleMic);
    $('#qbarJump').addEventListener('click', () => {
      const hs = $('#messages').querySelectorAll('.qhead');
      if (hs.length) hs[hs.length - 1].scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    $('#newBtn').addEventListener('click', () => { root.classList.remove('show-history'); newChat(CHAT.course); ta.focus(); });
    $('#histToggle').addEventListener('click', () => root.classList.toggle('show-history'));
    $('#courseSel').addEventListener('change', e => { CHAT.course = e.target.value; drawMessages(); });
    $('#endStudy').addEventListener('click', async () => {
      try {
        const r = await api('/api/logpose', { action: 'end', sid: CHAT.sid || '' });
        APP.timerActive = {};
        drawTop();
        toast(r.text || 'Study session ended.', 5000);
      } catch (e) { toast(e.message, 4000); }
    });
    $('#retroBtn').addEventListener('click', () => { if (CHAT.sid) location.hash = '#/command?retro=' + encodeURIComponent(CHAT.sid); });
    $('#modes').addEventListener('click', e => {
      const b = e.target.closest('[data-mode]');
      if (b && !b.disabled) { CHAT.mode = b.dataset.mode; drawTop(); ta.focus(); }
    });
    $('#messages').addEventListener('click', e => {
      const b = e.target.closest('[data-start]');
      if (!b) return;
      CHAT.mode = b.dataset.start;
      drawTop();
      submit();
    });
    const hl = $('#historyList');
    hl.addEventListener('click', e => {
      const b = e.target.closest('[data-sid]');
      if (!b) return;
      root.classList.remove('show-history');
      if (b.dataset.sid !== CHAT.sid) location.hash = '#/classroom/' + b.dataset.sid;
    });
    hl.addEventListener('dblclick', async e => {
      const b = e.target.closest('[data-sid]');
      if (!b) return;
      const s = CHAT.sessions.find(x => x.id === b.dataset.sid);
      const title = s && prompt('Rename this session:', s.title);
      if (!title || !title.trim()) return;
      await api('/api/chat/rename', { sid: s.id, title: title.trim() });
      s.title = title.trim();
      if (CHAT.meta && CHAT.meta.id === s.id) CHAT.meta.title = s.title;
      drawHistory(); drawTop();
    });
  }

  function submit() {
    const ta = $('#input');
    const text = ta.value.trim();
    if (CHAT.sid && !text) return;
    if (!CHAT.sid && !CHAT.course) { toast('Pick a class first (top left).'); $('#courseSel').focus(); return; }
    if (LIVE) { toast('Dr. Claude is still answering another session. Wait or press Stop there.'); return; }
    if (recOn) stopMic();
    ta.value = ''; autosize();
    sendTurn(text);
  }

  async function sendTurn(text) {
    const startSid = CHAT.sid;
    const body = startSid ? { sid: startSid, text } : { course: CHAT.course, mode: CHAT.mode, text };
    const c = courseById(CHAT.course);
    CHAT.messages.push(text ? { role: 'user', text } : { role: 'note', text: `Started **${CHAT.mode}** for **${c ? c.code : CHAT.course}**` });
    const L = LIVE = { sid: startSid, text: '', tools: [], status: 'Waking Dr. Claude…', timer: '', error: '', ctrl: new AbortController() };
    drawMessages(true); drawComposer();
    let doneEv = null, gotSession = false;
    const handle = ev => {
      switch (ev.t) {
        case 'session':
          L.sid = ev.session.id; gotSession = true;
          if (CHAT.sid === startSid && !startSid && parseHash().route === 'classroom') {
            CHAT.sid = ev.session.id; CHAT.meta = ev.session;
            history.replaceState(null, '', '#/classroom/' + CHAT.sid);
            loadSessions().then(drawHistory);
            drawTop();
          }
          break;
        case 'timer':
          L.timer = ev.text;
          APP.timerActive = Object.assign({}, APP.timerActive, { [L.sid]: true });
          toast('⏱ ' + ev.text);
          drawTop();
          break;
        case 'status': L.status = ev.text; break;
        case 'tool': L.tools.push({ icon: ev.icon, text: ev.text }); L.status = ev.text + '…'; break;
        case 'text': L.text += ev.delta || ''; L.status = 'Writing…'; break;
        case 'error': L.error = ev.text; break;
        case 'done': doneEv = ev; break;
      }
      drawLive();
    };
    try {
      const res = await fetch('/api/chat/send', {
        method: 'POST', signal: L.ctrl.signal,
        headers: { 'Content-Type': 'application/json', 'X-Dr-Claude': '1' }, body: JSON.stringify(body),
      });
      if (!res.ok || !res.body) {
        let j = {}; try { j = await res.json(); } catch (e) { /* ignore */ }
        throw new Error(j.error || `${res.status} ${res.statusText}`);
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      for (;;) {
        const { value, done } = await reader.read();
        if (value) buf += dec.decode(value, { stream: true });
        let k;
        while ((k = buf.indexOf('\n\n')) >= 0) {
          const chunk = buf.slice(0, k); buf = buf.slice(k + 2);
          for (const line of chunk.split('\n')) {
            if (line.startsWith('data:')) { try { handle(JSON.parse(line.slice(5))); } catch (e) { console.warn('bad event', line); } }
          }
        }
        if (done) break;
      }
    } catch (e) {
      if (e.name !== 'AbortError') L.error = L.error || e.message;
    }
    // finish: the server's saved chat is the source of truth
    LIVE = null;
    if (doneEv && doneEv.timer) toast('⏱ ' + doneEv.timer);
    if (doneEv && /ended|saved/i.test(doneEv.timer || '')) delete APP.timerActive[L.sid];
    const here = L.sid && CHAT.sid === L.sid;
    if (here) {
      try {
        const r = await api('/api/chat/history?sid=' + encodeURIComponent(L.sid));
        CHAT.meta = r.session || CHAT.meta;
        CHAT.messages = r.messages || CHAT.messages;
      } catch (e) {
        if (L.text) CHAT.messages.push({ role: 'assistant', text: stripMarkers(L.text), tools: L.tools, timer: doneEv && doneEv.timer });
      }
    } else if (!L.sid && !CHAT.sid) {
      // never got a session (server refused): keep the user's text so it isn't lost
      CHAT.messages = [];
    }
    const ta = $('#input');
    if (!gotSession && text && ta && !ta.value) ta.value = text;  // server refused: give the text back
    if (L.error && (here || (!L.sid && !CHAT.sid))) CHAT.messages.push({ role: 'error', text: L.error });
    if (!here && L.sid && !L.error) toast('Dr. Claude finished answering in another session.');
    await loadSessions();
    if (parseHash().route === 'classroom') drawChat();
  }

  async function stopTurn() {
    if (CHAT.running && !liveHere()) {
      await api('/api/chat/stop', { sid: CHAT.sid }).catch(() => {});
      toast('Stopping…');
      return;
    }
    if (!LIVE) return;
    if (LIVE.sid) {
      try { await api('/api/chat/stop', { sid: LIVE.sid }); } catch (e) { LIVE.ctrl.abort(); }
    } else LIVE.ctrl.abort();
    toast('Stopped.');
  }

  // ---- voice typing (Web Speech API)
  function toggleMic() { recOn ? stopMic() : startMic(); }
  function stopMic() {
    recOn = false;
    if (REC) try { REC.stop(); } catch (e) { /* already stopped */ }
    const b = $('#micBtn'); if (b) b.classList.remove('listening');
    const i = $('#interim'); if (i) i.textContent = '';
  }
  function startMic() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { toast("Voice typing isn't available in this window. Use Windows voice typing instead (Win+H).", 5000); return; }
    REC = new SR();
    REC.lang = 'en-US'; REC.continuous = true; REC.interimResults = true;
    REC.onresult = e => {
      const ta = $('#input'); if (!ta) return;
      let interim = '';
      for (let k = e.resultIndex; k < e.results.length; k++) {
        const r = e.results[k];
        if (r.isFinal) {
          const t = r[0].transcript.trim();
          if (t) ta.value += (ta.value && !/\s$/.test(ta.value) ? ' ' : '') + t;
        } else interim += r[0].transcript;
      }
      const i = $('#interim'); if (i) i.textContent = interim ? '🎤 ' + interim : '🎤 listening…';
      autosize();
    };
    REC.onerror = e => {
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') toast('Microphone is blocked. Allow it in the address-bar prompt, or use Win+H.', 5000);
      else if (e.error === 'network') toast("Voice typing needs internet. Try Win+H (Windows voice typing).", 5000);
      else if (e.error !== 'no-speech' && e.error !== 'aborted') toast('Mic error: ' + e.error);
      if (e.error !== 'no-speech') stopMic();
    };
    REC.onend = () => { if (recOn) { try { REC.start(); } catch (e) { stopMic(); } } };
    try {
      REC.start();
      recOn = true;
      $('#micBtn').classList.add('listening');
      $('#interim').textContent = '🎤 listening…';
    } catch (e) { toast('Could not start the mic: ' + e.message); }
  }

  // ------------------------------------------------------------------ COURSES
  const TABS = [
    ['overview', 'Overview'], ['pacing', 'Pacing Calendar'], ['assessments', 'Assessment Log'],
    ['mastery', 'Mastery'], ['patterns', 'Professor habits'], ['timeline', 'Canvas calendar'],
  ];
  const TAB_EMPTY = {
    overview: 'No course facts in the Course Record yet.',
    pacing: 'No Pacing Calendar yet. After class, open the Classroom in <b>Log a Class</b> mode and tell Claude what was covered.',
    assessments: 'No quizzes or exams logged yet. Log them in <b>Log a Class</b> mode.',
    mastery: 'No mastery table yet. It fills in as you study with Dr. Claude.',
    patterns: "No professor habits logged yet (how they write quizzes, what they repeat, what they grade hard).",
    timeline: 'No Canvas calendar for this class (it fills in when Canvas syncs).',
  };

  async function renderCourses(tok, arg, q) {
    const list = courses();
    const id = arg || lsGet('drc-course') || (list[0] && list[0].id);
    const tab = q.get('tab') || lsGet('drc-course-tab') || 'overview';
    const picker = `<div class="course-pick">${list.map(c => `<button class="cpick${c.id === id ? ' on' : ''}" data-c="${h(c.id)}"><b>${h(c.code)}</b><span>${h(c.professor || c.title)}</span></button>`).join('')}</div>`;
    if (!id || q.get('add')) {
      view.innerHTML = `<div class="page-head"><div><div class="eyebrow">Course records</div><h1>Courses</h1></div></div>${list.length ? picker : ''}
        ${list.length ? '' : emptyBox('📚', 'No classes yet', 'Connect Canvas in Settings to bring them in, or add one by hand below.')}<div id="addBox"></div>`;
      addClassForm($('#addBox'), c => { location.hash = '#/library?course=' + encodeURIComponent(c); });
      const pk = view.querySelector('.course-pick');
      if (pk) pk.addEventListener('click', e => { const b = e.target.closest('[data-c]'); if (b) location.hash = `#/courses/${encodeURIComponent(b.dataset.c)}`; });
      return;
    }
    view.innerHTML = `<div class="page-head"><div><div class="eyebrow">Course records</div><h1>Courses</h1></div></div>${picker}<div class="loading">Loading…</div>`;
    view.querySelector('.course-pick').addEventListener('click', e => {
      const b = e.target.closest('[data-c]');
      if (b) location.hash = `#/courses/${encodeURIComponent(b.dataset.c)}?tab=${tab}`;
    });
    const d = await api('/api/course?id=' + encodeURIComponent(id));
    if (stale(tok)) return;
    lsSet('drc-course', id); lsSet('drc-course-tab', tab);
    const c = d.course, sec = d.sections || {};
    const body = sec[tab] ? `<div class="doc md">${md(sec[tab])}</div>` : emptyBox('📝', 'Nothing here yet', TAB_EMPTY[tab] || '');
    const total = STATUS.reduce((a, s) => a + (d.counts[s] || 0), 0);
    view.innerHTML = `<div class="page-head"><div><div class="eyebrow">Course record</div><h1>${h(c.code)} ${h(c.title)}</h1>
        <div class="sub">${h(c.professor || '')}${c.term ? ' · ' + h(c.term) : ''}</div></div>
        <div class="row"><a class="btn primary" href="#/classroom?course=${encodeURIComponent(c.id)}">🎓 Study this</a>
        ${c.record ? '<button class="btn" id="openRec" title="Open the Course Record file">Open record</button>' : ''}
        <a class="btn ghost" href="#/library?course=${encodeURIComponent(c.id)}">📁 Files</a>
        <a class="btn ghost" href="#/courses?add=1" title="Add a class that isn't on Canvas">＋ Class</a></div></div>
      ${picker}
      ${total ? `<div class="card" style="margin-bottom:16px;padding:14px 18px"><div class="row" style="justify-content:space-between"><b>Mastery</b>${mcounts(d.counts)}</div><div style="margin-top:8px">${mbar(d.counts)}</div></div>` : ''}
      <div class="tabs">${TABS.map(([k, n]) => `<button class="tab${k === tab ? ' on' : ''}" data-tab="${k}">${n}</button>`).join('')}</div>
      ${body}`;
    view.querySelector('.course-pick').addEventListener('click', e => {
      const b = e.target.closest('[data-c]');
      if (b) location.hash = `#/courses/${encodeURIComponent(b.dataset.c)}?tab=${tab}`;
    });
    view.querySelector('.tabs').addEventListener('click', e => {
      const b = e.target.closest('[data-tab]');
      if (b) location.hash = `#/courses/${encodeURIComponent(id)}?tab=${b.dataset.tab}`;
    });
    const orb = $('#openRec');
    if (orb) orb.addEventListener('click', () => openPath(c.record));
  }

  // ------------------------------------------------------------------ LIBRARY
  const ICONS = [
    [/\.pdf$/i, '📕'], [/\.(docx?|rtf|odt)$/i, '📘'], [/\.(xlsx?|csv)$/i, '📗'], [/\.(pptx?)$/i, '📙'],
    [/\.(md|txt|log)$/i, '📝'], [/\.(png|jpe?g|gif|bmp|svg|webp|heic)$/i, '🖼️'], [/\.(zip|7z|rar)$/i, '🗜️'],
    [/\.(c|h|cpp|hpp|py|java|js|m|v|sv|vhd|ipynb|ps1)$/i, '💻'], [/\.(asc|raw|kicad_\w+|sch|brd|net)$/i, '⚡'],
    [/\.(mp4|mov|mkv|mp3|wav|m4a)$/i, '🎞️'], [/\.(html?|url|lnk)$/i, '🔗'],
  ];
  const fileIcon = f => f.dir ? '📁' : (ICONS.find(([re]) => re.test(f.name)) || [0, '📄'])[1];

  function fileRow(f, rel) {
    return `<div class="file" data-path="${h(f.path)}" data-dir="${f.dir ? 1 : 0}" title="${f.dir ? 'Open folder' : 'Open with its normal app'} · right-click: show in Explorer">
      <span class="ic">${fileIcon(f)}</span>
      <span class="nm">${h(f.name)}${rel ? `<span class="rel">${h(rel)}</span>` : ''}</span>
      <span class="sz">${f.dir ? '' : f.size != null ? fmtSize(f.size) : ''}</span>
      <span class="dt">${f.mtime ? h(fmtStamp(f.mtime)) : ''}</span></div>`;
  }

  async function renderLibrary(tok, arg, q) {
    const docs = APP.state.docs_root;
    const cid = q.has('course') ? q.get('course') : (lsGet('drc-lib-course') || '');
    const c = courseById(cid);
    const root = c && c.folder ? c.folder : docs;
    const path = q.get('path') || root;
    const query = q.get('q') || '';
    lsSet('drc-lib-course', c ? c.id : '');
    const chipList = courses().slice();
    if (c && c.past) chipList.push(c);
    const link = (o) => {
      const p = new URLSearchParams();
      const cc = 'course' in o ? o.course : (c ? c.id : '');
      p.set('course', cc);
      if (o.path) p.set('path', o.path);
      if (o.q) p.set('q', o.q);
      return '#/library?' + p.toString();
    };
    view.innerHTML = `<div class="page-head"><div><div class="eyebrow">Class files</div><h1>Library</h1>
        <div class="sub">Click a file to open it. Right-click to show it in File Explorer.</div></div></div>
      <div id="upBox"></div>
      <div class="qchips">${[`<a class="qchip${!c ? ' on' : ''}" href="${link({ course: '' })}">All classes</a>`]
        .concat(chipList.map(x => `<a class="qchip${c && x.id === c.id ? ' on' : ''}" href="${link({ course: x.id })}">${h(x.code)}</a>`)).join('')}</div>
      <div class="qchips" id="quick"></div>
      <div class="lib-bar"><label class="search">🔎<input id="libSearch" type="search" placeholder="Search file names in ${h(baseName(path))}…" value="${h(query)}"></label>
        <button class="btn" id="revealBtn" title="Open this folder in File Explorer">Open in Explorer</button></div>
      <div class="crumbs" id="crumbs"></div>
      <div id="fileList"><div class="loading">Loading files…</div></div>`;

    // crumbs: root -> current
    const sep = /[\\/]/;
    const rootParts = root.split(sep).filter(Boolean), pathParts = path.split(sep).filter(Boolean);
    const inside = pathParts.slice(0, rootParts.length).join('\\').toLowerCase() === rootParts.join('\\').toLowerCase();
    const crumbs = [];
    if (inside) {
      let acc = root;
      crumbs.push({ name: c ? c.code : 'Dr. Claude', path: root });
      for (const part of pathParts.slice(rootParts.length)) { acc = acc.replace(/[\\/]$/, '') + '\\' + part; crumbs.push({ name: part, path: acc }); }
    } else crumbs.push({ name: path, path });
    $('#crumbs').innerHTML = crumbs.map((x, i) => (i ? '<span class="faint">›</span>' : '') +
      `<button data-go="${h(x.path)}">${h(x.name)}</button>`).join('');
    $('#crumbs').addEventListener('click', e => {
      const b = e.target.closest('[data-go]');
      if (b) location.hash = link({ path: b.dataset.go });
    });
    $('#revealBtn').addEventListener('click', () => openPath(path));
    if (c && c.folder) uploadBox($('#upBox'), c, () => { if (!stale(tok)) showFiles(''); });

    const list = $('#fileList');
    list.addEventListener('click', e => {
      const r = e.target.closest('.file');
      if (!r) return;
      if (r.dataset.dir === '1') location.hash = link({ path: r.dataset.path });
      else openPath(r.dataset.path);
    });
    list.addEventListener('contextmenu', e => {
      const r = e.target.closest('.file');
      if (!r) return;
      e.preventDefault();
      openPath(r.dataset.path, 'reveal');
    });
    let deb = 0;
    $('#libSearch').addEventListener('input', e => {
      clearTimeout(deb);
      const v = e.target.value.trim();
      deb = setTimeout(() => { history.replaceState(null, '', link({ path: q.get('path') || '', q: v })); showFiles(v); }, 300);
    });

    if (c && c.folder) {
      api('/api/quickdirs?course=' + encodeURIComponent(c.id)).then(r => {
        if (stale(tok) || !r.dirs.length) return;
        $('#quick').innerHTML = r.dirs.map(d => `<a class="qchip${d.toLowerCase() === path.toLowerCase() ? ' on' : ''}" href="${link({ path: d })}">📂 ${h(baseName(d))}</a>`).join('');
      }).catch(() => {});
    }

    async function showFiles(qq) {
      const mytok = APP.tok;
      if (qq) {
        list.innerHTML = '<div class="loading">Searching…</div>';
        const r = await api(`/api/search?root=${encodeURIComponent(path)}&q=${encodeURIComponent(qq)}`);
        if (mytok !== APP.tok || $('#libSearch').value.trim() !== qq) return;
        list.innerHTML = r.results.length ? `<p class="small faint">${r.results.length}${r.results.length >= 300 ? '+' : ''} match${r.results.length === 1 ? '' : 'es'}</p><div class="files">${r.results.map(f => fileRow(f, f.rel)).join('')}</div>`
          : emptyBox('🔍', 'No matches', `Nothing named like “${h(qq)}” in ${h(baseName(path))}.`);
      } else {
        const r = await api('/api/files?path=' + encodeURIComponent(path));
        if (mytok !== APP.tok) return;
        list.innerHTML = r.items.length ? `<div class="files">${r.items.map(f => fileRow(f)).join('')}</div>` : emptyBox('📂', 'Empty folder', 'Nothing in here yet.');
      }
    }
    await showFiles(query);
  }

  // ------------------------------------------------------------------ GRADEBOOK
  async function renderGradebook(tok) {
    view.innerHTML = '<div class="loading">Loading grades…</div>';
    const r = await api('/api/gradebook');
    if (stale(tok)) return;
    const head = `<div class="page-head"><div><div class="eyebrow">Mock quiz & exam scores</div><h1>Gradebook</h1>
      <div class="sub">Dr. Claude writes your scores here after each Quiz or Mock Exam.</div></div>
      <button class="btn" id="gbFolder">Open folder</button></div>`;
    const body = r.books.length ? r.books.map(b => `<div class="card" style="margin-bottom:16px"><h2>📒 ${h(b.name)}
        <span class="count">updated ${h(fmtStamp(b.mtime))}</span></h2>
        <div class="doc md">${md(b.content)}</div>
        <div class="row" style="margin-top:10px"><button class="btn sm" data-open="${h(b.path)}">Open file</button></div></div>`).join('')
      : emptyBox('📒', 'No grades yet', 'When you finish a Quiz or Mock Exam in the Classroom, your score and the topics you missed land here.',
        '<a class="btn primary" href="#/classroom?mode=Mock%20Exam">Take a mock exam</a>');
    view.innerHTML = head + body;
    $('#gbFolder').addEventListener('click', () => openPath(r.folder));
  }

  // ------------------------------------------------------------------ shared setup panels (Settings + first-run setup)
  const PREF_HELP = {
    learning_mode: 'Off = Dr. Claude just explains and answers.',
    labels: 'The question you’re on stays pinned at the top.',
    steps: 'Methods play like a short video, one step at a time.',
    videos: 'A short YouTube clip, jumped to the right spot.',
  };
  function prefsHtml(p) {
    return `<div class="prefs">${(APP.state.prefs || []).map(x => `<label class="pref"><input type="checkbox" data-pref="${h(x.key)}"${p.prefs[x.key] ? ' checked' : ''}>
      <span><b>${h(x.label)}</b>${PREF_HELP[x.key] ? `<small>${h(PREF_HELP[x.key])}</small>` : ''}</span></label>`).join('')}</div>`;
  }
  const readPrefs = el => Object.fromEntries($$('[data-pref]', el).map(i => [i.dataset.pref, i.checked]));

  // "Brain" = the AI that does the teaching. ChatGPT through OpenAI's Codex app (school account), or a Gemini key.
  function brainPanel(box, tok, onReady) {
    const draw = async () => {
      const s = APP.state.settings;
      const k = s.brain || '';
      box.innerHTML = `<div class="seg big-seg" id="brainSeg">
          <button type="button" data-v="codex" class="${k === 'codex' ? 'on' : ''}"><b>ChatGPT</b><small>school account, through Codex</small></button>
          <button type="button" data-v="gemini" class="${k === 'gemini' ? 'on' : ''}"><b>Google Gemini</b><small>free key, backup option</small></button></div>
        <div id="brainBody" style="margin-top:14px">${k ? '<div class="loading">Checking…</div>' : '<p class="muted">Pick one. You can switch any time in Settings.</p>'}</div>`;
      $('#brainSeg', box).addEventListener('click', async e => {
        const b = e.target.closest('[data-v]');
        if (!b) return;
        const r = await api('/api/settings', { brain: b.dataset.v });
        APP.state.settings = r.settings;
        draw();
      });
      if (!k) return;
      const body = $('#brainBody', box);
      const st = await api('/api/brain/status?brain=' + k).catch(e => ({ ready: false, message: e.message }));
      if (stale(tok) && tok !== -1) return;
      const status = `<div class="status ${st.ready ? 'ok' : 'warn'}">${st.ready ? '✅' : '⚠️'} ${MD.inline(st.message || '')}</div>`;
      if (k === 'codex') {
        body.innerHTML = `${status}
          <ol class="steps-list">
            <li>${st.installed === false ? '<button class="btn primary" id="cxInstall">Install Codex</button> <span class="small muted">OpenAI’s official installer opens in a black window. Wait for “Done”, then close it.</span>'
              : '<span class="muted">Codex is installed.</span>'}</li>
            <li><button class="btn${st.installed !== false && !st.ready ? ' primary' : ''}" id="cxLogin"${st.installed === false ? ' disabled' : ''}>Sign in with your school ChatGPT</button>
              <button class="btn ghost sm" id="cxDevice"${st.installed === false ? ' disabled' : ''} title="Use this if the browser sign-in doesn't come back">Use a code instead</button>
              <div class="small muted">A browser page opens. Choose <b>Sign in with ChatGPT</b> and use your school email (it goes through your school’s sign-in).</div></li>
            <li><button class="btn" id="cxCheck">Check again</button> <button class="btn ghost" id="bTest"${st.ready ? '' : ' disabled'}>Test a reply</button> <span class="small" id="bTestOut"></span></li>
          </ol>
          <details class="small"><summary>Advanced</summary>
            <div class="field"><label>File access</label>${seg('codex_sandbox', [['workspace-write', 'Can update my Course Records'], ['read-only', 'Read only']], s.codex_sandbox)}
            <div class="help">Codex can only ever touch the <code>Dr. Claude</code> folder. Pick “Read only” if updates fail.</div></div>
            <div class="field"><label for="cxModel">Model (optional)</label><input id="cxModel" value="${h(s.codex_model)}" placeholder="blank = Codex’s default"></div>
            <button class="btn sm" id="cxSave">Save</button></details>`;
        const on = (id, fn) => { const el = $('#' + id, body); if (el) el.addEventListener('click', fn); };
        on('cxInstall', async () => { await api('/api/brain/codex/install', {}); toast('Installer opened in a new window.', 4000); });
        on('cxLogin', async () => { try { await api('/api/brain/codex/login', {}); toast('Sign-in opened. Finish it in the browser, then click Check again.', 6000); } catch (e) { toast(e.message, 5000); } });
        on('cxDevice', async () => { try { await api('/api/brain/codex/login', { device: true }); toast('A window shows a code and a link. Open the link and type the code.', 7000); } catch (e) { toast(e.message, 5000); } });
        on('cxCheck', draw);
        on('cxSave', async () => {
          const r = await api('/api/settings', { codex_sandbox: $('[data-seg="codex_sandbox"] .on', body).dataset.v, codex_model: $('#cxModel', body).value.trim() });
          APP.state.settings = r.settings; toast('Saved.');
        });
        $$('[data-seg]', body).forEach(wireSeg);
      } else {
        body.innerHTML = `${status}
          <ol class="steps-list">
            <li>Open <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">aistudio.google.com/apikey</a>, sign in with a Google account, click <b>Create API key</b>, and copy it.</li>
            <li><div class="row"><input id="gmKey" type="password" placeholder="${st.has_key ? 'A key is saved. Paste a new one to replace it.' : 'Paste the key here'}" style="flex:1;min-width:220px" spellcheck="false">
              <button class="btn primary" id="gmSave">Save &amp; test</button></div>
              <div class="small muted">Saved encrypted with your Windows account (it never leaves this laptop except to talk to Google).</div></li>
            <li><button class="btn ghost" id="bTest"${st.ready ? '' : ' disabled'}>Test a reply</button> <span class="small" id="bTestOut"></span></li>
          </ol>
          <p class="small warn-note">Heads-up: on the free tier, Google may use what you send to improve its products, and people may review it. Don’t paste anything private.</p>`;
        $('#gmSave', body).addEventListener('click', async () => {
          const key = $('#gmKey', body).value.trim();
          try { const r = await api('/api/brain/gemini/key', { key }); toast(r.ready ? 'Key works!' : r.message, 5000); draw(); } catch (e) { toast(e.message, 5000); }
        });
      }
      const t = $('#bTest', body);
      if (t) t.addEventListener('click', async () => {
        const out = $('#bTestOut', body);
        out.textContent = 'Asking…';
        try { const r = await api('/api/brain/test', {}); out.innerHTML = r.ok ? '✅ ' + h(r.text) : '⚠️ ' + h(r.error || 'No answer.'); }
        catch (e) { out.textContent = '⚠️ ' + e.message; }
      });
      if (st.ready && onReady) onReady();
    };
    draw();
  }

  function canvasPanel(box, tok, onSynced) {
    const draw = async () => {
      const st = await api('/api/canvas/status');
      if (stale(tok) && tok !== -1) return;
      const url = st.url || 'https://canvas.cpp.edu';
      box.innerHTML = `${st.has_token ? `<div class="status ok">✅ Canvas is connected${st.synced ? ` · last sync ${h(fmtStamp(st.synced))}` : ''}.</div>`
        : st.connected ? `<div class="status ok">✅ Canvas syncs through your browser${st.synced ? ` · last sync ${h(fmtStamp(st.synced))}` : ''}. Click <b>🎓 Sync Dr. Claude</b> on your Canvas tab to refresh.</div>` : ''}
        <ol class="steps-list">
          <li>Open <a href="${h(url)}/profile/settings" target="_blank" rel="noopener">Canvas → Account → Settings</a>.</li>
          <li>Scroll to <b>Approved Integrations</b> and click <b>+ New Access Token</b>. Purpose: <i>Dr. Claude</i>. Leave the date empty (or pick the end of the term). Click <b>Generate Token</b>.</li>
          <li>Copy the long token (you only see it once) and paste it here:
            <div class="row" style="margin-top:6px"><input id="cvUrl" value="${h(url)}" style="width:210px" spellcheck="false" title="Your school's Canvas address">
            <input id="cvTok" type="password" placeholder="${st.has_token ? 'Saved. Paste a new one to replace it.' : 'Paste the token'}" style="flex:1;min-width:200px" spellcheck="false">
            <button class="btn primary" id="cvTest">Test &amp; connect</button></div>
            <div class="small" id="cvMsg"></div></li>
        </ol>
        <div class="small muted">The token is saved encrypted with your Windows account. It only reads your classes. You can delete it in Canvas any time.</div>
        <details class="card-sub" id="cvBrowser" ${!st.has_token ? 'open' : ''} style="margin-top:12px"><summary><b>No “+ New Access Token” button?</b> Sync through your browser instead (no token)</summary>
          <ol class="steps-list">
            <li>Show your bookmarks bar in Chrome: press <b>Ctrl+Shift+B</b>.</li>
            <li>Drag this button onto the bookmarks bar: <a class="btn primary sm" id="cvBm" href="#" title="Drag me to your bookmarks bar">🎓 Sync Dr. Claude</a>
              <span class="small muted">(Or <a href="#" id="cvBmCopy">copy it</a>, then right-click the bookmarks bar → Add page, Name: Sync Dr. Claude, URL: paste.)</span></li>
            <li>Open <a href="${h(url)}" target="_blank" rel="noopener">Canvas</a> in Chrome and log in like normal.</li>
            <li>Click <b>🎓 Sync Dr. Claude</b> on the bookmarks bar. A small Dr. Claude window opens and syncs your classes. Keep it open until it says <b>Done</b>. If Chrome blocks the pop-up, click <b>Always allow</b>, then click the bookmark again.</li>
          </ol>
          <div class="small muted">Click the bookmark again any time to pull in new files and due dates. It only reads your own classes, using your normal Canvas login.</div>
          <div class="small" id="cvBmMsg"></div></details>
        <div class="row" style="margin-top:10px">${st.has_token ? '<button class="btn" id="cvSync">⟳ Sync now</button><button class="btn ghost sm" id="cvForget">Forget token</button>' : ''}</div>
        <div id="cvProgress"></div>`;
      api('/api/canvas/bridge').then(b => {
        const a = $('#cvBm', box), m = $('#cvBmMsg', box);
        if (!a) return;
        if (!b.bookmarklet) { m.textContent = '⚠️ The browser sync helper didn’t start. Restart Dr. Claude and try again.'; return; }
        a.href = b.bookmarklet;
        a.addEventListener('click', e => { e.preventDefault(); toast('Drag this button to your bookmarks bar, then click it on your Canvas tab.', 4500); });
        $('#cvBmCopy', box).addEventListener('click', async e => {
          e.preventDefault();
          try { await navigator.clipboard.writeText(b.bookmarklet); toast('Copied. Paste it as the URL of a new bookmark.'); } catch (x) { toast('Couldn’t copy. Drag the button instead.'); }
        });
      }).catch(() => {});
      $('#cvTest', box).addEventListener('click', async () => {
        const msg = $('#cvMsg', box);
        msg.textContent = 'Checking…';
        try {
          const r = await api('/api/canvas/token', { url: $('#cvUrl', box).value.trim(), token: $('#cvTok', box).value.trim() });
          msg.innerHTML = (r.ok ? '✅ ' : '⚠️ ') + h(r.message);
          if (r.ok) { await api('/api/canvas/sync', {}); draw(); }
        } catch (e) { msg.textContent = '⚠️ ' + e.message; }
      });
      const sy = $('#cvSync', box);
      if (sy) sy.addEventListener('click', async () => { try { await api('/api/canvas/sync', {}); draw(); } catch (e) { toast(e.message, 4000); } });
      const fg = $('#cvForget', box);
      if (fg) fg.addEventListener('click', async () => { await api('/api/canvas/forget', {}); toast('Token removed from this laptop.'); draw(); });
      if (st.running || st.finished) watchSync($('#cvProgress', box), tok, async s2 => { await refreshState(); if (onSynced) onSynced(s2); });
    };
    draw();
  }

  function seg(name, opts, cur) {
    return `<div class="seg" data-seg="${name}">${opts.map(([v, l]) => `<button type="button" data-v="${v}" class="${String(cur) === String(v) ? 'on' : ''}">${l}</button>`).join('')}</div>`;
  }
  function wireSeg(g, cb) {
    g.addEventListener('click', e => {
      const b = e.target.closest('[data-v]');
      if (!b) return;
      $$('button', g).forEach(x => x.classList.toggle('on', x === b));
      if (cb) cb(b.dataset.v);
    });
  }

  function addClassForm(box, done) {
    box.innerHTML = `<form class="card add-class" autocomplete="off"><h2>➕ Add a class by hand</h2>
      <p class="small muted">For a class that isn’t on Canvas, or if you’d rather upload the files yourself.</p>
      <div class="row"><input name="code" placeholder="Code, e.g. ARO 1011L" required style="width:170px">
      <input name="title" placeholder="Title, e.g. Intro to Aerospace Lab" style="flex:1;min-width:200px">
      <input name="professor" placeholder="Professor (optional)" style="width:190px">
      <button class="btn primary">Add class</button></div></form>`;
    $('form', box).addEventListener('submit', async e => {
      e.preventDefault();
      const f = e.target;
      try {
        const r = await api('/api/course/add', { code: f.code.value, title: f.title.value, professor: f.professor.value });
        APP.state.courses = r.courses;
        toast('Class added. Upload its files in the Library.');
        if (done) done(r.course);
      } catch (err) { toast(err.message, 5000); }
    });
  }

  // Upload box: drag files or whole folders in, or pick them. Files land in <class>\My Files\.
  function uploadBox(box, c, done) {
    box.innerHTML = `<div class="dropzone" id="dz"><b>⬆ Add your own files to ${h(c.code)}</b>
      <span class="small muted">Drag files or folders here (slides, notes, old quizzes…), or</span>
      <span class="row"><button class="btn sm" id="pickF">Pick files</button><button class="btn sm" id="pickD">Pick a folder</button></span>
      <input type="file" id="inF" multiple hidden><input type="file" id="inD" webkitdirectory hidden>
      <div class="small" id="upMsg"></div></div>`;
    const dz = $('#dz', box), msg = $('#upMsg', box);
    const send = async list => {
      if (!list.length) return;
      let ok = 0, bad = 0;
      for (const [file, rel] of list) {
        msg.textContent = `Uploading ${ok + bad + 1} of ${list.length}: ${rel}`;
        try {
          const r = await fetch(`/api/upload?course=${encodeURIComponent(c.id)}&rel=${encodeURIComponent(rel)}`,
            { method: 'POST', headers: { 'X-Dr-Claude': '1', 'Content-Type': 'application/octet-stream' }, body: file });
          if (r.ok) ok++; else bad++;
        } catch (e) { bad++; }
      }
      msg.textContent = `Added ${ok} file${ok === 1 ? '' : 's'} to My Files${bad ? ` (${bad} failed)` : ''}.`;
      if (done) done();
    };
    const fromInput = inp => Array.from(inp.files).map(f => [f, f.webkitRelativePath || f.name]);
    $('#pickF', box).addEventListener('click', () => $('#inF', box).click());
    $('#pickD', box).addEventListener('click', () => $('#inD', box).click());
    $('#inF', box).addEventListener('change', e => send(fromInput(e.target)));
    $('#inD', box).addEventListener('change', e => send(fromInput(e.target)));
    const walk = (entry, pre) => new Promise(res => {
      if (entry.isFile) entry.file(f => res([[f, pre + f.name]]), () => res([]));
      else if (entry.isDirectory) {
        const rd = entry.createReader(), all = [];
        const more = () => rd.readEntries(async es => {
          if (!es.length) { const sub = await Promise.all(all.map(x => walk(x, pre + entry.name + '/'))); res(sub.flat()); }
          else { all.push(...es); more(); }
        }, () => res([]));
        more();
      } else res([]);
    });
    dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('over'); });
    dz.addEventListener('dragleave', () => dz.classList.remove('over'));
    dz.addEventListener('drop', async e => {
      e.preventDefault(); dz.classList.remove('over');
      const entries = Array.from(e.dataTransfer.items || []).map(i => i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean);
      const list = entries.length ? (await Promise.all(entries.map(x => walk(x, '')))).flat()
        : Array.from(e.dataTransfer.files).map(f => [f, f.name]);
      send(list);
    });
  }

  // ------------------------------------------------------------------ COMMAND (the student's coach for HOW Dr. Claude teaches)
  const CMD = { chat: [], pending: null };
  const ruleLine = r => r ? `<div class="rule-text">${r.group === 'Per-class' && r.course ? `<span class="chip">${h(r.course)}</span> ` : ''}${h(r.text)}</div>
      ${r.why ? `<div class="small faint">why: “${h(r.why)}”</div>` : ''}` : '<div class="faint">(nothing)</div>';
  function proposalHtml(list, pick) {
    return list.map((p, i) => `<div class="proposal">
      <div class="row" style="justify-content:space-between"><b>${pick ? `<label><input type="checkbox" data-pick="${i}" checked> ` : ''}${h(p.summary)}${pick ? '</label>' : ''}</b>
        <span class="chip">${h((p.after || p.before).group)}</span></div>
      <div class="ba">${p.before ? `<div class="before"><div class="small faint">Before</div>${ruleLine(p.before)}${p.after && p.after.on === false ? '' : ''}</div>` : ''}
        <div class="after"><div class="small faint">${p.after ? (p.after.on === false ? 'After (paused)' : 'After') : 'After'}</div>${p.after ? ruleLine(p.after) : '<div class="faint">removed</div>'}</div></div></div>`).join('');
  }

  async function renderCommand(tok, arg, q) {
    view.innerHTML = '<div class="loading">Opening Command…</div>';
    const st = await api('/api/command');
    if (stale(tok)) return;
    const groups = st.groups.map(g => {
      const rs = st.rules.filter(r => r.group === g);
      if (!rs.length) return '';
      return `<div class="rule-group"><h3>${h(g)}</h3>${rs.map(r => `<div class="rule${r.on === false ? ' off' : ''}" data-rule="${h(r.id)}">
        <label class="switch" title="${r.on === false ? 'Paused: click to turn on' : 'On: click to pause'}"><input type="checkbox" data-toggle${r.on === false ? '' : ' checked'}><span></span></label>
        <div class="rule-body">${ruleLine(r)}<div class="small faint">${h(r.date || '')}${r.source ? ' · ' + h(r.source) : ''}</div></div>
        <button class="icon-btn" data-edit title="Edit">✏️</button><button class="icon-btn" data-del title="Delete">🗑</button></div>`).join('')}</div>`;
    }).join('');
    const inbox = st.inbox.length ? st.inbox.map(it => `<div class="inbox-item" data-inbox="${h(it.id)}">
        <div class="small muted">${h(it.source)} · ${h(fmtStamp(it.date))}${it.quote ? ` · you said: “${h(it.quote)}”` : ''}</div>
        ${it.proposal ? proposalHtml([it.proposal]) : ''}
        <div class="row"><button class="btn sm primary" data-accept>✔ Approve</button><button class="btn sm ghost" data-dismiss>Dismiss</button></div></div>`).join('')
      : '<p class="small faint">Empty. Answers to the tutor’s “💬 Teaching check-in” questions show up here as suggested rules.</p>';
    view.innerHTML = `<div class="page-head"><div><div class="eyebrow">Your coach</div><h1>🎛️ Command</h1>
        <div class="sub">Tell Command how you like to learn. It turns that into rules Dr. Claude follows on every reply. Nothing changes until you confirm.</div></div>
        <button class="btn" data-open="${h(st.file)}">Open rules file</button></div>
      <div class="grid g-command">
        <div class="card cmd-chat"><h2>💬 Talk to Command</h2>
          <div class="cmd-msgs" id="cmdMsgs"></div>
          <div id="cmdPending"></div>
          <form id="cmdForm" class="row" autocomplete="off"><input id="cmdIn" style="flex:1" placeholder="e.g. “Stop giving me acronyms, use real-life examples”">
            <button class="btn primary" id="cmdSend">Send</button></form>
          <div class="qchips" style="margin-top:8px">${['Explanations are too long', 'Quiz me harder', 'Show the professor’s exact question first', 'I learn by drawing']
            .map(x => `<button class="qchip" data-say="${h(x)}">${h(x)}</button>`).join('')}</div></div>
        <div>
          <div class="card"><h2>📥 Suggestions <span class="count">${st.inbox.length}</span></h2>${inbox}</div>
          <div class="card" style="margin-top:16px"><h2>📜 Teaching Rules <span class="count">${st.rules.filter(r => r.on !== false).length} on</span></h2>
            ${groups || '<p class="faint">No rules yet. Finish setup or tell Command what you like.</p>'}
            <button class="btn sm" id="ruleAdd" style="margin-top:8px">＋ Write a rule myself</button></div>
          ${st.feedback.length ? `<details class="card" style="margin-top:16px"><summary><b>🗒 Feedback log</b></summary>${st.feedback.map(f => `<div class="small"><span class="faint">${h(fmtStamp(f.date))} · ${h(f.source)}</span> ${h(f.text)}</div>`).join('')}</details>` : ''}
        </div></div>`;

    const msgs = $('#cmdMsgs');
    const drawChat = () => {
      msgs.innerHTML = CMD.chat.length ? CMD.chat.map(m => `<div class="msg ${m.role === 'user' ? 'user' : 'assistant'}"><div class="bubble md">${m.role === 'user' ? h(m.text) : md(m.text)}</div></div>`).join('')
        : '<p class="small faint">Say what’s working and what isn’t. Command suggests a rule; you see it before/after and confirm.</p>';
      msgs.scrollTop = msgs.scrollHeight;
    };
    const showPending = (list, opts = {}) => {
      const box = $('#cmdPending');
      CMD.pending = list && list.length ? { list, ...opts } : null;
      if (!CMD.pending) { box.innerHTML = ''; return; }
      box.innerHTML = `<div class="pending"><b>${opts.pick ? 'Pick the changes to keep' : 'Confirm this change?'}</b>${proposalHtml(list, opts.pick)}
        <div class="row"><button class="btn primary" id="pcOk">${opts.pick ? 'Keep selected' : 'Confirm'}</button><button class="btn ghost" id="pcNo">Not now</button></div></div>`;
      $('#pcOk').addEventListener('click', async () => {
        const keep = opts.pick ? list.filter((_, i) => $(`[data-pick="${i}"]`).checked) : list;
        const r = await api('/api/command/apply', { changes: keep.map(p => p.change), source: opts.source || 'command' });
        toast(`Saved ${r.applied} change${r.applied === 1 ? '' : 's'}. Dr. Claude uses ${r.applied === 1 ? 'it' : 'them'} from the next reply.`, 4000);
        CMD.pending = null; route();
      });
      $('#pcNo').addEventListener('click', () => { CMD.chat.push({ role: 'assistant', text: 'OK, nothing changed.' }); showPending(null); drawChat(); });
    };
    drawChat();
    if (CMD.pending) showPending(CMD.pending.list, CMD.pending);

    const ask = async text => {
      CMD.chat.push({ role: 'user', text });
      drawChat();
      $('#cmdSend').disabled = true;
      msgs.insertAdjacentHTML('beforeend', '<div class="msg assistant" id="cmdWait"><div class="thinking"><span class="dots"><i></i><i></i><i></i></span><span>Thinking…</span></div></div>');
      try {
        const r = await api('/api/command/send', { text, history: CMD.chat.slice(0, -1).slice(-8) });
        CMD.chat.push({ role: 'assistant', text: r.reply });
        drawChat(); showPending(r.proposals);
      } catch (e) { CMD.chat.push({ role: 'assistant', text: '⚠️ ' + e.message }); drawChat(); }
      const b = $('#cmdSend'); if (b) b.disabled = false;
    };
    $('#cmdForm').addEventListener('submit', e => { e.preventDefault(); const v = $('#cmdIn').value.trim(); if (v) { $('#cmdIn').value = ''; ask(v); } });
    view.addEventListener('click', e => { const b = e.target.closest('[data-say]'); if (b) ask(b.dataset.say); });

    // rule list: toggle / edit / delete all go through the same before/after confirm
    const ruleOf = el => st.rules.find(r => r.id === el.closest('[data-rule]').dataset.rule);
    const proposeLocal = async (changes, source) => {
      const r = await api('/api/command/propose', { changes });
      showPending(r.proposals, { source });
      $('#cmdPending').scrollIntoView({ behavior: 'smooth', block: 'center' });
    };
    view.addEventListener('change', e => {
      if (!e.target.matches('[data-toggle]')) return;
      const r = ruleOf(e.target);
      e.target.checked = r.on !== false;  // stays as-is until confirmed
      proposeLocal([{ op: 'toggle', id: r.id, on: r.on === false }], 'edited by hand');
    });
    view.addEventListener('click', e => {
      if (e.target.closest('[data-del]')) proposeLocal([{ op: 'delete', id: ruleOf(e.target).id }], 'edited by hand');
      const ed = e.target.closest('[data-edit]');
      if (ed) {
        const r = ruleOf(ed), body = ed.closest('[data-rule]').querySelector('.rule-body');
        body.innerHTML = `<textarea class="rule-edit" rows="2">${h(r.text)}</textarea>
          <div class="row"><select class="rule-grp">${st.groups.map(g => `<option${g === r.group ? ' selected' : ''}>${h(g)}</option>`).join('')}</select>
          <button class="btn sm primary" data-save>Review change</button></div>`;
        $('[data-save]', body).addEventListener('click', () => proposeLocal([{ op: 'edit', id: r.id, text: $('.rule-edit', body).value.trim(), group: $('.rule-grp', body).value }], 'edited by hand'));
      }
      const ib = e.target.closest('[data-inbox]');
      if (ib && (e.target.closest('[data-accept]') || e.target.closest('[data-dismiss]'))) {
        api('/api/command/inbox', { id: ib.dataset.inbox, accept: !!e.target.closest('[data-accept]') })
          .then(r => { toast(r.applied ? 'Rule saved.' : 'Dismissed.'); route(); }).catch(err => toast(err.message, 4000));
      }
    });
    $('#ruleAdd').addEventListener('click', () => {
      $('#cmdPending').innerHTML = `<div class="pending"><b>New rule</b><textarea class="rule-edit" id="nrText" rows="2" placeholder="e.g. Keep explanations under 6 lines, then ask if I want more."></textarea>
        <div class="row"><select id="nrGrp">${st.groups.map(g => `<option>${h(g)}</option>`).join('')}</select><input id="nrCourse" placeholder="Class (Per-class only)" style="width:170px">
        <button class="btn primary" id="nrGo">Review</button></div></div>`;
      $('#nrGo').addEventListener('click', () => proposeLocal([{ op: 'add', text: $('#nrText').value.trim(), group: $('#nrGrp').value, course: $('#nrCourse').value.trim(), why: 'written by hand' }], 'written by hand'));
    });

    // Retro: #/command?retro=<session id>
    const rsid = q.get('retro');
    if (rsid) {
      history.replaceState(null, '', '#/command');
      CMD.chat.push({ role: 'user', text: 'Retro on my last study session, please.' });
      drawChat();
      msgs.insertAdjacentHTML('beforeend', '<div class="msg assistant"><div class="thinking"><span class="dots"><i></i><i></i><i></i></span><span>Reading the session…</span></div></div>');
      try {
        const r = await api('/api/command/retro', { sid: rsid });
        if (stale(tok)) return;
        CMD.chat.push({ role: 'assistant', text: r.reply });
        drawChat(); showPending(r.proposals, { pick: true, source: 'retro' });
      } catch (e) { CMD.chat.push({ role: 'assistant', text: '⚠️ ' + e.message }); drawChat(); }
    }
  }

  // ------------------------------------------------------------------ SETTINGS
  async function renderSettings(tok) {
    const r = await api('/api/state');
    if (stale(tok)) return;
    APP.state = r;
    const s = r.settings, p = r.profile;
    view.innerHTML = `<div class="page-head"><div><div class="eyebrow">Dr. Claude</div><h1>Settings</h1>
        <div class="sub">Everything stays on this laptop, in <code>${h(r.docs_root)}</code>.</div></div>
        <a class="btn" href="#/welcome">Run setup again</a></div>
      <div class="set-grid">
        <div class="card"><h2>🙋 You</h2>
          <form class="form" id="meForm" autocomplete="off">
            <div class="row"><div class="field" style="flex:1"><label>Name</label><input name="name" value="${h(p.name)}"></div>
            <div class="field" style="flex:1"><label>School</label><input name="school" value="${h(p.school)}"></div>
            <div class="field" style="flex:1"><label>Major</label><input name="major" value="${h(p.major)}"></div></div>
            <div class="field"><label>How I like to learn</label>${prefsHtml(p)}
              <div class="help">These are your first Teaching Rules. Fine-tune them in words on the <a href="#/command">Command</a> page.</div></div>
            <div class="field"><label>Anything else Dr. Claude should know (optional)</label><textarea name="notes" rows="3">${h(p.notes)}</textarea></div>
            <button class="btn primary">Save</button></form></div>
        <div class="card"><h2>🧠 AI brain</h2><div id="brainBox"></div></div>
        <div class="card"><h2>🎓 Canvas</h2><div id="canvasBox"></div></div>
        <div class="card"><h2>🎨 App</h2>
          <div class="field"><label>Theme</label>${seg('theme', [['system', 'Match Windows'], ['light', 'Light'], ['dark', 'Dark']], s.theme)}</div>
          <div class="field"><label>Study timer</label>${seg('logpose', [['true', 'On'], ['false', 'Off']], s.logpose)}
            <div class="help">Study modes time themselves; the home screen shows today, this week, and your streak.</div></div>
          <p class="small muted" id="tmStatus"></p>
          <div class="row"><button class="btn sm" id="tmEnd">⏹ End study session now</button></div>
          <div class="field" style="margin-top:12px"><label for="f_edge">Microsoft Edge</label><input id="f_edge" value="${h(s.edge)}" spellcheck="false">
            <div class="help">Used to open the app window. <button class="btn sm ghost" id="edgeSave">Save</button></div></div>
          <p class="small faint">Chats are saved in the app’s data folder. Close the window and the app shuts down by itself.</p></div>
        <div class="card"><h2>🔄 Updates</h2>
          <p>You have <b>Dr. Claude v${h(r.version || '')}</b>.</p>
          <div class="field"><label>Install updates automatically</label>${seg('auto_update', [['true', 'On'], ['false', 'Off']], s.auto_update)}
            <div class="help">On: new versions download in the background and install the next time you open Dr. Claude. Your notes, rules, chats and keys are never touched.</div></div>
          <div class="row"><button class="btn sm" id="updCheck">Check for updates</button><span class="small" id="updMsg"></span></div></div>
      </div>`;
    $('#meForm').addEventListener('submit', async e => {
      e.preventDefault();
      const f = e.target;
      try {
        const res = await api('/api/profile', { name: f.name.value, school: f.school.value, major: f.major.value, notes: f.notes.value, prefs: readPrefs(f) });
        APP.state.profile = res.profile; toast('Saved.');
      } catch (err) { toast(err.message, 4000); }
    });
    brainPanel($('#brainBox'), tok);
    canvasPanel($('#canvasBox'), tok);
    $$('[data-seg="theme"],[data-seg="logpose"],[data-seg="auto_update"]').forEach(g => wireSeg(g, async v => {
      const k = g.dataset.seg;
      if (k === 'theme') applyTheme(v);
      const res = await api('/api/settings', { [k]: k === 'theme' ? v : v === 'true' });
      APP.state.settings = res.settings;
    }));
    $('#edgeSave').addEventListener('click', async () => { const res = await api('/api/settings', { edge: $('#f_edge').value.trim() }); APP.state.settings = res.settings; toast('Saved.'); });
    const tm = async () => { try { const x = await api('/api/logpose/status'); if (!stale(tok)) $('#tmStatus').textContent = x.text; } catch (e) { /* ignore */ } };
    $('#tmEnd').addEventListener('click', async () => { const x = await api('/api/logpose', { action: 'end' }); toast(x.text, 4000); APP.timerActive = {}; tm(); });
    tm();
    $('#updCheck').addEventListener('click', async () => {
      const m = $('#updMsg');
      m.textContent = 'Checking…';
      try {
        const u = await api('/api/update/check', {});
        m.textContent = !u.installed ? 'Updates work in the installed app only.' : u.error ? '⚠️ ' + u.error
          : !u.configured ? 'No update link is set up in this copy.' : u.available ? `v${u.available} is ready.` : 'You’re up to date.';
        updateBanner(u);
      } catch (e) { m.textContent = '⚠️ ' + e.message; }
    });
  }

  // ------------------------------------------------------------------ FIRST-RUN SETUP
  const WZ = { step: 0 };
  async function renderWelcome(tok) {
    await refreshState();
    if (stale(tok)) return;
    const p = APP.state.profile;
    const steps = ['You', 'How you learn', 'AI brain', 'Canvas', 'Done'];
    const nav = (back, next, nextLabel = 'Next →') => `<div class="row wz-nav">${back ? '<button class="btn ghost" id="wzBack">← Back</button>' : ''}<span class="spacer"></span>
      ${next ? `<button class="btn primary" id="wzNext">${nextLabel}</button>` : ''}</div>`;
    const go = n => { WZ.step = n; renderWelcome(tok); };
    let body = '';
    if (WZ.step === 0) body = `<h1>Welcome to Dr. Claude 🎓</h1>
        <p class="muted">Your own study professor. It reads your classes from Canvas and teaches, quizzes, and tests you at your class’s pace, in your professor’s style.</p>
        <div class="field"><label>Your first name</label><input id="wzName" value="${h(p.name)}" placeholder="e.g. Jancy"></div>
        <div class="row"><div class="field" style="flex:1"><label>School</label><input id="wzSchool" value="${h(p.school)}"></div>
        <div class="field" style="flex:1"><label>Major</label><input id="wzMajor" value="${h(p.major)}" placeholder="e.g. Aerospace Engineering"></div></div>
        ${nav(false, true)}`;
    else if (WZ.step === 1) body = `<h1>How do you like to learn?</h1>
        <p class="muted">These start as on. Turn off anything you don’t want. Later, just tell the <b>Command</b> page in your own words (“explanations are too long”) and it updates the rules.</p>
        <div id="wzPrefs">${prefsHtml(p)}</div>${nav(true, true)}`;
    else if (WZ.step === 2) body = `<h1>Pick the AI brain</h1>
        <p class="muted">Dr. Claude needs an AI to do the teaching. Your school ChatGPT account is free and best. Gemini is the backup.</p>
        <div id="wzBrain"></div>${nav(true, true)}`;
    else if (WZ.step === 3) body = `<h1>Connect Canvas</h1>
        <p class="muted">Dr. Claude downloads your classes’ files, syllabus, assignments, and modules, and keeps them up to date.</p>
        <div id="wzCanvas"></div>
        <details class="small" style="margin-top:12px"><summary>Can’t or don’t want to use a token?</summary>
          <p>Use <b>Sync through your browser</b> above: no token needed. Or skip this, add each class by hand on the Courses page, and drag your own files into it in the Library.</p></details>
        ${nav(true, true, 'Next →')}`;
    else body = `<h1>You’re all set${p.name ? ', ' + h(p.name.split(' ')[0]) : ''}! 🎉</h1>
        <ul class="done-list"><li><b>Home</b> shows what’s due and a plan for today.</li>
          <li><b>Classroom</b>: pick a class and a mode (Lecture, Quiz, Mock Exam…).</li>
          <li><b>Command</b>: tell it how you like to learn; it turns that into rules.</li>
          <li><b>🧰 Tools</b>: calculator, quick questions, and your thoughts.</li></ul>
        ${nav(true, true, 'Start studying →')}`;
    view.innerHTML = `<div class="wizard"><div class="wz-steps">${steps.map((x, i) => `<span class="${i === WZ.step ? 'on' : i < WZ.step ? 'done' : ''}">${i < WZ.step ? '✓' : i + 1} ${h(x)}</span>`).join('')}</div>
      <div class="card wz-card">${body}</div></div>`;
    const back = $('#wzBack'); if (back) back.addEventListener('click', () => go(WZ.step - 1));
    const next = $('#wzNext');
    if (WZ.step === 2) brainPanel($('#wzBrain'), tok);
    if (WZ.step === 3) canvasPanel($('#wzCanvas'), tok);
    next.addEventListener('click', async () => {
      try {
        if (WZ.step === 0) {
          if (!$('#wzName').value.trim()) { toast('Type your name first.'); return; }
          await api('/api/profile', { name: $('#wzName').value, school: $('#wzSchool').value, major: $('#wzMajor').value });
        } else if (WZ.step === 1) {
          await api('/api/profile', { prefs: readPrefs($('#wzPrefs')) });
        } else if (WZ.step === 4) {
          await api('/api/profile', { onboarded: true, prefs: APP.state.profile.prefs });
          await refreshState();
          WZ.step = 0;
          location.hash = '#/home';
          return;
        }
        go(WZ.step + 1);
      } catch (e) { toast(e.message, 4000); }
    });
  }

  // ------------------------------------------------------------------ updates (banner + restart)
  const UPD = { later: '' };
  async function updateBanner(st) {
    const el = $('#updBanner');
    if (!el) return;
    try { st = st || await api('/api/update/status'); } catch (e) { return; }
    APP.update = st;
    let html = '';
    if (st.event && st.event.kind === 'ok') {
      html = `<b>🎉 Updated to v${h(st.event.to)}</b>${st.event.notes ? `<div class="upd-notes md">${md(st.event.notes)}</div>` : ''}
        <div class="row"><button class="btn sm primary" data-upd="seen">Got it</button></div>`;
    } else if (st.event && st.event.kind === 'rolled_back') {
      html = `<b>⚠️ The update to v${h(st.event.to)} didn't start, so Dr. Claude went back to v${h(st.event.from)}.</b>
        <div class="small muted">Nothing of yours was changed. It won't try that version again by itself.</div>
        <div class="row"><button class="btn sm" data-upd="seen">OK</button></div>`;
    } else if (st.available && UPD.later !== st.available) {
      html = st.too_old ? `<b>A new Dr. Claude (v${h(st.available)}) is out.</b><div class="small muted">This copy is too old to update itself; please reinstall it.</div>
          <div class="row"><button class="btn sm ghost" data-upd="later">OK</button></div>`
        : `<b>Update ready: v${h(st.available)}</b>${st.notes ? `<div class="upd-notes md">${md(st.notes)}</div>` : ''}
          ${st.staged && st.auto ? '<div class="small muted">It installs by itself the next time you open Dr. Claude.</div>' : ''}
          <div class="row"><button class="btn sm primary" data-upd="install">Update now</button><button class="btn sm ghost" data-upd="later">Later</button></div>`;
    }
    el.innerHTML = html;
    el.hidden = !html;
  }
  async function installUpdate() {
    const el = $('#updBanner');
    el.innerHTML = '<b>Updating…</b><div class="small muted">Dr. Claude restarts in a few seconds. Don’t close this window.</div>';
    el.hidden = false;
    try {
      const r = await api('/api/update/install', {});
      if (!r.restarting) { toast(r.error || 'Update failed.', 6000); return updateBanner(r); }
    } catch (e) { toast(e.message, 5000); return; }
    const from = APP.update && APP.update.version;
    const t0 = Date.now();
    const poll = async () => {
      try {
        const p = await fetch('/api/ping').then(x => x.json());
        if (p.version && p.version !== from) { location.reload(); return; }
        if (p.version === from && Date.now() - t0 > 8000) { location.reload(); return; }  // rolled back
      } catch (e) { /* restarting */ }
      if (Date.now() - t0 < 120000) setTimeout(poll, 1000);
      else el.innerHTML = '<b>Update is taking long.</b><div class="small muted">Close this window and open Dr. Claude from the Desktop icon.</div>';
    };
    setTimeout(poll, 2500);
  }
  document.addEventListener('click', async e => {
    const b = e.target.closest('[data-upd]');
    if (!b) return;
    const k = b.dataset.upd;
    if (k === 'install') installUpdate();
    else if (k === 'later') { UPD.later = APP.update && APP.update.available; $('#updBanner').hidden = true; }
    else if (k === 'seen') { await api('/api/update/seen', {}).catch(() => {}); $('#updBanner').hidden = true; }
  });

  // ------------------------------------------------------------------ global bits
  // Copy buttons on code blocks (anywhere Markdown is rendered)
  document.addEventListener('click', e => {
    const b = e.target.closest('.codewrap .copy');
    if (!b) return;
    const code = b.parentElement.querySelector('pre code');
    navigator.clipboard.writeText(code ? code.textContent : '').then(() => {
      b.textContent = 'Copied'; setTimeout(() => { b.textContent = 'Copy'; }, 1200);
    }, () => toast("Couldn't copy."));
  });

  // Any [data-open] button opens that file/folder with its normal app
  document.addEventListener('click', e => { const b = e.target.closest('[data-open]'); if (b) openPath(b.dataset.open); });

  // Ctrl+M = mic (Classroom only)
  document.addEventListener('keydown', e => {
    if (e.ctrlKey && !e.shiftKey && !e.altKey && (e.key === 'm' || e.key === 'M') && $('#micBtn')) { e.preventDefault(); toggleMic(); }
  });

  // Heartbeat: the server shuts itself down when the window has been closed for a while.
  const beat = () => fetch('/api/heartbeat', { method: 'POST' }).catch(() => {});
  setInterval(beat, 20000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) beat(); });
  window.addEventListener('pagehide', () => { try { navigator.sendBeacon('/api/bye'); } catch (e) { /* ignore */ } });

  async function boot() {
    beat();
    try {
      APP.state = await api('/api/state');
    } catch (e) {
      view.innerHTML = emptyBox('🔌', "Can't reach Dr. Claude's server", h(e.message), '<button class="btn" onclick="location.reload()">Try again</button>');
      return;
    }
    if (!APP.state.profile.onboarded) history.replaceState(null, '', '#/welcome');
    const urlTheme = new URLSearchParams(location.search).get('theme');
    applyTheme(urlTheme || APP.state.settings.theme || lsGet('drc-theme') || 'system');
    if (!location.hash) history.replaceState(null, '', '#/home');
    route();
    updateBanner();
    setTimeout(updateBanner, 15000);  // the first check runs a few seconds after start
    setInterval(updateBanner, 30 * 60 * 1000);
  }
  boot();
})();
