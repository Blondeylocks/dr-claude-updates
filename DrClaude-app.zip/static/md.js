// Tiny Markdown renderer for Dr. Claude (no libraries).
// Handles: headings, paragraphs, **bold**, *italic*, ~~strike~~, `code`, ``` fenced code (whitespace kept),
// GFM tables, nested lists, task boxes, blockquotes, hr, links, <br> in cells, emoji (just text).
(function () {
  const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  function inline(s) {
    const codes = [];
    s = s.replace(/(`+)([\s\S]*?[^`])\1(?!`)/g, (m, f, c) => { codes.push(c); return '\u0000' + (codes.length - 1) + '\u0000'; });
    s = esc(s);
    s = s.replace(/&lt;br\s*\/?&gt;/gi, '<br>');
    s = s.replace(/!\[([^\]]*)\]\((\/media\/[^\s)]+)\)/g, '<img class="chat-img" src="$2" alt="$1" title="Click to make it bigger" loading="lazy">');
    s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
    s = s.replace(/(^|[\s(])(https?:\/\/[^\s<)]+)/g, '$1<a href="$2" target="_blank" rel="noopener">$2</a>');
    s = s.replace(/\*\*\*(?=\S)([\s\S]*?\S)\*\*\*/g, '<strong><em>$1</em></strong>');
    s = s.replace(/\*\*(?=\S)([\s\S]*?\S)\*\*/g, '<strong>$1</strong>');
    s = s.replace(/(^|[^\w])__(?=\S)([\s\S]*?\S)__(?!\w)/g, '$1<strong>$2</strong>');
    s = s.replace(/(^|[^*\w])\*(?=[^\s*])([^*\n]*?[^\s*])\*(?![*\w])/g, '$1<em>$2</em>');
    s = s.replace(/(^|[^\w])_(?=[^\s_])([^_\n]*?[^\s_])_(?!\w)/g, '$1<em>$2</em>');
    s = s.replace(/~~(?=\S)(.+?)~~/g, '<del>$1</del>');
    s = s.replace(/\u0000(\d+)\u0000/g, (m, n) => '<code>' + esc(codes[+n]) + '</code>');
    return s;
  }

  const splitRow = l => {
    let s = l.trim();
    if (s.startsWith('|')) s = s.slice(1);
    if (s.endsWith('|') && !s.endsWith('\\|')) s = s.slice(0, -1);
    // split on pipes that are not escaped and not inside `code`
    const cells = []; let cur = '', inCode = false;
    for (let i = 0; i < s.length; i++) {
      const ch = s[i];
      if (ch === '`') inCode = !inCode;
      if (ch === '\\' && s[i + 1] === '|') { cur += '|'; i++; continue; }
      if (ch === '|' && !inCode) { cells.push(cur.trim()); cur = ''; continue; }
      cur += ch;
    }
    cells.push(cur.trim());
    return cells;
  };
  const SEP = /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;
  const LIST = /^(\s*)([-*+]|\d+[.)])\s+(.*)$/;
  const FENCE = /^\s*(`{3,}|~{3,})\s*([\w+#.-]*)\s*$/;

  function parseList(lines, i) {
    const items = [];
    while (i < lines.length) {
      const l = lines[i];
      if (FENCE.test(l)) break;
      const m = l.match(LIST);
      if (m) {
        items.push({ ind: m[1].replace(/\t/g, '    ').length, ord: /\d/.test(m[2]), num: parseInt(m[2], 10), text: m[3] });
        i++; continue;
      }
      if (/^\s*$/.test(l)) {
        const n = lines[i + 1];
        if (n !== undefined && LIST.test(n)) { i++; continue; }
        break;
      }
      if (/^\s{2,}\S/.test(l) && items.length) { items[items.length - 1].text += '\n' + l.trim(); i++; continue; }
      break;
    }
    let html = ''; const stack = [];
    for (const it of items) {
      while (stack.length && it.ind < stack[stack.length - 1].ind) html += '</li></' + stack.pop().tag + '>';
      if (!stack.length || it.ind > stack[stack.length - 1].ind) {
        const tag = it.ord ? 'ol' : 'ul';
        html += `<${tag}${it.ord && it.num !== 1 ? ` start="${it.num}"` : ''}>`;
        stack.push({ ind: it.ind, tag });
      } else html += '</li>';
      let t = it.text, box = '';
      const tm = t.match(/^\[([ xX])\]\s+(.*)$/s);
      if (tm) { box = `<span class="task">${tm[1] === ' ' ? '☐' : '☑'}</span> `; t = tm[2]; }
      html += '<li>' + box + t.split('\n').map(inline).join('<br>');
    }
    while (stack.length) html += '</li></' + stack.pop().tag + '>';
    return [html, i];
  }

  // ```video block -> click-to-play YouTube card (thumbnail first, so streaming re-renders don't restart it)
  //   id: <11-char id or any youtube url>   start: 83 or 1:23   end: 150   caption: what it shows
  const toSec = v => {
    if (!v) return 0;
    const p = String(v).trim().split(':').map(x => parseInt(x, 10) || 0);
    return p.reduce((a, x) => a * 60 + x, 0);
  };
  const fmtSec = s => Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  //   or  search: <what they need to see>   -> the app finds a clip on demand (catalog first, then live YouTube)
  function videoCard(lines) {
    const f = {};
    for (const l of lines) { const m = l.match(/^\s*(\w+)\s*:\s*(.*)$/); if (m) f[m[1].toLowerCase()] = m[2].trim(); }
    const raw = f.id || f.url || f.video || '';
    const idm = raw.match(/(?:v=|youtu\.be\/|embed\/|shorts\/)([\w-]{11})/) || raw.match(/^([\w-]{11})$/);
    const cap = f.caption || f.title || '';
    const q = f.search || f.query || '';
    if (!idm && !q) return `<div class="video-card bad">🎬 (video link missing or broken)</div>`;
    const head = `<div class="video-card" data-q="${esc(q)}" data-cap="${esc(cap)}"`;
    if (!idm) return `${head}><div class="video-finding">🔎 Finding a clip: <i>${esc(q)}</i>…</div></div>`;
    return `${head} data-vid="${esc(idm[1])}">${cardInner({ id: idm[1], start: toSec(f.start), end: toSec(f.end) }, cap)}</div>`;
  }
  function cardInner(c, cap) {
    const start = c.start || 0, end = c.end || 0;
    const span = start || end ? ` · plays ${fmtSec(start)}${end ? '–' + fmtSec(end) : ''}` : '';
    const label = cap || c.title || 'Watch this clip';
    const sub = c.title && cap ? `<div class="video-sub">${esc(c.title)}${c.channel ? ' · ' + esc(c.channel) : ''}${c.chapter ? ' · chapter “' + esc(c.chapter) + '”' : ''}</div>` : '';
    return `<button class="video-thumb" title="Play here" style="background-image:url('https://i.ytimg.com/vi/${esc(c.id)}/hqdefault.jpg')"><span class="play">▶</span></button>
      <div class="video-cap"><div><span>📺 ${inline(label)}${esc(span)}</span>${sub}</div>
      <span class="video-acts"><button data-vote="1" title="This clip helped (it gets reused)">👍</button><button data-vote="-1" title="Not helpful (find a different one)">👎</button>
      <button data-another title="Show a different clip">🔄</button>
      <a href="https://www.youtube.com/watch?v=${esc(c.id)}${start ? '&t=' + start + 's' : ''}" target="_blank" rel="noopener">YouTube ↗</a></span></div>
      ${c.sure === false ? '<div class="video-unsure">🤔 I’m not 100% sure this is the exact part. Tell me after you watch it.</div>' : ''}
      <div class="video-ask" hidden><b>How was this clip?</b>
        <button data-fb="good">✅ Right part</button><button data-fb="part">⏩ Right video, wrong part</button><button data-fb="video">❌ Wrong video</button></div>`;
  }

  // ```made block (JSON from the app) -> the file the tutor made, playable right in the chat
  const MADE_ICON = { html: '🌐', pdf: '📄', gif: '🎞️', mp3: '🎧', mp4: '🎬' };
  const MADE_WORD = { html: 'Web page', pdf: 'PDF', gif: 'Animation', mp3: 'Audio', mp4: 'Video' };
  function madeCard(lines) {
    let f;
    try { f = JSON.parse(lines.join('\n')); } catch (e) { return '<div class="made-card bad">🛠️ (file card is broken)</div>'; }
    const url = String(f.url || '');
    if (!/^\/media\//.test(url) || !MADE_ICON[f.type]) return '<div class="made-card bad">🛠️ (file card is broken)</div>';
    const u = esc(url);
    const size = f.size ? ` · ${f.size > 1048576 ? (f.size / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(f.size / 1024)) + ' KB'}` : '';
    const view = {
      html: `<iframe class="made-frame" src="${u}" sandbox="allow-scripts allow-forms allow-modals" loading="lazy" title="${esc(f.title || '')}"></iframe>`,
      pdf: `<iframe class="made-frame tall" src="${u}#view=FitH" loading="lazy" title="${esc(f.title || '')}"></iframe>`,
      gif: `<img class="made-img" src="${u}" alt="${esc(f.title || '')}">`,
      mp3: `<audio class="made-audio" controls preload="metadata" src="${u}"></audio>`,
      mp4: `<video class="made-video" controls preload="auto" src="${u}#t=0.1"></video>`,
    }[f.type];
    return `<div class="made-card" data-url="${u}"><div class="made-head"><span>${MADE_ICON[f.type]} <b>${esc(f.title || f.name || 'Your file')}</b>
        <span class="made-sub">${MADE_WORD[f.type]}${esc(size)}</span></span>
        <span class="made-acts"><button data-made="open" title="Open it in its own window">↗ Open</button>
        <button data-made="save" title="Keep a copy in this class's Library (My Files → Made by Dr. Claude)">💾 Save to class</button></span></div>
      ${view}</div>`;
  }

  // On-demand clips: fill "search:" cards. Results are cached so streaming re-renders don't refetch,
  // and remembered per search so an old chat shows the same clip next time.
  const CLIPS = new Map();
  const ckey = q => 'drc-clip:' + q.toLowerCase();
  function remember(q, c) { CLIPS.set(q, c); try { localStorage.setItem(ckey(q), JSON.stringify(c)); } catch (e) { /* storage off */ } }
  function recall(q) {
    if (CLIPS.has(q)) return CLIPS.get(q);
    try { const s = localStorage.getItem(ckey(q)); if (s) { const c = JSON.parse(s); CLIPS.set(q, c); return c; } } catch (e) { /* ignore */ }
    return undefined;
  }
  function fill(card, c) {
    if (!c) { card.innerHTML = `<div class="video-finding">🎬 No good clip found for <i>${esc(card.dataset.q)}</i>.</div>`; card.classList.add('filled'); return; }
    card.dataset.vid = c.id; card.dataset.t0 = c.start || 0; card.dataset.t1 = c.end || 0;
    card.innerHTML = cardInner(c, card.dataset.cap);
    card.classList.add('filled');
  }
  async function fetchClip(q, exclude) {
    const course = window.DRC ? window.DRC.course() : '';
    const r = await fetch(`/api/clip?q=${encodeURIComponent(q)}&course=${encodeURIComponent(course)}&exclude=${encodeURIComponent((exclude || []).join(','))}`);
    const j = await r.json();
    return j.clip || null;
  }
  function hydrate(root) {
    (root || document).querySelectorAll('.video-card[data-q]').forEach(card => {
      const q = card.dataset.q;
      if (!q) return;
      if (card.dataset.vid) { card.dataset.t0 = card.dataset.t0 || 0; return; }
      const got = recall(q);
      if (got && !(got instanceof Promise)) return fill(card, got);
      if (!got) {
        const p = fetchClip(q).then(c => { remember(q, c); return c; }).catch(() => { CLIPS.delete(q); return null; });
        CLIPS.set(q, p);
      }
      CLIPS.get(q).then(c => document.querySelectorAll('.video-card[data-q]:not(.filled)').forEach(el => { if (el.dataset.q === q) fill(el, c); }));
    });
  }

  async function vote(card, v) {
    const id = card.dataset.vid, q = card.dataset.q || '';
    try {
      await fetch('/api/clip/rate', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Dr-Claude': '1' }, body: JSON.stringify({ id, vote: v, q }) });
    } catch (e) { /* offline: ignore */ }
    if (v > 0) { card.querySelector('[data-vote="1"]').classList.add('voted'); if (window.DRC) window.DRC.toast('Saved: this clip will be reused'); }
    else another(card);
  }
  async function another(card) {
    const q = card.dataset.q || card.dataset.cap || '';
    if (!q) { if (window.DRC) window.DRC.toast('This clip has no search to redo'); return; }
    const ex = (card.dataset.ex ? card.dataset.ex.split(',') : []).concat(card.dataset.vid ? [card.dataset.vid] : []);
    card.dataset.ex = ex.join(',');
    card.classList.remove('filled');
    card.innerHTML = `<div class="video-finding">🔎 Finding a different clip…</div>`;
    const c = await fetchClip(q, ex).catch(() => null);
    if (c && card.dataset.q) remember(card.dataset.q, c);
    fill(card, c);
  }

  // ```steps block -> frame-by-frame animation. Frames start with a line "--- caption".
  // Lines before the first "---" (e.g. "title: ...") are the header.
  function stepsPlayer(lines) {
    let title = '';
    const frames = [];
    for (const l of lines) {
      const m = l.match(/^\s*---+\s*(.*)$/);
      if (m) { frames.push({ cap: m[1].replace(/-+\s*$/, '').trim(), body: [] }); continue; }
      if (!frames.length) { const t = l.match(/^\s*title\s*:\s*(.*)$/i); if (t) title = t[1].trim(); continue; }
      frames[frames.length - 1].body.push(l);
    }
    if (!frames.length) return `<div class="codewrap"><pre><code>${esc(lines.join('\n'))}</code></pre></div>`;
    const n = frames.length;
    return `<div class="steps" data-i="0" data-n="${n}">
      <div class="steps-head"><span>🎬 ${inline(title || 'Watch it step by step')}</span><span class="steps-count">1 / ${n}</span></div>
      ${frames.map((fr, k) => `<div class="frame${k ? '' : ' on'}"><div class="frame-cap">${inline(fr.cap || 'Step ' + (k + 1))}</div>
        <pre><code>${esc(fr.body.join('\n').replace(/^\n+|\s+$/g, ''))}</code></pre></div>`).join('')}
      <div class="steps-ctl"><button data-step="first" title="Back to start">⏮</button><button data-step="prev" title="Previous step">◀</button>
        <button data-step="play" class="playbtn" title="Play / pause">▶ Play</button><button data-step="next" title="Next step">▶</button>
        <div class="steps-bar"><i style="width:${100 / n}%"></i></div></div></div>`;
  }

  function showFrame(box, i) {
    const n = +box.dataset.n;
    i = Math.max(0, Math.min(n - 1, i));
    box.dataset.i = i;
    box.querySelectorAll('.frame').forEach((f, k) => f.classList.toggle('on', k === i));
    box.querySelector('.steps-count').textContent = `${i + 1} / ${n}`;
    box.querySelector('.steps-bar i').style.width = (100 * (i + 1) / n) + '%';
    return i;
  }
  function stopPlay(box) {
    clearInterval(box._t); box._t = 0;
    const b = box.querySelector('.playbtn'); if (b) b.textContent = '▶ Play';
  }
  document.addEventListener('click', e => {
    const mb = e.target.closest('.made-card [data-made]');
    if (mb) {
      const url = mb.closest('.made-card').dataset.url;
      const course = window.DRC ? window.DRC.course() : '';
      const call = (path, body) => fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Dr-Claude': '1' }, body: JSON.stringify(body) })
        .then(r => r.json().then(j => { if (!r.ok || j.error) throw new Error(j.error || 'failed'); return j; }));
      if (mb.dataset.made === 'open') call('/api/made/open', { url }).catch(err => window.DRC && window.DRC.toast(err.message));
      else call('/api/made/save', { url, course }).then(j => { mb.textContent = '✅ Saved'; mb.disabled = true; if (window.DRC) window.DRC.toast(`Saved to ${j.course} → My Files → Made by Dr. Claude`, 5000); })
        .catch(err => window.DRC && window.DRC.toast(err.message, 5000));
      return;
    }
    const fb = e.target.closest('.video-card [data-fb]');
    if (fb) {
      const card = fb.closest('.video-card');
      if (fb.dataset.fb === 'good') { vote(card, 1); card.querySelector('.video-ask').innerHTML = '✅ Thanks! I’ll reuse this exact part.'; }
      else {
        if (window.DRC) window.DRC.toast(fb.dataset.fb === 'part' ? 'Got it. Finding a better spot…' : 'Got it. Finding a different video…');
        vote(card, -1);
        // and let them say what they were looking for, so the next search is sharper
        if (window.DRC && window.DRC.ask) window.DRC.ask(fb.dataset.fb === 'part'
          ? 'That clip was the right video but the wrong part. The part I needed was: '
          : 'That clip was the wrong video. What I was looking for was: ');
      }
      return;
    }
    const vb = e.target.closest('.video-card [data-vote], .video-card [data-another]');
    if (vb) {
      const card = vb.closest('.video-card');
      return vb.hasAttribute('data-another') ? another(card) : vote(card, +vb.dataset.vote);
    }
    const th = e.target.closest('.video-thumb');
    if (th) {
      const c = th.closest('.video-card');
      const q = new URLSearchParams({ autoplay: '1', rel: '0', modestbranding: '1' });
      if (+c.dataset.t0) q.set('start', c.dataset.t0);
      if (+c.dataset.t1) q.set('end', c.dataset.t1);
      const fr = document.createElement('iframe');
      fr.src = `https://www.youtube-nocookie.com/embed/${c.dataset.vid}?${q}`;
      fr.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
      fr.allowFullscreen = true;
      fr.className = 'video-frame';
      th.replaceWith(fr);
      // when the clip should be over, ask how it was (the ask also shows right away if they scroll past)
      const len = (+c.dataset.t1 && +c.dataset.t1 > +c.dataset.t0) ? (+c.dataset.t1 - +c.dataset.t0) : 90;
      const ask = c.querySelector('.video-ask');
      if (ask) setTimeout(() => { ask.hidden = false; ask.classList.add('pulse'); }, (len + 3) * 1000);
      return;
    }
    const b = e.target.closest('[data-step]');
    if (!b) return;
    const box = b.closest('.steps');
    const i = +box.dataset.i, n = +box.dataset.n, act = b.dataset.step;
    if (act === 'play') {
      if (box._t) return stopPlay(box);
      if (i >= n - 1) showFrame(box, 0);
      b.textContent = '⏸ Pause';
      box._t = setInterval(() => {
        if (!box.isConnected) return clearInterval(box._t);
        const k = showFrame(box, +box.dataset.i + 1);
        if (k >= n - 1) stopPlay(box);
      }, 1800);
      return;
    }
    stopPlay(box);
    showFrame(box, act === 'first' ? 0 : act === 'prev' ? i - 1 : i + 1);
  });

  function render(src) {
    const lines = String(src || '').replace(/\r\n?/g, '\n').split('\n');
    const out = [];
    let i = 0;
    while (i < lines.length) {
      const line = lines[i];
      let m = line.match(FENCE);
      if (m) {
        const fence = m[1], lang = m[2], buf = [];
        const indent = line.match(/^\s*/)[0].length;
        i++;
        while (i < lines.length && !(lines[i].trim().startsWith(fence[0].repeat(3)) && lines[i].trim().replace(/[`~]/g, '') === '')) {
          buf.push(indent ? lines[i].replace(new RegExp('^ {0,' + indent + '}'), '') : lines[i]);
          i++;
        }
        i++;
        const low = lang.toLowerCase();
        if (low === 'video' || low === 'youtube') { out.push(videoCard(buf)); continue; }
        if (low === 'steps' || low === 'animate') { out.push(stepsPlayer(buf)); continue; }
        if (low === 'image') { out.push('<div class="img-pending">🎨 Drawing a picture…</div>'); continue; }
        if (low === 'make') { out.push('<div class="img-pending">🛠️ Making your file…</div>'); continue; }
        if (low === 'made') { out.push(madeCard(buf)); continue; }
        out.push(`<div class="codewrap">${lang ? `<span class="lang">${esc(lang)}</span>` : ''}<button class="copy" title="Copy">Copy</button><pre><code>${esc(buf.join('\n'))}</code></pre></div>`);
        continue;
      }
      if (/^\s*$/.test(line)) { i++; continue; }
      m = line.match(/^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$/);
      if (m) {
        const n = m[1].length, t = m[2];
        // question banners: "▶ NOW: A1 ..." and answer checks "✔ A1 check" / "❌ A1 ..."
        const cls = /^▶/.test(t) ? ' class="qhead"' : /^(✔|✅|❌|🔁)/.test(t) ? ' class="checkhead"' : '';
        out.push(`<h${n}${cls}>${inline(t)}</h${n}>`); i++; continue;
      }
      if (/^\s{0,3}([-*_])(\s*\1){2,}\s*$/.test(line)) { out.push('<hr>'); i++; continue; }
      if (line.includes('|') && i + 1 < lines.length && SEP.test(lines[i + 1])) {
        const head = splitRow(line);
        const aligns = splitRow(lines[i + 1]).map(c => /^:-+:$/.test(c) ? 'center' : /-+:$/.test(c) ? 'right' : '');
        i += 2;
        const rows = [];
        while (i < lines.length && lines[i].includes('|') && lines[i].trim()) { rows.push(splitRow(lines[i])); i++; }
        const al = k => aligns[k] ? ` style="text-align:${aligns[k]}"` : '';
        let h = '<div class="tablewrap"><table><thead><tr>' + head.map((c, k) => `<th${al(k)}>${inline(c)}</th>`).join('') + '</tr></thead><tbody>';
        for (const r of rows) {
          h += '<tr>' + head.map((_, k) => `<td${al(k)}>${inline(r[k] || '')}</td>`).join('') + '</tr>';
        }
        out.push(h + '</tbody></table></div>');
        continue;
      }
      if (/^\s{0,3}>/.test(line)) {
        const buf = [];
        while (i < lines.length && /^\s{0,3}>/.test(lines[i])) { buf.push(lines[i].replace(/^\s{0,3}>\s?/, '')); i++; }
        out.push('<blockquote>' + render(buf.join('\n')) + '</blockquote>');
        continue;
      }
      if (LIST.test(line)) { const [h, ni] = parseList(lines, i); out.push(h); i = ni; continue; }
      // paragraph: single newlines become <br> (chat style)
      const buf = [];
      while (i < lines.length && !/^\s*$/.test(lines[i]) && !FENCE.test(lines[i]) && !/^\s{0,3}#{1,6}\s/.test(lines[i]) &&
             !/^\s{0,3}>/.test(lines[i]) && !(LIST.test(lines[i]) && buf.length === 0) &&
             !(lines[i].includes('|') && i + 1 < lines.length && SEP.test(lines[i + 1])) &&
             !/^\s{0,3}([-*_])(\s*\1){2,}\s*$/.test(lines[i])) {
        if (LIST.test(lines[i])) break;
        buf.push(lines[i]); i++;
      }
      if (!buf.length) { buf.push(lines[i]); i++; }
      out.push('<p>' + buf.map(l => inline(l.replace(/\s+$/, ''))).join('<br>') + '</p>');
    }
    return out.join('\n');
  }

  window.MD = { render, inline, esc, hydrate };
})();
