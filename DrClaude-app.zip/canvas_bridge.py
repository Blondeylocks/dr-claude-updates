"""
Canvas sync WITHOUT a token, through the student's own logged-in browser (Python standard library only).

Some schools (CPP) block students from making Canvas access tokens. Canvas still lets a logged-in page read the
student's own data from /api/v1. So the browser does the reading and this app does everything else:

    Canvas tab (logged in)                     bridge pop-up  http://127.0.0.1:BRIDGE_PORT/bridge
      "Sync Dr. Claude" bookmark   <--postMessage-->   asks this server what to fetch next (same origin, no CORS)
      fetches /api/v1/... with her login                 posts each answer back
                                                         |
                                     canvas_sync.sync_all(cv=BridgeCanvas)  (the exact same sync the token uses)

Safety: the pop-up only talks to the configured Canvas origin, the bookmark only fetches /api/v1/ paths on its own
Canvas site, and every bridge call needs the random key baked into the bookmark. Nothing listens beyond 127.0.0.1.
Files are downloaded by the Canvas tab too (CPP's signed links refuse direct downloads) and handed over as raw bytes.
"""
import json
import secrets
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import canvas_sync

PORTS = (47219, 47231, 47243)   # first free one wins; the bookmark is built for the port actually in use
WAIT_ANSWER = 90                # seconds to wait for the Canvas tab to answer one request


class BridgeLost(Exception):
    """The Canvas tab or pop-up went away: stop the whole sync instead of waiting on every request."""


class Bridge:
    def __init__(self):
        self.cond = threading.Condition()
        self.pending = []            # [(id, path)]
        self.answers = {}            # id -> dict(status, link, body)
        self.next_id = 1
        self.session = None          # id of the pop-up currently driving a sync
        self.last_seen = 0.0
        self.done_msg = None
        self.ok = False
        self.origin = None

    def ask(self, path, kind="get"):
        """Called from the sync thread: have the Canvas tab GET this /api/v1 path (kind 'get') or download this
        file URL (kind 'file'). Returns the answer dict: status, link, body (text) or data (bytes)."""
        with self.cond:
            rid = self.next_id
            self.next_id += 1
            self.pending.append((rid, path, kind))
            self.cond.notify_all()
            end = time.time() + WAIT_ANSWER
            while rid not in self.answers:
                left = end - time.time()
                if left <= 0 or self.session is None:
                    self.pending = [p for p in self.pending if p[0] != rid]
                    self.session = None
                    raise BridgeLost("The Canvas tab stopped answering. Keep the Canvas tab and the Dr. Claude "
                                     "pop-up open until the sync finishes, then click the bookmark again.")
                self.cond.wait(min(left, 2))
            return self.answers.pop(rid)

    def next_job(self, sid, timeout=20):
        """Called by the pop-up (long poll). Returns a job dict, {'idle': True}, or {'done': msg}."""
        end = time.time() + timeout
        with self.cond:
            while True:
                if self.session != sid:
                    return {"done": "Another sync window took over. You can close this one."}
                self.last_seen = time.time()
                if self.pending:
                    rid, path, kind = self.pending.pop(0)
                    return {"id": rid, "url": path, "kind": kind}
                if self.done_msg is not None and not canvas_sync.STATE.get("running"):
                    return {"done": self.done_msg, "ok": self.ok}
                left = end - time.time()
                if left <= 0:
                    return {"idle": True}
                self.cond.wait(min(left, 1))

    def answer(self, sid, rid, status, link="", body="", data=None):
        with self.cond:
            if self.session != sid:
                return
            self.answers[int(rid)] = {"status": int(status or 0), "link": link or "", "body": body or "", "data": data}
            self.cond.notify_all()

    def finish(self, msg, ok):
        with self.cond:
            self.done_msg, self.ok = msg, ok
            self.cond.notify_all()


BRIDGE = Bridge()


class BridgeCanvas(canvas_sync.Canvas):
    """canvas_sync.Canvas, but every API GET is done by the student's logged-in Canvas tab."""
    via = "browser"

    def __init__(self, base, bridge):
        super().__init__(base, "")
        self.bridge = bridge

    def _req(self, url):  # used by download(): signed file links need no Authorization header
        if url.startswith("/"):
            url = self.base + url
        return canvas_sync.urllib.request.Request(url, headers={"User-Agent": "DrClaude/1.0"})

    def download(self, url, dest):
        """The Canvas tab fetches the file (it follows Canvas's redirect with her login) and sends the bytes."""
        full = url if url.startswith("http") else self.base + url
        p = urllib.parse.urlparse(full)
        if p.netloc.lower() != urllib.parse.urlparse(self.base).netloc.lower():
            raise canvas_sync.CanvasError(400, f"refusing to download from {p.netloc}")
        a = self.bridge.ask(p.path + ("?" + p.query if p.query else ""), kind="file")
        if a["status"] != 200 or a.get("data") is None:
            raise canvas_sync.CanvasError(a["status"], f"Canvas said {a['status']} for the file")
        tmp = Path(canvas_sync.long_path(str(dest) + ".part"))
        tmp.parent.mkdir(parents=True, exist_ok=True)
        tmp.write_bytes(a["data"])
        canvas_sync.os.replace(tmp, canvas_sync.long_path(dest))

    def _to_path(self, url):
        p = urllib.parse.urlparse(url)
        if p.netloc and p.netloc.lower() != urllib.parse.urlparse(self.base).netloc.lower():
            raise canvas_sync.CanvasError(400, f"refusing to read a non-Canvas address: {p.netloc}")
        path = p.path + ("?" + p.query if p.query else "")
        if not path.startswith("/api/v1/"):
            raise canvas_sync.CanvasError(400, f"refusing to read {p.path}")
        return path

    def get(self, path, params=None):
        url = path if path.startswith("http") else self.base + path
        if params:
            url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params, doseq=True)
        a = self.bridge.ask(self._to_path(url))
        status, link, body = a["status"], a["link"], a["body"]
        if status in (401,):
            raise canvas_sync.CanvasError(401, "Canvas says you're logged out. Log in to Canvas, then click the bookmark again.")
        if status != 200:
            raise canvas_sync.CanvasError(status, f"Canvas said {status} for {urllib.parse.urlparse(url).path}")
        if body.startswith("while(1);"):
            body = body[9:]
        nxt = None
        for part in (link or "").split(","):
            m = canvas_sync.re.search(r'<([^>]+)>;\s*rel="next"', part)
            if m:
                nxt = m.group(1)
        return (json.loads(body) if body.strip() else None), nxt


# ----------------------------------------------------------------------------- settings + bookmark
class Config:
    data_dir = None      # set by dr_claude.py
    root = None          # Documents\Dr. Claude
    get_canvas_url = staticmethod(lambda: "https://canvas.cpp.edu")
    on_done = staticmethod(lambda: None)
    port = None


def _key():
    p = Path(Config.data_dir) / "bridge_key.txt"
    try:
        k = p.read_text(encoding="utf-8").strip()
        if len(k) >= 20:
            return k
    except OSError:
        pass
    k = secrets.token_urlsafe(24)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(k, encoding="utf-8")
    return k


def canvas_origin():
    u = (Config.get_canvas_url() or "https://canvas.cpp.edu").strip().rstrip("/")
    if not u.startswith("http"):
        u = "https://" + u
    p = urllib.parse.urlparse(u)
    return f"{p.scheme}://{p.netloc}"


def allowed_origin(o):
    """The Canvas site the bookmark was clicked on: the one in Settings, or any https Canvas host."""
    p = urllib.parse.urlparse(o or "")
    if p.scheme != "https" or not p.netloc or p.path not in ("", "/"):
        return None
    host = p.hostname or ""
    if f"https://{p.netloc}" == canvas_origin() or host.endswith(".instructure.com") or host.startswith("canvas."):
        return f"https://{p.netloc}"
    return None


def bookmarklet():
    """The javascript: link she drags to her bookmarks bar. Runs on her Canvas tab when clicked."""
    if not Config.port:
        return ""
    o = f"http://127.0.0.1:{Config.port}"
    js = ("(()=>{const O='%s',K='%s';"
          "if(!window.__drcBridge){window.__drcBridge=1;addEventListener('message',async e=>{"
          "if(e.origin!==O)return;const d=e.data||{};"
          "if(d.drc==='file'){let st=0,buf=null;try{const u=new URL(d.url,location.origin);"
          "if(u.origin===location.origin&&(u.pathname.startsWith('/files/')||u.pathname.startsWith('/courses/'))){const r=await fetch(u.href,{credentials:'same-origin'});"
          "st=r.status;if(r.ok)buf=await r.arrayBuffer()}else st=400}catch(x){st=0}"
          "e.source.postMessage({drc:'fres',id:d.id,status:st,buf:buf},O,buf?[buf]:[]);return}"
          "if(d.drc!=='get')return;let st=0,body='',link='';"
          "if(typeof d.url==='string'&&d.url.startsWith('/api/v1/')){try{const r=await fetch(d.url,{credentials:'same-origin',"
          "headers:{Accept:'application/json'}});st=r.status;link=r.headers.get('Link')||'';body=await r.text()}catch(x){st=0}}"
          "else st=400;e.source.postMessage({drc:'res',id:d.id,status:st,link:link,body:body},O)})}"
          "const w=window.open(O+'/bridge?k='+K+'&o='+encodeURIComponent(location.origin),'drc_bridge','width=480,height=420');"
          "if(!w)alert('Dr. Claude: allow pop-ups for this Canvas site, then click the bookmark again.')})()") % (o, _key())
    return "javascript:" + urllib.parse.quote(js, safe="()=>{};,.'/:+!?*&|[]$_-")


BRIDGE_PAGE = """<!doctype html><meta charset=utf-8><title>Dr. Claude · Canvas sync</title>
<style>body{font:15px system-ui,Segoe UI,sans-serif;margin:0;padding:22px;background:#0f172a;color:#e2e8f0}
h1{font-size:18px;margin:0 0 10px}#s{font-size:15px;margin:8px 0}#l{font:12px ui-monospace,Consolas,monospace;color:#94a3b8;
max-height:170px;overflow:auto;white-space:pre-wrap}.bar{height:8px;background:#1e293b;border-radius:4px;overflow:hidden;margin:10px 0}
.bar span{display:block;height:100%;width:5%;background:#38bdf8;transition:width .4s}.ok{color:#4ade80}.bad{color:#f87171}</style>
<h1>🎓 Dr. Claude · Canvas sync</h1><div id=s>Connecting to your Canvas tab…</div><div class=bar><span id=b></span></div><div id=l></div><p id=n style="font-size:13px;color:#94a3b8;margin-top:14px"></p>
<script>
const K=__KEY__, CANVAS=__ORIGIN__, sid=Math.random().toString(36).slice(2);
const S=t=>document.getElementById('s').textContent=t, L=t=>{const l=document.getElementById('l');l.textContent=t};
const waiting={};
addEventListener('message',e=>{if(e.origin!==CANVAS)return;const d=e.data||{};if((d.drc==='res'||d.drc==='fres')&&waiting[d.id]){waiting[d.id](d);delete waiting[d.id]}});
function viaCanvas(id,url,kind){return new Promise(res=>{waiting[id]=res;opener.postMessage({drc:kind==='file'?'file':'get',id,url},CANVAS);
  setTimeout(()=>{if(waiting[id]){delete waiting[id];res({id,status:0,link:'',body:''})}},kind==='file'?300000:60000)})}
const q=(p,o)=>fetch(p+(p.includes('?')?'&':'?')+'k='+encodeURIComponent(K)+'&sid='+sid,o).then(r=>r.json());
async function status(){try{const s=await fetch('/status?k='+encodeURIComponent(K)).then(r=>r.json());
  if(s.total)document.getElementById('b').style.width=Math.max(5,Math.round(100*s.done/s.total))+'%';
  L((s.log||[]).slice(-8).join('\\n'));if(s.phase)S(s.phase+(s.course?': '+s.course:''))}catch(e){}}
const EVERY=3*3600*1000;let tick=0;
function quiet(t){S(t);document.getElementById('s').className='';document.getElementById('l').textContent=''}
async function canvasAlive(){if(!opener||opener.closed)return false;const a=await Promise.race([viaCanvas('ping'+Date.now(),'/api/v1/users/self','get'),
  new Promise(r=>setTimeout(()=>r({status:0}),15000))]);return a.status===200}
async function runSync(auto){
  let st;try{st=await q('/hello?o='+encodeURIComponent(CANVAS))}catch(e){if(!auto)S('Dr. Claude isn’t running. Open the Dr. Claude app, then click the bookmark again.');return false}
  if(st.error){if(!auto){S(st.error);document.getElementById('s').className='bad'}return false}
  tick=setInterval(status,1000);
  for(;;){let j;try{j=await q('/next')}catch(e){S('Lost Dr. Claude. Is the app still open?');clearInterval(tick);return false}
    if(j.done){clearInterval(tick);await status();S(j.done);document.getElementById('s').className=j.ok?'ok':'';
      document.getElementById('b').style.width='100%';return j.ok}
    if(!j.url)continue;
    const a=await viaCanvas(j.id,j.url,j.kind);
    if(j.kind==='file')await q('/file?id='+j.id+'&status='+a.status,{method:'POST',headers:{'Content-Type':'application/octet-stream'},body:a.buf||new ArrayBuffer(0)});
    else await q('/result',{method:'POST',headers:{'Content-Type':'text/plain'},body:JSON.stringify(a)});
  }
}
// Auto-sync: while this little window and the Canvas tab stay open, re-sync quietly every 3 hours.
// No pop-ups or alerts: if Canvas moved on or the app is closed, it just waits and tries again later.
function later(){const at=new Date(Date.now()+EVERY);
  document.getElementById('n').textContent='🔁 Auto-sync is on: I’ll quietly check Canvas again around '+at.toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})+
    ' as long as this window and your Canvas tab stay open. You can minimize this window, or close it to stop.';
  setTimeout(async()=>{if(await canvasAlive()){quiet('Checking Canvas for anything new…');await runSync(true)}later()},EVERY)}
(async()=>{
  if(!opener){S('Open this from the “Sync Dr. Claude” bookmark on your Canvas tab.');return}
  if(await runSync(false))later();
})();
</script>"""


class _Server(ThreadingHTTPServer):
    """Never share the port: Python's default SO_REUSEADDR lets a second program bind the same port on Windows."""
    allow_reuse_address = False
    daemon_threads = True

    def server_bind(self):
        import socket
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


class _H(BaseHTTPRequestHandler):
    server_version = "DrClaudeBridge/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass

    def _out(self, code, body, ctype="application/json; charset=utf-8"):
        b = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(b)

    def _json(self, obj, code=200):
        self._out(code, json.dumps(obj, ensure_ascii=False))

    def _q(self):
        return {k: v[0] for k, v in urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).items()}

    def _ok(self):
        host = (self.headers.get("Host") or "").lower()
        if host not in (f"127.0.0.1:{Config.port}", f"localhost:{Config.port}"):
            return False
        return secrets.compare_digest(self._q().get("k", ""), _key())

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if not self._ok():
            return self._json({"error": "This sync link is out of date. Copy the bookmark again from Dr. Claude → Settings."}, 403)
        q = self._q()
        if path == "/bridge":
            origin = allowed_origin(q.get("o")) or canvas_origin()
            page = BRIDGE_PAGE.replace("__KEY__", json.dumps(_key())).replace("__ORIGIN__", json.dumps(origin))
            return self._out(200, page, "text/html; charset=utf-8")
        if path == "/hello":
            return self._json(start(q.get("sid", ""), allowed_origin(q.get("o")) or canvas_origin()))
        if path == "/next":
            return self._json(BRIDGE.next_job(q.get("sid", "")))
        if path == "/status":
            st = {k: canvas_sync.STATE.get(k) for k in ("running", "phase", "course", "done", "total")}
            st["log"] = canvas_sync.STATE.get("log", [])[-8:]
            return self._json(st)
        return self._json({"error": "not found"}, 404)

    def do_POST(self):
        if not self._ok():
            return self._json({"error": "bad key"}, 403)
        n = int(self.headers.get("Content-Length") or 0)
        if n > 400_000_000:
            return self._json({"error": "too big"}, 413)
        q = self._q()
        if urllib.parse.urlparse(self.path).path == "/file":
            data = self.rfile.read(n)
            st = int(q.get("status") or 0)
            BRIDGE.answer(q.get("sid", ""), q.get("id", 0), st, data=data if st == 200 else None)
            return self._json({"ok": True})
        try:
            d = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except ValueError:
            return self._json({"error": "bad json"}, 400)
        if urllib.parse.urlparse(self.path).path == "/result":
            BRIDGE.answer(self._q().get("sid", ""), d.get("id", 0), d.get("status", 0), d.get("link", ""), d.get("body", ""))
            return self._json({"ok": True})
        return self._json({"error": "not found"}, 404)


def start(sid, origin):
    """A pop-up said hello: start a browser-driven sync (one at a time)."""
    if not sid:
        return {"error": "missing session"}
    if canvas_sync.STATE.get("running"):
        if BRIDGE.session and time.time() - BRIDGE.last_seen < 30:
            return {"error": "A Canvas sync is already running in another window. Let it finish first."}
        if not BRIDGE.session:
            return {"error": "A token sync is running right now. Try again in a minute."}
    with BRIDGE.cond:
        BRIDGE.session, BRIDGE.done_msg, BRIDGE.ok, BRIDGE.pending, BRIDGE.answers = sid, None, False, [], {}
        BRIDGE.origin = origin
        BRIDGE.last_seen = time.time()

    def run():
        cv = BridgeCanvas(origin, BRIDGE)
        try:
            canvas_sync.sync_all(cv.base, "", Config.root, cv=cv)
        finally:
            st = canvas_sync.STATE
            ok = st.get("phase") == "Done"
            if ok:
                msg = f"✅ Done! {st.get('courses', 0)} class(es) synced, {st.get('files_new', 0)} new file(s)."
            else:
                msg = "⚠️ " + ((st.get("errors") or ["The sync stopped."])[-1])
            BRIDGE.finish(msg, ok)
            try:
                Config.on_done()
            except Exception:
                pass

    threading.Thread(target=run, daemon=True).start()
    return {"ok": True}


def serve(data_dir, root, get_canvas_url, on_done=None):
    """Start the bridge listener on the first free fixed port. Returns the port, or None."""
    Config.data_dir, Config.root, Config.get_canvas_url = Path(data_dir), Path(root), get_canvas_url
    if on_done:
        Config.on_done = on_done
    pref = Path(data_dir) / "bridge_port.txt"
    order = list(PORTS)
    try:
        last = int(pref.read_text().strip())
        if last in order:
            order.remove(last)
            order.insert(0, last)
    except (OSError, ValueError):
        pass
    for port in order:
        try:
            srv = _Server(("127.0.0.1", port), _H)
        except OSError:
            continue
        srv.daemon_threads = True
        Config.port = port
        try:
            pref.write_text(str(port))
        except OSError:
            pass
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        return port
    return None
