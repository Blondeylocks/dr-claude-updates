"""
Teaching Rules: the student's own rules for HOW Dr. Claude teaches (the "Command" page manages them).

    Profile\\rules.json          source of truth: rules + feedback log + suggestion inbox
    Profile\\Teaching Rules.md   the same rules as Markdown, rewritten on every change; the tutor reads it every turn

A change is a dict: {"op": "add"|"edit"|"delete"|"toggle", "id": ..., "group": ..., "text": ..., "why": ..., "course": ...}.
Nothing changes until the student confirms it: propose() only describes before/after, apply() writes.
"""
import datetime as dt
import json
import re
import threading
import uuid
from pathlib import Path

GROUPS = ["Format", "Pace", "Questions", "Visuals", "Tone", "Per-class"]
_lock = threading.RLock()


class Rules:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.json = self.folder / "rules.json"
        self.md = self.folder / "Teaching Rules.md"

    # ---- storage
    def load(self):
        try:
            d = json.loads(self.json.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            d = {}
        d.setdefault("rules", [])
        d.setdefault("feedback", [])
        d.setdefault("inbox", [])
        d.setdefault("version", 0)
        return d

    def save(self, d):
        with _lock:
            d["version"] = int(d.get("version", 0)) + 1
            self.folder.mkdir(parents=True, exist_ok=True)
            tmp = self.json.with_suffix(".tmp")
            tmp.write_text(json.dumps(d, indent=1, ensure_ascii=False), encoding="utf-8")
            tmp.replace(self.json)
            self.md.write_text(to_markdown(d), encoding="utf-8")
        return d

    def version(self):
        return self.load().get("version", 0)

    def active(self, course=""):
        """Rules in force (for one class: the general ones plus that class's Per-class rules)."""
        out = []
        for r in self.load()["rules"]:
            if not r.get("on", True):
                continue
            if r.get("group") == "Per-class" and course and r.get("course") and r["course"].replace(" ", "").lower() != course.replace(" ", "").lower():
                continue
            out.append(r)
        return out

    # ---- changes
    def propose(self, changes):
        """-> list of {change, before, after, summary} for the confirm step (invalid changes are dropped)."""
        rules = {r["id"]: r for r in self.load()["rules"]}
        out = []
        for ch in changes or []:
            op = str(ch.get("op", "")).lower()
            r = rules.get(str(ch.get("id", "")))
            if op == "add":
                text = str(ch.get("text", "")).strip()
                if not text or any(x["text"].strip().lower() == text.lower() for x in rules.values()):
                    continue
                grp = ch.get("group") if ch.get("group") in GROUPS else guess_group(text)
                new = {"group": grp, "text": text[:400], "why": str(ch.get("why", "")).strip()[:300],
                       "course": str(ch.get("course", "")).strip()[:20] if grp == "Per-class" else ""}
                out.append({"change": dict(new, op="add"), "before": None, "after": new, "summary": f"Add a {grp} rule"})
            elif op in ("edit", "delete", "toggle") and r:
                if op == "edit":
                    after = dict(r)
                    for k in ("text", "why", "group", "course"):
                        if ch.get(k) not in (None, ""):
                            after[k] = str(ch[k]).strip()[:400]
                    if after["group"] not in GROUPS:
                        after["group"] = r["group"]
                    if after == r:
                        continue
                    out.append({"change": {"op": "edit", "id": r["id"], **{k: after[k] for k in ("text", "why", "group", "course")}},
                                "before": r, "after": after, "summary": f"Change a {r['group']} rule"})
                elif op == "delete":
                    out.append({"change": {"op": "delete", "id": r["id"]}, "before": r, "after": None, "summary": f"Remove a {r['group']} rule"})
                else:
                    on = bool(ch["on"]) if "on" in ch else not r.get("on", True)
                    if on == r.get("on", True):
                        continue
                    out.append({"change": {"op": "toggle", "id": r["id"], "on": on}, "before": r, "after": dict(r, on=on),
                                "summary": ("Turn on" if on else "Pause") + f" a {r['group']} rule"})
        return out

    def apply(self, changes, source="command"):
        today = dt.date.today().isoformat()
        with _lock:
            d = self.load()
            by = {r["id"]: r for r in d["rules"]}
            done = 0
            for ch in changes or []:
                op = ch.get("op")
                if op == "add" and str(ch.get("text", "")).strip():
                    grp = ch.get("group") if ch.get("group") in GROUPS else guess_group(ch["text"])
                    d["rules"].append({"id": ch.get("id") if ch.get("id") and ch["id"] not in by else uuid.uuid4().hex[:8],
                                       "group": grp, "text": str(ch["text"]).strip()[:400], "why": str(ch.get("why", "")).strip()[:300],
                                       "course": str(ch.get("course", "")).strip()[:20] if grp == "Per-class" else "",
                                       "date": today, "on": ch.get("on", True) is not False, "source": ch.get("source") or source})
                    done += 1
                elif ch.get("id") in by:
                    r = by[ch["id"]]
                    if op == "delete":
                        d["rules"] = [x for x in d["rules"] if x["id"] != r["id"]]
                    elif op == "toggle":
                        r["on"] = bool(ch.get("on", not r.get("on", True)))
                    elif op == "edit":
                        for k in ("text", "why", "group", "course"):
                            if ch.get(k) not in (None, ""):
                                r[k] = str(ch[k]).strip()[:400]
                        if r["group"] not in GROUPS:
                            r["group"] = "Format"
                        r["date"] = today
                    else:
                        continue
                    done += 1
            if done:
                self.save(d)
        return done

    def log_feedback(self, text, source="check-in", course=""):
        with _lock:
            d = self.load()
            d["feedback"].append({"date": dt.datetime.now().isoformat(timespec="minutes"), "text": str(text).strip()[:600],
                                  "source": source, "course": course})
            d["feedback"] = d["feedback"][-300:]
            self.save(d)

    def add_inbox(self, items, source, quote=""):
        with _lock:
            d = self.load()
            for it in items:
                d["inbox"].append({"id": uuid.uuid4().hex[:8], "date": dt.datetime.now().isoformat(timespec="minutes"),
                                   "source": source, "quote": quote[:400], **it})
            d["inbox"] = d["inbox"][-50:]
            self.save(d)

    def take_inbox(self, iid):
        with _lock:
            d = self.load()
            it = next((x for x in d["inbox"] if x["id"] == iid), None)
            d["inbox"] = [x for x in d["inbox"] if x["id"] != iid]
            self.save(d)
            return it

    def sync_prefs(self, prefs, rule_text, group_of):
        """The setup toggles are the first rules: one rule per toggle, id 'pref_<key>', on/off follows the toggle."""
        with _lock:
            d = self.load()
            by = {r["id"]: r for r in d["rules"]}
            changed = False
            for key, on in prefs.items():
                rid = f"pref_{key}"
                if rid in by:
                    if by[rid].get("on", True) != bool(on):
                        by[rid]["on"] = bool(on)
                        changed = True
                elif key in rule_text:
                    d["rules"].append({"id": rid, "group": group_of.get(key, "Format"), "text": rule_text[key], "why": "Chosen during setup",
                                       "course": "", "date": dt.date.today().isoformat(), "on": bool(on), "source": "setup"})
                    changed = True
            if changed or not self.md.exists():
                self.save(d)


def guess_group(text):
    t = text.lower()
    for g, words in (("Visuals", ("diagram", "draw", "picture", "visual", "animation", "video", "image")),
                     ("Questions", ("question", "quiz", "retry", "hint", "answer", "problem")),
                     ("Pace", ("slow", "fast", "pace", "long", "short", "time", "minutes")),
                     ("Tone", ("tone", "encourag", "praise", "funny", "blunt", "kind", "joke"))):
        if any(w in t for w in words):
            return g
    return "Format"


def to_markdown(d):
    out = ["# Teaching Rules",
           "*The student's own rules for how Dr. Claude teaches. They OVERRIDE the default teaching style. "
           "Managed on the Command page in the app; edit there, not here.*", ""]
    for g in GROUPS:
        rs = [r for r in d["rules"] if r.get("group") == g]
        if not rs:
            continue
        out.append(f"## {g}")
        for r in rs:
            pre = "" if r.get("on", True) else "(paused) "
            cls = f"[{r['course']}] " if r.get("course") else ""
            why = f" — why: \"{r['why']}\"" if r.get("why") else ""
            out.append(f"- {pre}{cls}{r['text']} _({r.get('date', '')}{why})_")
        out.append("")
    out.append("## Feedback log")
    for f in d["feedback"][-40:]:
        out.append(f"- {f['date']} ({f.get('source', '')}{', ' + f['course'] if f.get('course') else ''}): {f['text']}")
    if not d["feedback"]:
        out.append("- (nothing yet)")
    return "\n".join(out) + "\n"


def rules_for_prompt(rules):
    if not rules:
        return ""
    lines = []
    for g in GROUPS:
        for r in rules:
            if r.get("group") == g:
                lines.append(f"- [{g}{' · ' + r['course'] if r.get('course') else ''}] {r['text']}")
    return "\n".join(lines)


CHANGE_RE = re.compile(r"```rule-change\s*\n(.*?)```", re.S)


def parse_changes(text):
    """Pull the ```rule-change JSON out of a Command AI reply. -> (reply text without the block, [changes])"""
    changes = []
    for raw in CHANGE_RE.findall(text or ""):
        try:
            j = json.loads(raw.strip())
        except ValueError:
            continue
        if isinstance(j, dict):
            j = j.get("changes", [j])
        changes += [c for c in j if isinstance(c, dict)]
    return CHANGE_RE.sub("", text or "").strip(), changes
